export { bmoRange };
class bmoRange extends HTMLElement {
    constructor() {
        super();
    }
    get inputLabel() { return this.getAttribute('label'); }
    set inputLabel(value) {
        if (value) {
            this.setAttribute('label', value);
        }
    }
    get rangeMax() { return this.getAttribute('max'); }
    set rangeMax(value) {
        if (value) {
            this.setAttribute('max', value);
        }
    }
    get rangeMin() { return this.getAttribute('min'); }
    set rangeMin(value) {
        if (value) {
            this.setAttribute('min', value);
        }
    }
    get rangeVal() { return this.getAttribute('value'); }
    set rangeVal(value) {
        if (value) {
            this.setAttribute('value', value);
        }
    }
    get rangeStep() { return this.getAttribute('step'); }
    set rangeStep(value) {
        if (value) {
            this.setAttribute('step', value);
        }
    }
    get rangePrefix() { return this.getAttribute('prefix'); }
    set rangePrefix(value) {
        if (value) {
            this.setAttribute('prefix', value);
        }
    }
    get rangeSuffix() { return this.getAttribute('suffix'); }
    set rangeSuffix(value) {
        if (value) {
            this.setAttribute('suffix', value);
        }
    }

    connectedCallback() {
        this.innerHTML =
            '<label for="range" class="range-label">' + this.inputLabel + '</label>' +
            '<input type="range" class="range">' +
            '<output class="range-bubble"><span class="bubble-text"></span></output>';

        this.classList.add('range-wrap');
        const range = this.querySelector(".range");
        const rangeLabel = this.querySelector(".range-label");
        const bubble = this.querySelector(".range-bubble");
        const bubbleText = this.querySelector(".range-bubble .bubble-text");
        if (this.hasAttribute('prefix')) {
            bubbleText.insertAdjacentHTML('beforebegin', '<span class="bubble-prefix">' + this.rangePrefix + '</div>');
        }
        if (this.hasAttribute('suffix')) {
            bubbleText.insertAdjacentHTML('afterend', '<span class="bubble-suffix">' + this.rangeSuffix + '</div>');
        }
        setTimeout(() => {
            bubble.style.display = `inline-block`;
            let labelToDash = this.querySelector('.range-label');
            let doIt = labelToDash.innerHTML;
            const labelToDash2 = doIt.replace(/\s+/g, '-').toLowerCase();
            range.setAttribute('name', labelToDash2);
            range.setAttribute('id', labelToDash2);
            range.setAttribute('min', this.rangeMin);
            range.setAttribute('max', this.rangeMax);
            range.setAttribute('step', this.rangeStep);
            range.setAttribute('value', this.rangeVal);
            rangeLabel.setAttribute('for', labelToDash2);

            setBubble(range, bubble);

            function setBubble(range, bubble) {
                const val = range.value;
                const min = range.min ? range.min : 0;
                const max = range.max ? range.max : 100;
                const newVal = Number(((val - min) * 100) / (max - min));
                bubbleText.innerHTML = val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                // Sorta magic numbers based on size of the native UI thumb
                bubble.style.left = `calc(${newVal}% + (${0 - newVal * 0.05}px))`;
            }
            range.addEventListener("input", () => {
                setBubble(range, bubble);
            });

        }, 0);

    }
    disconnectedCallback() {

    }
    static get observedAttributes() {
        return [ /***place attribute names here ***/ ];
    }
    attributeChangedCallback(attr, oldVal, newVal) {
        console.log('Attribute changed:', attr, oldVal, newVal);

    }

}

customElements.define('bmo-range', bmoRange);