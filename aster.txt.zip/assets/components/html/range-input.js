const allRanges = document.querySelectorAll(".range-wrap");

function setBubble(range, bubble) {
    const val = range.value;
    const min = range.min ? range.min : 0;
    const max = range.max ? range.max : 100;
    const newVal = Number(((val - min) * 100) / (max - min));
    bubble.querySelector('.bubble-text').innerHTML = val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

    // Sorta magic numbers based on size of the native UI thumb
    range.nextElementSibling.style.left = `calc(${newVal}% + (${8 - newVal * 0.15}px))`;
}
allRanges.forEach(wrap => {
    const range = wrap.querySelector('.range');
    const bubble = wrap.querySelector('.range-bubble');
    range.addEventListener("input", () => {
        setBubble(range, bubble);
    });
    setBubble(range, bubble);
});