document.addEventListener('input.textarea', e => {
    if (e.target.tagName.toLowerCase() !== 'textarea') return;
    e.target.autoExpand();
}, false);
HTMLTextAreaElement.prototype.autoExpand = function() {
    // Reset field height (breaks CSS transition)
    this.style.height = 'inherit';
    var height = this.scrollHeight;

    this.style.height = height + 'px';
};
HTMLTextAreaElement.prototype.dynamicValue = function(value) {
    this.value = value;
    this.autoExpand();
};