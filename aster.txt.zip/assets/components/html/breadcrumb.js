export { breadCrumbs };

var breadCrumbs = document.querySelectorAll('.bread-crumb-link');
[].forEach.call(breadCrumbs, function(breadCrumb) {
    breadCrumb.addEventListener('click', function() {
        document.querySelector('.bread-crumb-link.active').classList.remove('active');
        this.classList.add('active');
    });
});