import { registerApplication, start } from "single-spa";
import { authorize, isAuth } from '@bmo/auth';
import i18n  from './i18n';

registerApplication({
  name: "@bmo/e2e-mobile-web-app",
  app: () => System.import("@bmo/e2e-mobile-web-app"),
  activeWhen: ["/"],
  customProps: { i18n, lang: 'en'}
});

registerApplication({
  name: "@bmo/bmo-send-payment",
  app: () => System.import("@bmo/bmo-send-payment"),
  activeWhen: ["/sendmoney"],
  
});

// window.addEventListener('single-spa:before-routing-event', evt => {
//   console.log('single-spa is about to mount/unmount applications!');
//   console.log(evt.detail.originalEvent); // PopStateEvent
//   console.log(evt.detail.newAppStatuses); // { }
//   console.log(evt.detail.appsByNewStatus); // { MOUNTED: [], NOT_MOUNTED: [] }
//   console.log(evt.detail.totalAppChanges); // 0
// });

window.addEventListener('single-spa:before-first-mount', () => {
  if (!isAuth() && window.location.pathname !== "/redirect") {
    authorize();
    //return null;
  }
});

start({
  urlRerouteOnly: true,
});
