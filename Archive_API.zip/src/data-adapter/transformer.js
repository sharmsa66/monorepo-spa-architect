const {
  ACCOUNT_STATUS,
  ACCOUNT_TYPE,
  CURRENCY,
  RDM_CODETABLES,
} = require("./mappings");

function resolveBankAccounts(arrangements) {
  const accounts = [];
  const debits = [];
  arrangements.forEach((arrangement) => {
    if (arrangement.statusType === ACCOUNT_STATUS.Open) {
      if (arrangement.subCategory === ACCOUNT_TYPE.Saving) {
        accounts.unshift(arrangement);
      } else if (arrangement.subCategory === ACCOUNT_TYPE.Chequing) {
        accounts.push(arrangement);
      } else if (arrangement.linkedAccount) {
        debits.push(arrangement);
      }
    }
  });

  // Resolve cardNumber from debitCard category
  accounts.forEach((account) => {
    debits.forEach((debit) => {
      if (debit.linkedAccount.includes(account.arrangementId)) {
        account.debitCardNumber = debit.arrangementId;
      }
    });
  });

  return accounts;
}

function resolveCreditcardAccounts(arrangements) {
  const accounts = [];
  arrangements.forEach((arrangement) => {
    if (
      arrangement.subCategory === ACCOUNT_TYPE.CreditCard &&
      arrangement.statusType === ACCOUNT_STATUS.Open
    ) {
      accounts.push(arrangement);
    }
  });

  return accounts;
}

export function CustomerProfile(parent) {
  return {
    lastName: parent.lastName ? parent.lastName : "",
    firstName: parent.givenNameOne
      ? parent.givenNameOne
      : parent.organizationName,
    prefix: parent.prefixValue ? parent.prefixValue : "",
    preferredLanguage: parent.preferredLanguagValue,
    emailAddress: parent.contact ? parent.contact[0].primaryEmailAddress : null,
    homePhoneNumber: parent.contact ? parent.contact[0].homePhoneNumber : null,
    workPhoneNumber: parent.contact
      ? parent.contact[0].businessPhoneNumber
      : null,
    type: parent.organizationName ? "Organization" : "Person",
  };
}

export function accountSummary(parent) {
  const [par, userPref] = parent;

  // Resolve bank accounts and creditcard accounts separately
  // And merge them togehter as required
  const bankAccounts = resolveBankAccounts(par.arrangements);
  const creditcards = resolveCreditcardAccounts(par.arrangements);
  let accounts = [...bankAccounts, ...creditcards];

  // Try to shuffle the order of accounts based on user preference
  if (userPref) {
    const pref = userPref.procedures[0].outcomes[0].outcomeDetails;
    let target = 0;
    for (let i = 0; i < pref.accounts.length; i++) {
      for (let j = 0; j < accounts.length; j++) {
        if (pref.accounts[i] === accounts[j].arrangementId) {
          const temp = accounts[target];
          accounts[target] = accounts[j];
          accounts[j] = temp;
          accounts[target].numberOfTransaction = pref.numberTransaction[i];
          target++;
          break;
        }
      }
    }
  }

  //let commonAccounts = accounts.map((acct) => accountCommonResolvers(acct));

  // const accountActionsPromise = getActionDecision(context, accounts);

  return accounts;
}

export function fdxAccountSummary(parent) {
  const [fdxAccounts, userPref] = parent;

  let accounts = [];

  fdxAccounts.accounts.forEach((account) => {
    if (account.depositAccount) {
      accounts.push(account.depositAccount);
    } else if (account.locAccount) {
      accounts.push(account.locAccount);
    }
  });

  // Try to shuffle the order of accounts based on user preference
  if (userPref) {
    const pref = userPref.procedures[0].outcomes[0].outcomeDetails;
    let target = 0;
    for (let i = 0; i < pref.accounts.length; i++) {
      for (let j = 0; j < accounts.length; j++) {
        if (pref.accounts[i] === accounts[j].accountId) {
          const temp = accounts[target];
          accounts[target] = accounts[j];
          accounts[j] = temp;
          accounts[target].numberOfTransaction = pref.numberTransaction[i];
          target++;
          break;
        }
      }
    }
  }
  return accounts;
}

export function fdxAccountResolver(parent) {
  let actions = () => {
    const actionList = [];
    for (const key in parent.actions) {
      if (parent.actions[key].isEligible) {
        actionList.push(key);
      }
    }
    return actionList;
  };

  return {
    type: Object.keys(ACCOUNT_TYPE).find(
      (key) => ACCOUNT_TYPE[key] === parent.accountType
    ),
    accountNumber: parent.accountId,
    maskedAccountNumber: "****" + parent.accountNumber?.slice(-4),
    status: parent.status,
    currency: parent.currency?.currencyCode,
    name: parent.productName,
    balance: parent.currentBalance,
    actions: actions(),
    numberOfTransaction: parent.numberOfTransaction
      ? parent.numberOfTransaction
      : 10,

    bankTransitNumber: parent.routingTransitNumber,
    availableCredit: parent.availableCredit,
    creditLimit: parent.creditLine,
    minPaymentRequired: parent.minimumPaymentRequired,
    lastStatementAmount: parent.nextPaymentAmount,
    paymentDueDate: parent.nextPaymentDate?.substring(0, 10),
  };
}

export function accountCommonResolvers(parent) {
  let actions = () => {
    const actionList = [];
    for (const key in parent.actions) {
      if (parent.actions[key].isEligible) {
        actionList.push(key);
      }
    }
    return actionList;
  };
  let commonData = {
    type: Object.keys(ACCOUNT_TYPE).find(
      (key) => ACCOUNT_TYPE[key] === parent.subCategory
    ),
    accountNumber: parent.arrangementId,
    maskedAccountNumber: parent.maskedAccountNumber.slice(
      parent.maskedAccountNumber.length - 8
    ),
    status: parent.statusValue,
    currency: parent.currency ? parent.currency : parent.balance.currency,
    name: parent.productName,
    shortName: parent.productShortName,
    balance: parent.currentBalance,
    actions: actions(),
    numberOfTransaction: parent.numberOfTransaction
      ? parent.numberOfTransaction
      : 10,
    source: parent.adminSystemValue,
    transactions: parent.transactions,
  };

  if (
    parent.subCategory === ACCOUNT_TYPE.Chequing ||
    parent.subCategory === ACCOUNT_TYPE.Saving
  ) {
    let bankAccount = getBankAccount(parent);
    return { ...commonData, ...bankAccount };
  } else if (parent.subCategory === ACCOUNT_TYPE.CreditCard) {
    let creditCard = getCreditCard(parent);
    return { ...commonData, ...creditCard };
  }
}

export const resolveCustomerRecipeintList = (recipents) => {
  recipents.forEach((recipient) => {
    if (recipient.notificationPreferences) {
      const activeHandle = recipient.notificationPreferences.find(
        (handle) => handle.isActive
      );
      if (activeHandle) {
        recipient.handle = activeHandle.handle;
        recipient.handleType = activeHandle.type;
      }
    }
  });
  return recipents;
};

export function transactionMapper(parent) {
  return {
    merchantName: parent.merchantInfo ? parent.merchantInfo.name : "",
    description: parent.description
      ? parent.description
      : parent.transactionDescription,
    transactionDate: parent.createdDate
      ? parent.createdDate.substring(0, 10)
      : parent.transactionDate.substring(0, 10),
    postedDate: parent.postedDate
      ? parent.postedDate.substring(0, 10)
      : parent.postDate.substring(0, 10),
    amount: getTransactionAmount(parent),
    currency: parent.currency
      ? parent.currency
      : CURRENCY[parent.transactionAmount.code],
  };
}

export function fdxTransactionMapper(parent) {
  const transaction = parent[Object.keys(parent)[0]];
  return {
    merchantName: "", // Not implemented by FDX transaction API
    description: transaction.description,
    transactionDate: transaction.transactionTimestamp
      ? transaction.transactionTimestamp.substring(0, 10)
      : "",
    postedDate: transaction.postedTimestamp
      ? transaction.postedTimestamp.substring(0, 10)
      : "",
    amount:
      transaction.debitCreditMemo === "CREDIT"
        ? transaction.amount
        : -transaction.amount,
    currency: transaction.foreignCurrency ? transaction.foreignCurrency : "",
    category: transaction.transactionType ? transaction.transactionType : "",
  };
}

function getBankAccount(parent) {
  return {
    bankTransitNumber: parent.transitNumber,
    debitCardNumber: parent.debitCardNumber,
  };
}

function getCreditCard(parent) {
  return {
    availableCredit: parent.availableCredit,
    creditLimit: parent.creditLimit,
    minPaymentRequired: parent.minimumPaymentRequired,
    lastStatementAmount: parent.nextPaymentAmount,
    paymentDueDate: parent.nextPaymentDate.substring(0, 10),
  };
}

const getTransactionAmount = (parent) => {
  if (typeof parent.transactionAmount !== "object") {
    // Bank account transaction
    return parseFloat(parent.transactionAmount);
  } else {
    // Credit card transaction
    let amount = parseFloat(parent.transactionAmount.value);
    if (parent.debitCredit.toLowerCase() === "debit") {
      amount = -amount;
    }
    return amount;
  }
};

export async function parseRDMXml(payload) {
  const result = {};
  payload.parameters.forEach(async (entry) => {
    const table = {};
    const tableName = entry.code;
    const xml = await entry.value.replace("<![CDATA[", "").replace("]]>", "");
    const parser = new DOMParser();
    const xmlDoc = await parser.parseFromString(xml, "text/xml");
    const nodelist = xmlDoc.getElementsByTagName("RefDataValue");
    for (let i = 0; i < nodelist.length; i++) {
      const name = nodelist[i].childNodes[0].innerHTML;
      const code = nodelist[i].getElementsByTagName("Properties")[0]
        .childNodes[0].innerHTML;
      const codeNum = Number.parseInt(code);
      if (
        tableName !== "ES.CDPROVSTATETP" ||
        (codeNum < 114 && codeNum > 100 && code !== 888888 && code !== 999999)
      ) {
        table[code] = name;
      }
    }
    result[RDM_CODETABLES[tableName]] = table;
  });
  return result;
}

export const setUpdatableProfile = (parent) => {
  let fullName, prefix, lastName, firstName;

  for (const name of parent.personName) {
    if (name.nameUsageType === "1") {
      prefix = name.prefixTypeValue;
      lastName = name.lastName;
      firstName = name.givenNameOne + " " + name.givenNameTwo;
      fullName = firstName + " " + lastName;
    }
  }

  const getPrimaryOccupation = () => {
    for (const occupation of parent.occupation) {
      if (occupation.ordinalityType === "100000") {
        return occupation;
      }
    }
    return "";
  };

  const getPrimaryAddress = () => {
    for (const addr of parent.partyAddress) {
      if (addr.addressUsageType === "100000") {
        return addr;
      }
    }
  };

  const getUpdateRef = () => {
    const result = JSON.stringify({ sourceObjectRef: parent.sourceObjectRef });
    return result;
  };

  return {
    fullName,
    prefix,
    lastName,
    firstName,
    birthDate: parent.birthDate,
    primaryOccupation: getPrimaryOccupation(),
    primaryAddr: getPrimaryAddress(),
    contactMethods: parent.partyContactMethod,
    updateRef: getUpdateRef(),
  };
};
