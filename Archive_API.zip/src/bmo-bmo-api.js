// Anything exported from this file is importable by other in-browser modules.

import * as api from "./data-adapter/api";
export { default as ERRORS } from "./errors";
import * as util from "./util/util";

export { cardTypeBackgroundMap } from "./util/landingPageutil";

export async function getAccountSummary() {
  return await api.getAccountSummary();
}

export async function payBill(bill) {
  return await api.payBill(bill);
}

export async function eTransfer(payment) {
  return await api.eTransfer(payment);
}

export async function getCustomerPayees() {
  return await api.getCustomerPayees();
}

export async function getFDXAccountSummary() {
  return await api.getFDXAccountSummary();
}

export async function getFDXTransactions(accountNumber, numTrans = 10) {
  return await api.getFDXTransactions(accountNumber, numTrans);
}

export async function getParty() {
  return await api.getParty();
}

export async function referenceTables() {
  return await api.referenceTables();
}

export async function updatePrfoile(profile, accounts) {
  return await api.updateProfile(profile, accounts);
}

export async function getCustomerRecipients() {
  return await api.getCustomerRecipients();
}

export async function getAccountTransactions(
  accountType,
  accountNumber,
  accountSource,
  numTrans
) {
  return await api.getAccountTransactions(
    accountType,
    accountNumber,
    accountSource,
    numTrans
  );
}

export function getDeviceFingerprint() {
  return util.getDeviceFingerprint();
}

export function numberWithCommas(x) {
  return util.numberWithCommas(x);
}

export function convertObjectToArray(obj) {
  return util.convertObjectToArray(obj);
}
