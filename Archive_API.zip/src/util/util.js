export function numberWithCommas(x) {
  const parts = x.toString().split(".");
  const thousandSeperated = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${thousandSeperated}.${parts[1]}`;
}

export function convertObjectToArray(obj) {
  const arr = obj
    ? Object.keys(obj).map((key) => ({
        value: key,
        label: String(obj[key]).slice(0, 30),
      }))
    : [];
  return arr;
}

export function getDeviceFingerprint() {
  return window["add_deviceprint"]
    ? encodeURI(window["add_deviceprint"]())
    : null;
}
