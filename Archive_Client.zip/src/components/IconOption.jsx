import React from 'react';


export const IconOption = (props) =>{
    return (
        
        <div className="IconOption-icon">
         <img src={props.src} alt={props.text} />
         <span className="IconOption-icon-name">{props.text}</span>
         </div>
         
    )
}