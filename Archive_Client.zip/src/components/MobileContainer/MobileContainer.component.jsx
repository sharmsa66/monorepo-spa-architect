import React from 'react';
import mobilePhoneImg from '../../assets/mobile-template.svg';
import './MobileContainer.styles.scss';

const MobileContainer = (props) => {

  const viewportStyle = {};
  viewportStyle.top =  "117px" ;
  viewportStyle.height = "487px";
  const viewport = <div style={viewportStyle} className="phone-viewport">{props.children}</div>;

  // browser view
  return (
    <div className="page-container">
      <div className="phone-container">
        <div className="phone-img-container">
          <img className="phone-img" src={mobilePhoneImg} alt="phone-img" />
          {viewport}
        </div>
      </div>
    </div>
  );
}

export default MobileContainer;