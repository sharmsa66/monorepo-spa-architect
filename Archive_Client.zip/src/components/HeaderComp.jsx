import React from 'react';
import goback from '../assets/Header/Left.svg';
import notification from '../assets/Header/Notification.svg';
import {NavMenu} from './NavMenu'
import './Header.css';


export const HeaderComp = ({heading, onBackBtnClick, backImgSrc = goback, hideNav=false, hideVertIcon = false, bgColor='white', name}) =>{

    const [activeDrawer, setActiveDrawer] = React.useState(false);
 
    return (
        
        <div className="header-icon" style={{background:bgColor}}>
        <div className="back-menu">
        <img src={backImgSrc} alt="Back" onClick={onBackBtnClick}/>
        {heading && <span className="header-heading">{heading}</span>}
        </div>
         {!hideNav && <div className="bell-Menu flex">
         <img src={notification} alt="Notifications" style={{paddingRight:'20px'}}/>
            <NavMenu activeDrawer={activeDrawer} name={name} setActiveDrawer={(val) => setActiveDrawer(val)} hideVertIcon={hideVertIcon}/>
          </div>}
          </div>
         
    )
}