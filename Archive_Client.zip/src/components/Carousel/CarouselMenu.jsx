import React, {useEffect, useState} from 'react';
import Slider from 'react-slick';
import creditCardImg from '../../assets/CarouselCards/CreditCard.png';
import creditCardImg345 from '../../assets/CarouselCards/CreditCard345px.svg';
import ba1 from '../../assets/CarouselCards/BA1_345px.svg';
import ba2 from '../../assets/CarouselCards/BA2_345px.svg';
// import ba3 from '../../assets/CarouselCards/BA3_345px.svg';
// import ba4 from '../../assets/CarouselCards/BA4_345px.svg';
import bank1 from '../../assets/CarouselCards/BA1.png';
import bank2 from '../../assets/CarouselCards/BA2.png';
// import bank3 from '../../assets/CarouselCards/BA3.png';
// import bank4 from '../../assets/CarouselCards/BA4.png';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {AccountCard} from './AccountCard';
 

export const CarouselMenu = (props) =>{
  const [windowWidth, setWindowWidth] = useState(0);
  const [carouselMenu, setCarouselMenu] = useState([])
  const settings = {
    className: "account-carousel",
    centerMode: true,
    lazyLoad: true,
    dots: true,
    infinite: false,
    speed: 1500,
    slidesToShow: 1,
    arrows: false,
    initialSlide: props.curentSlide || 0,
    beforeChange: (_current, next) => {
      props.onAccountSlide(props.accounts[next], next);
    }
  };

  const resizeWindow = () => {
    setWindowWidth(window.innerWidth);
    
  };

  useEffect(() =>{
    function renderAccounts() {
      const cardAccountMap = {
          Saving: windowWidth < 410 ? bank1: ba1,
          Chequing: windowWidth < 410 ? bank2: ba2,
          CreditCard: windowWidth < 410 ? creditCardImg: creditCardImg345
      }
  
      const carouselCards = props.accounts.map(({type, balance, accountNumber='', name='',maskedAccountNumber='', numberOfTransaction}, index) => {
          const cardImg = cardAccountMap[type];
         
          return (<AccountCard key={index} cardImg={cardImg} currentBalance={balance}
             accountNumber={accountNumber} maskedAccountNumber={maskedAccountNumber} 
             accountName={name} type={type}
             showAccountInfo={props.showAccountInfo}
             />)
      })
      setCarouselMenu(carouselCards);
    }
    renderAccounts();
  }, [windowWidth])
  

  useEffect(() => {
    resizeWindow();
    window.addEventListener("resize", resizeWindow);
    return () => window.removeEventListener("resize", resizeWindow);
  }, []);

    return (
      // <div style={{minwidth: '375px'}}>
      <div>
        <Slider {...settings} >
            {carouselMenu}
        </Slider>
      </div>
    )
}
