import React from 'react';
import add from '../assets/PayBills/Add.svg';
import edit from '../assets/PayBills/Edit.svg';

export const AddAndSelect = (props) => {
    return (
        <div className="add-edit-payee">
        <span>{props.text}</span>
        { props.flow === "add" ? 
            <img src={add} onClick={props.onAction} alt='add'/> : 
            <img src={edit} onClick={props.onAction} alt='edit'/>
        }
        </div> 
    )

}