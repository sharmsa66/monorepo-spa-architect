import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import Drawer from '@material-ui/core/Drawer';
import {DrawerProfile} from './DrawerProfile';
import {DrawerMenu} from './DrawerMenu';

const useStyles = makeStyles((theme) =>({
  drawerContainer: {
    width: '100vw',
    maxWidth: '450px',
    background: '#095DA2'
  },
  drawerAnchorRight: {
    maxWidth:'450px',
    [theme.breakpoints.up('sm')]: {
      right: '21%'
    },
    [theme.breakpoints.up('md')]: {
      right: '28.6%'
    },
    [theme.breakpoints.up('lg')]: {
      right: '34.6%'
    }
  }
}));

export const NavMenu = ({hideVertIcon=false , activeDrawer, setActiveDrawer, name= "", onBackButtonClick}) => {
 
  const nameLetters = name.match(/\b(\w)/g);
  const nameLettersJoin = nameLetters? nameLetters.join(''): "";

  const classes = useStyles();
  
  const toggleDrawer = (open, overrideEvent=false) => (event) => {
    if (!overrideEvent && (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift'))) {
      return;
    }

    if(onBackButtonClick){
      onBackButtonClick()
    }

    setActiveDrawer(open)
  };

  return (
    <div>
      {!hideVertIcon && <MoreVertIcon onClick={toggleDrawer(true)}/>}
      <Drawer anchor='right' open={activeDrawer} onClose={toggleDrawer(false)} classes={{paperAnchorRight: classes.drawerAnchorRight}}>
        <div className={classes.drawerContainer}>
          <DrawerProfile closeDrawer={toggleDrawer(false, true)} name={nameLettersJoin}/>
          <DrawerMenu closeDrawer={toggleDrawer(false, true)} />
        </div>
      </Drawer>
     </div>
  );
}
