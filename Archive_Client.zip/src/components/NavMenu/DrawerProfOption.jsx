import React from 'react';


export const DrawerProfOption = (props) =>{
    
     return (
         <div className="profile-nav" onClick={props.onClick}>
         <img src={props.imgsrc} alt={props.text} style={{...props.imgStyle}}/>
         {props.label && <span> {props.label} </span>}
         </div>
     )
 }