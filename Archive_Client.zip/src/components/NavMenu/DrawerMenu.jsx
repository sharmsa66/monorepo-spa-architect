import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import List from '@material-ui/core/List';
import MyAccounts from '../../assets/Menu/MyAccounts.svg';
import InvestmentAccounts from '../../assets/Menu/InvestmentAccounts.svg';
import LoanAccounts from '../../assets/Menu/LoanAccounts.svg';
import sendMoney from '../../assets/Menu/SendMoney.svg';
import transfer from '../../assets/Menu/Transfer.svg';
import deposit from '../../assets/Menu/Deposit.svg';
import payBills from '../../assets/Menu/Paybills.svg';
import ApplyCC from '../../assets/Menu/ApplyCreditCard.svg';
import LineofCredit from '../../assets/Menu/ApplyLineofcredit.svg';
import BookAppt from '../../assets/Menu/Bookanappointment.svg';
import OpenBA from '../../assets/Menu/OpenaBankAccount.svg';
import help from '../../assets/Menu/Help.svg';
import ContactUs from '../../assets/Menu/ContactUs.svg';
import Atm from '../../assets/Menu/ATM.svg';
import Setting from '../../assets/Menu/Setting.svg';
import { Link, useLocation, useHistory } from "react-router-dom";
import { DrawerMenuOption } from './DrawerMenuOption';
import { useTranslation } from 'react-i18next';
import { useSelector} from 'react-redux';



const useStyles = makeStyles((theme) => ({
  container: {
    width: '100%',
    height: '100%',
    position: "relative",
    top: '169px'
  },
  list: {
    width: '100%',
    padding: 0,
    backgroundColor: theme.palette.background.paper,
  },
 /*  listitem:{
    borderBottom: '1px solid #DCDCDC'
  },
  listFwdIcon: {
    fontSize: '0.75rem'
  }, */
  firstAccordian: {
    borderRadius: '30px 30px 0 0',
    '& .MuiAccordionSummary-root':{
      borderRadius: '30px 30px 0 0',
    }
  },
  accordianExpanded: {
    margin: '0 !important'
  },
  accordianSummary:{
    background: '#F5F5F5',
    height: '56px'
  },
  accordianDetails:{
    padding: '0 20px'
  },
  heading: {
    fontSize: '16px',
    fontWeight: 600,
    fontStyle: 'normal',
    lineHeight: '23.5px'
  },
}));

export const DrawerMenu = ({closeDrawer}) =>{
  const classes = useStyles();
  const { t } = useTranslation();
  const location = useLocation();
  const history = useHistory();
  const accounts = useSelector((state) => state.landing.accounts);
  const profile = useSelector((state) => state.landing.profile);

    return (
      <div className={classes.container}>
        <Accordion defaultExpanded={true} classes={{root: classes.firstAccordian, expanded: classes.accordianExpanded}} square={true}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          classes={{root: classes.accordianSummary}}
          >
          <span className={classes.heading}>Accounts</span>
          </AccordionSummary>
          <AccordionDetails classes={{root: classes.accordianDetails}}>
            <List component="nav" aria-labelledby="accounts" className={classes.list}>
            
              <DrawerMenuOption text={t('My Accounts')} imgsrc={MyAccounts}  onClick={() =>{
                const currentPath = location.pathname;
                if(currentPath === '/'){
                  closeDrawer();

                }
                history.push('/')
              }}/>
           
              <DrawerMenuOption text={t('Investment Accounts')} imgsrc={InvestmentAccounts} />
              <DrawerMenuOption text={t('Loan Accounts')} imgsrc={LoanAccounts} />
              </List>
          </AccordionDetails>
        </Accordion>
        <Accordion classes={{expanded: classes.accordianExpanded}}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
          classes={{root: classes.accordianSummary}}
          >
          <span className={classes.heading}>Pay &amp; Transfer</span>
          </AccordionSummary>
          <AccordionDetails classes={{root: classes.accordianDetails}}>
            <List component="nav" aria-labelledby="accounts" className={classes.list}>
            <Link to = {{ pathname: "/sendmoney" , state:{accounts, profile} }}>
            <DrawerMenuOption text={t('Send Money')} imgsrc={sendMoney} />
            </Link>
            <DrawerMenuOption text={t('Transfer')} imgsrc={transfer} />
            <DrawerMenuOption text={t('Deposit')} imgsrc={deposit} />
            <Link to = "/paybills">
            <DrawerMenuOption text={t('Pay Bills')} imgsrc={payBills} />
            </Link>
            </List>
          </AccordionDetails>
        </Accordion>
        <Accordion classes={{expanded: classes.accordianExpanded}}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
          classes={{root: classes.accordianSummary}}
          >
          <span className={classes.heading}>Add Something new</span>
          </AccordionSummary>
          <AccordionDetails classes={{root: classes.accordianDetails}}>
            <List component="nav" aria-labelledby="accounts" className={classes.list}>
            <DrawerMenuOption text="Open a Bank Account" imgsrc={OpenBA} />
            <DrawerMenuOption text="Apply for Credit Card" imgsrc={ApplyCC} />
            <DrawerMenuOption text="Apply for a Line of Credit" imgsrc={LineofCredit} />
            </List>
          </AccordionDetails>
        </Accordion>
        <Accordion classes={{expanded: classes.accordianExpanded}}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}
          aria-controls="panel4a-content"
          id="panel4a-header"
          classes={{root: classes.accordianSummary}}
          >
          <span className={classes.heading}>Get in touch</span>
          </AccordionSummary>
          <AccordionDetails classes={{root: classes.accordianDetails}}>
            <List component="nav" aria-labelledby="accounts" className={classes.list}>
            <DrawerMenuOption text="Help" imgsrc={help} />
            <DrawerMenuOption text="Contact Us" imgsrc={ContactUs} />
            <DrawerMenuOption text="Find a Branch/ATM" imgsrc={Atm} />
            <DrawerMenuOption text="Book an Appointment" imgsrc={BookAppt} />
            </List>
          </AccordionDetails>
        </Accordion>
        <Accordion classes={{expanded: classes.accordianExpanded}}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}
          aria-controls="panel5a-content"
          id="panel5a-header"
          classes={{root: classes.accordianSummary}}
          >
          <span className={classes.heading}>Setting</span>
          </AccordionSummary>
          <AccordionDetails classes={{root: classes.accordianDetails}}>
            <List component="nav" aria-labelledby="accounts" className={classes.list}>
            <Link to = "/setting">
            <DrawerMenuOption text="Home Settings" imgsrc={Setting} onClick={() => {console.log('clcikced')}} />
            </Link>
            </List>
          </AccordionDetails>
        </Accordion>
      </div>
    )
}