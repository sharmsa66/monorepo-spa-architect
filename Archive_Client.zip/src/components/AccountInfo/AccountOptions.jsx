import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import List from '@material-ui/core/List';
import { AccountOption } from './AccountOption';
import { cardTypeBackgroundMap } from '../../util/landingPageutil';

const useStyles = makeStyles((theme) => ({
	container: {
		width: '100%',
		height: '100%',
		position: "relative",
	},
	list: {
		width: '100%',
		padding: 0,
		backgroundColor: theme.palette.background.paper,
	},
	/*  listitem:{
		borderBottom: '1px solid #DCDCDC'
	},
	listFwdIcon: {
		fontSize: '0.75rem'
	}, */
	firstAccordian: {
		borderRadius: '30px 30px 0 0',
		'& .MuiAccordionSummary-root':{
			borderRadius: '30px 30px 0 0',
		}
	},
	accordianExpanded: {
		margin: '0 !important'
	},
	accordianSummary:{
		background: '#F4F5F8',
		height: '69px'
	},
	accordianDetails:{
		padding: '0 20px'
	},
	heading: {
		fontSize: '16px',
		fontWeight: 600,
		fontStyle: 'normal',
		lineHeight: '23.5px'
	},
}));

export const AccountOptions = ({activeAccountDetails}) =>{
	const classes = useStyles();

	return (
		<div className={`${classes.container} ${cardTypeBackgroundMap[activeAccountDetails.type]}`}>
			<Accordion 
				defaultExpanded={true} 
				expanded={true} 
				classes={{root: classes.firstAccordian, expanded: classes.accordianExpanded}} 
				square={true}
			>
				<AccordionSummary 
					aria-controls="panel1a-content"
					id="panel1a-header"
					classes={{root: classes.accordianSummary}}
				>
					<span className={classes.heading}>Accounts</span>
				</AccordionSummary>

				<AccordionDetails classes={{root: classes.accordianDetails}}>
					<List component="nav" aria-labelledby="accounts" className={classes.list}>
						<AccountOption text="Account Information"  />
						<AccountOption text="Statements"  />
					</List>
				</AccordionDetails>
			</Accordion>
				
			<Accordion 
				defaultExpanded={true} 
				expanded={true} 
				classes={{expanded: classes.accordianExpanded}}
			>
				<AccordionSummary 
					aria-controls="panel2a-content"
					id="panel2a-header"
					classes={{root: classes.accordianSummary}}
				>
					<span className={classes.heading}>Card</span>
				</AccordionSummary>
				<AccordionDetails classes={{root: classes.accordianDetails}}>
					<List component="nav" aria-labelledby="accounts" className={classes.list}>
						<AccountOption text="Card Information" />
						<AccountOption text="Change card Pin"  />
						<AccountOption text="Card Access"  />
						<AccountOption text="ReIssue Card" />
						<AccountOption text="Increase Limit" />
					</List>
				</AccordionDetails>
			</Accordion>
		</div>
	)
}