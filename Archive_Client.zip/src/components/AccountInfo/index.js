import React from 'react';
import {AccountInformation} from './AccountInformation';
import {AccountOptions} from './AccountOptions'
import './accountinfo.css';

export const AccountInfo = ({activeAccountDetails, onBackBtnClick}) => {
	return (
		<div className="accountDetails-continer borderon450">
		<AccountInformation 
			onBackBtnClick={onBackBtnClick} 
			activeAccountDetails={activeAccountDetails}
		/>
		<AccountOptions activeAccountDetails={activeAccountDetails}/>
		</div>
	);
}
