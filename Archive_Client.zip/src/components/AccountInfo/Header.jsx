import React from 'react';
import goback from '../../assets/Header/Left.svg';

export const Header = ({ onBackBtnClick, backImgSrc = goback }) => {
    return (
        <React.Fragment>
        <div className="accInfo-header">
            <img src={backImgSrc} alt="Back" onClick={() =>{ onBackBtnClick(false) }}/>
        </div>
        </React.Fragment>
    )
}