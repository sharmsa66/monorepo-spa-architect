import React from 'react';
import { useHistory } from "react-router-dom";
import transDeny from '../../assets/SendMoney/TransactionDenied.svg';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
    root: {
        textAlign:'right',
        paddingTop: '48px',
        paddingRight: '20px'
    },
    continueButtonRoot:{
        borderRadius:'18px',
        height: '36px',
    },
   
    continueLabel:{color:'#FFFFFF'},
    contained:{
      background:'#0075BE',
      '&:hover':{
        background: '#005587'
      },
      '&:focus':{
        background: '#005587',
        boxShadow: '0 0 0 2px #BEDCEB, 0 0 0 3px #005587',
        outline: 0
      }
    }
  }));

const LoginDeny = () => {
    const classes= useStyles();
    const history = useHistory();
 return (
        <div className="success-screen">
        
            <div style={{padding:'100px 20px 40px 20px', display:'flex'}}>
                <img src={transDeny} alt="Denied" style={{margin: '0 auto'}} />
            </div>
        <div style={{paddingLeft:'20px', paddingRight:'20px'}}>
            
            <div style={{fontSize:'18px', fontWeight:'500',color: '#0075BE', lineHeight:'26.44px', }}>Give us a ring to get in.</div>
            <div style={{fontSize: '16px',  fontWeight: 400}}>
            Sorry, you are not authorized to login right now.
            </div>
            <div style={{paddingTop:'20px'}}>Give us a call and we’ll sort this out:</div>
            <div style={{color: '#0075BE'}}>1-877-570-3644</div>
        

            <div style={{paddingTop:'20px'}}> Outside Canada and the continental U.S, please call us collect at:</div>
            <div style={{color: '#0075BE'}}>416-355-8839</div>
            </div>
           <div className={classes.root}>
            <Button variant="contained"
                classes={{root:classes.continueButtonRoot, label:classes.continueLabel, contained:classes.contained}}
                onClick={()=> history.push('/')} >
                Go Back
            </Button>
            </div>
           
        </div>
    )

}

export default LoginDeny;