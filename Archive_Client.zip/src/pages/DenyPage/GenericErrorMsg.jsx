import React from 'react';
import { HeaderComp } from '../../components/HeaderComp';
// import {ActionButtons} from '../../components/ActionButtons';
import { useHistory } from "react-router-dom";
import close from '../../assets/Header/Close.svg';
import transError from '../../assets/SendMoney/TransactionError.svg';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { useSelector } from "react-redux";

const useStyles = makeStyles((theme) => ({
    root: {
        textAlign:'right',
        paddingTop: '48px',
        paddingRight: '20px'
    },
    continueButtonRoot:{
        borderRadius:'18px',
        height: '36px',
    },
   
    continueLabel:{color:'#FFFFFF'},
    contained:{
      background:'#0075BE',
      '&:hover':{
        background: '#005587'
      },
      '&:focus':{
        background: '#005587',
        boxShadow: '0 0 0 2px #BEDCEB, 0 0 0 3px #005587',
        outline: 0
      }
    }
  }));

const GenericErrorMsg = () => {
    const classes= useStyles();
    const history = useHistory();
    const profile = useSelector((state) => state.landing.profile);

    const { firstName='', lastName='' } = profile;
    const name = `${firstName} ${lastName}`;
 return (
        <div className="success-screen">
            <HeaderComp onBackBtnClick={()=>history.push({ pathname: '/'})}
             backImgSrc={close} 
             name= {name}
             />

            <div style={{padding:'100px 20px 40px 20px', display:'flex'}}>
                <img src={transError} alt="Denied" style={{margin: '0 auto'}} />
            </div>
        <div style={{paddingLeft:'20px', paddingRight:'20px'}}>
            
            <div style={{fontSize:'18px', fontWeight:'500',color: '#0075BE', lineHeight:'26.44px', }}>Sorry, Something went wrong!</div>
            
            <div style={{paddingTop:'20px'}}> Give us a call and we’ll sort this out:</div>
            <div style={{color: '#0075BE'}}>1-877-570-3644</div>
        

            <div style={{paddingTop:'20px'}}> Outside Canada and the continental U.S, please call us collect at:</div>
            <div style={{color: '#0075BE'}}>416-355-8839</div>
            </div>
           <div className={classes.root}>
            <Button variant="contained"
                classes={{root:classes.continueButtonRoot, label:classes.continueLabel, contained:classes.contained}}
                onClick={()=> history.push('/')} >
                Try Again
            </Button>
            </div>
           
        </div>
    )

}
export default GenericErrorMsg;