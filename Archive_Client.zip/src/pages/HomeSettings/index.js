import React, { useEffect, useState } from "react";

import { createSelector } from "@reduxjs/toolkit";
import { useHistory } from "react-router-dom";
import { AccountsOrder } from "./AccountsOrder";
import { AccountTransactionsPreference } from "./AccountTransactionsPreference";
import "./HomeSettings.css";
import ErrorComponent from "../../components/Error.component";
import { Loader } from "../../components/Loader";
import { HeaderComp } from "../../components/HeaderComp";
import { useSelector, useDispatch } from "react-redux";
import { fetchAccountSummary } from "../LandingPage/landingSlice";

const selectAccounts = createSelector((state) => state.accounts);

const HomeSettings = (props) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [showErrorComponent, setShowErrorComponent] = useState(false);

  const accounts = useSelector((state) => state.landing.accounts);
  const profile = useSelector((state) => state.landing.profile);
  const loading = useSelector((state) => state.landing.loading);

  useEffect(() => {
    fetchData();
    async function fetchData() {
      try {
          dispatch(fetchAccountSummary());
      } catch (error) {
          setShowErrorComponent(true);
          console.error(error);
      }
    }
  }, [dispatch]);

  if (accounts.length > 0) {
    const { firstName = "", lastName = "" } = profile;
    const name = `${firstName} ${lastName}`;

    return (
      <div id="settings-container" className="borderon450">
        {accounts.length > 0 && (
          <React.Fragment>
            <HeaderComp
              heading="Home Settings"
              name={name}
              onBackBtnClick={() => history.push({ pathname: "/" })}
              bgColor="#F0F0F0"
            />
            <AccountsOrder accounts={accounts} />
            <AccountTransactionsPreference accounts={accounts} />
          </React.Fragment>
        )}
        {showErrorComponent && <ErrorComponent />}
        {loading && <Loader />}
      </div>
    );
  }
};

export default HomeSettings;
