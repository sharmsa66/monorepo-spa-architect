import React from 'react';
import AccountTransactions from './TransactionsDropDown';


export const AccountTransactionsPreference = ({accounts}) =>{
    
     return (
      <div className="account-trans-preference">
          <div style={{fontSize:'16px', fontWeight:'500', padding:'20px 20px 12px 20px', backgroundColor: '#f0f0f0'}}>Viewing Account Transactions</div>
          <div style={{ paddingTop: '10px'}}>
          {accounts.map(({name, maskedAccountNumber, numberOfTransaction}) => <AccountTransactions key={name} accountName={name} maskedacctNumber={maskedAccountNumber} defaultTransaction={numberOfTransaction} />)}
          </div>
      </div>
        
     )
 }