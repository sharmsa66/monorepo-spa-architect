import React from 'react';
import {Account} from './Account'


export const AccountsOrder = ({accounts}) =>{
    
     return (
      <div className="account-order">
          <div style={{fontSize:'16px', fontWeight:'500', padding:'20px 20px 9px', backgroundColor: '#f0f0f0'}}>I want to see</div>
          {accounts.map(({name, maskedAccountNumber}) => <Account key={name} accountName={name} maskedacctNumber={maskedAccountNumber}/> )}
      </div>
        
     )
 }