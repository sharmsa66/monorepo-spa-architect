import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Select from 'react-dropdown-select'
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

const useStyles = makeStyles(() => ({
  rootDropDown:{
    width: '36px !important',
    height:'24px !important'
  }
}));

export default function DropDown({defaultValue = '', options =[], searchable=false, rootDivClass, onChange}) {
  const classes = useStyles();

  const handleChange = (selectedVal) => {
    if(selectedVal.length){
      onChange(selectedVal[0].value)
    }
  };
 
  function getSelectedVal(){
    const val = options.find(opt => opt.value === defaultValue);
    return val ? [val]: []
  }

  return (
    <div className={rootDivClass}>
        <Select
          className="transactions-count-dropdown"
          options={options}
          values={getSelectedVal()}
          multi={false}
          dropdownGap={0}
          // dropdownHandleRenderer={()=>}
          //dropdownPosition="auto"
          searchable={searchable}
          onChange={(value) => handleChange(value) }
          dropdownHandleRenderer={({ state }) =>  <React.Fragment>{state.dropdown
             ? <ExpandLessIcon fontSize="large" classes={{root:classes.rootDropDown}}/> 
             : <ExpandMoreIcon fontSize="large" classes={{root:classes.rootDropDown}}/>}
             </React.Fragment>}
        />
    </div>
  );
}
