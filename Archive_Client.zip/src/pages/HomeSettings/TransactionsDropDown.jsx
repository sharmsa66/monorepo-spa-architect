import React from 'react';
import Dropdown from './Dropdown';

export default function AccounttransactionsSelect(props) {
	const options = [{
		value:5,
		label: 'Last 5 Transactions'
	},{
		value:10,
		label: 'Last 10 Transactions'
	},{
		value:15,
		label: 'Last 15 Transactions'
	},{
		value:20,
		label: 'Last 20 Transactions'
	},{
		value:25,
		label: 'Last 25 Transactions'
	},{
		value:30,
		label: 'Last 30 Transactions'
	}]
	
	return (
		<div style={{padding: '10px 0'}}>
			<div style={{paddingTop: '20px', display:'flex', padding: '0 20px', justifyContent:'space-between'}}>
			<span style={{color:'#0075BE', fontWeight:'500', fontSize:'16px'}}>{props.accountName}</span>
			<span>{props.maskedacctNumber}</span>
			</div>
			<Dropdown defaultValue={props.defaultTransaction} options={options} rootDivClass="homeSettingsDropDown"/>
		</div>
	);
}
