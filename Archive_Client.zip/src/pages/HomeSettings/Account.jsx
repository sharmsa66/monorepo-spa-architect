import React from 'react';
import MoreHorizSharpIcon from '@material-ui/icons/MoreHorizSharp';
import removeacct from '../../assets/HomeSetting/RemoveAcct.svg';


export const Account = (props) =>{
    
     return (
         <div className="account-wrapper">
            <img src={removeacct} alt="Remove Account" className="acc-removeIcon"/>
            <div className="acc-details-container">
                <div className="account-details">
                    <span>{props.accountName}</span>
                    <span>{props.maskedacctNumber}</span>
                </div>
                <div className="acc-more">
                <MoreHorizSharpIcon />
                </div>
            </div>
            
       </div>
               
     )
 }