
import bell from '../../assets/PayeeIcons/Bell.svg';
import bmo from '../../assets/PayeeIcons/BMO.svg';
import rogers from '../../assets/PayeeIcons/RogersPaygo.svg';
import hydro from '../../assets/PayeeIcons/TorontoHydro.svg';

export function payeeIconMap(name){
    if(String(name).toLowerCase().includes('bmo')){
        return bmo;
    }
    if(String(name).toLowerCase().includes('hydro')){
        return hydro;
    }
    if(String(name).toLowerCase().includes('rogers')){
        return rogers;
    }
    if(String(name).toLowerCase().includes('bell')){
        return bell;
    }
}