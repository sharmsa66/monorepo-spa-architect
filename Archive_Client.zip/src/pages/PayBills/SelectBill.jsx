import React, { useState, useEffect } from "react";
import { Selectpayee } from "./Selectpayee";
import { BillList } from "./BillList";
import { useDispatch, useSelector } from "react-redux";
import { fetchCustomerPayees } from "./paybillSlice";

export const SelectBill = ({
  onBillSelect,
  selectedPayee,
  setSelectedPayee,
  setShowLoader
}) => {
  const [showSelectBill, setShowSelectBill] = useState(false);
  const loading = useSelector((state) => state.payment.loading);
  function handleSelectedPayee(selectedPayeeDetails) {
    setShowSelectBill(false);
    setSelectedPayee(selectedPayeeDetails);
    onBillSelect(selectedPayeeDetails);
  }

  const dispatch = useDispatch();
  const payees = useSelector((state) => state.payment.payees);

  useEffect(() => {
      setShowLoader(loading);
  });

  useEffect(() => {
      if (!payees) {
          fetchPayees();
      }
      async function fetchPayees() {
          try {
              dispatch(fetchCustomerPayees());
              setShowLoader(true);
          } catch (error) {
              console.error(error);
          }
      }
  }, []);

  return (
    <React.Fragment>
      {showSelectBill && payees ? (
        <BillList
          onSelectPayee={(selectedPayeeDetails) =>
            handleSelectedPayee(selectedPayeeDetails)
          }
          headerHeading="Choose your payee"
          onBackBtnClick={() => setShowSelectBill(false)}
          payees={payees}
        />
      ) : (
        <div className="bill-input-container">
          <span className="bill-input-header-span"> Pay To</span>
          <Selectpayee
            selectedPayee={selectedPayee}
            onActionClick={() => setShowSelectBill(true)}
          />
        </div>
      )}
    </React.Fragment>
  );
};
