import { 
    createAsyncThunk,
    createSlice,
    createSelector
} from '@reduxjs/toolkit';

import {
    payBill,
    getCustomerPayees
} from "../../services/data-adapter/api";

export const fetchCustomerPayees = createAsyncThunk(
    "payment/fetchCustomerPayees",
    async() => {
        const response = await getCustomerPayees();
        return response;
    }
)

export const makeBillPayment = createAsyncThunk(
    "payment/makeCustomerPayment",
    async(bill) => {
        const response = await payBill(bill);
        return response;
    }
)

export const paymentSlice = createSlice({
    name: "payment",
    initialState: {
        payees: null,
        loading: false
    },
    reducers: {},
    extraReducers: {
        [fetchCustomerPayees.pending]: (state) => {
            state.loading = true;
        },
        [fetchCustomerPayees.fulfilled]: (state,action) => {
            state.payees = action.payload;
            state.loading = false;
        },
        [makeBillPayment.pending]: (state) => {
            state.loading = true;
        },
       [makeBillPayment.fulfilled]: (state,action) => {
           state.loading = false;
       }
    }

});

export default paymentSlice.reducer;