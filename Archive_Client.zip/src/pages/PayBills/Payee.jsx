import React from "react";

export const Payee = (props) => {
  return (
    <div className="payee-container" onClick={props.onSelect}>
      <div className="temp-circle-icon">
        <img
          src={props.imgSrc}
          style={{ width: "30px", height: "30px", marginLeft: "7px" }}
        />
      </div>
      <div className="payee-details">
        <div className="payee-name">
          {props.payeeNickName.slice(0, 15)}
          {props.payeeName.length > 10
            ? ` (${props.payeeName.slice(0, 10)}...)`
            : ` (${props.payeeName})`}
        </div>
        <div>{props.customerAccountNumber}</div>
        {/* <div>{`Last paid $${props.lastPaidAmount} on ${props.lastpaidDate}`}</div> */}
      </div>
    </div>
  );
};
