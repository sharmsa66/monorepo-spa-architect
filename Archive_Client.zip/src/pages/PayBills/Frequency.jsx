import React from 'react';
import { SelectInput } from '../../components/SelectInput';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
    textClass: {
      fontWeight: 'normal'
    }
  });

export const Frequency = (props) => {
    const classes = useStyles();
    return (
        <div className="bill-input-container">
            <span className="bill-input-header-span">Frequency</span>
        <SelectInput navigation="addNewPayee" text="Once" textClass={classes.textClass} />
        </div>
    )

}