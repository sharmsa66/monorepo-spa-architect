import React, { useEffect, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import { Carousel } from "../../components/Carousel";
import ErrorComponent from "../../components/Error.component";
import { Loader } from "../../components/Loader";
import "../LandingPage/NewLandingPage.css";
import "./paybills.css";
import { SelectBill } from "./SelectBill";
import { AmountInput } from "../../components/AmountInput";
import { Frequency } from "./Frequency";
import { DateInput } from "./Dateinput";
import { ActionButtons } from "../../components/ActionButtons";
import { HeaderComp } from "../../components/HeaderComp";
import { ReviewBill } from "./ReviewBill";
import date from "date-and-time";
import { useSelector } from "react-redux";

const PayBills = (props) => {
  const [showloader, setShowLoader] = useState(true);
  const [showErrorComponent, setShowErrorComponent] = useState(false);
  const [showReviewBill, setShowReviewBill] = useState(false);
  const [proceedToConfirmation, setProceedToConfirmation] = useState(false);
  const [activeAccountDetails, setActiveAccountDetails] = useState({
    accountNumber: "",
    accountName: "",
    accBalance: "",
  });
  const [curentSlide, setCurentSlide] = useState(0);
  const [selectedPayee, setSelectedPayee] = useState(null);
  const [amount, setAmount] = useState("0.00");
  const pattern = date.compile("MMMM DD, YYYY");
  const dt = date.format(new Date(), pattern);
  const [initalized, setInitialized] = useState(false);
  const [selectedBillDetails, setSelectedBillDetails] = useState({
    selectedPayeeDetails: {},
    amount: "0.00",
    frequency: "Once",
    date: dt,
  });
  const history = useHistory();
  const location = useLocation();
  const accounts = useSelector((state) => state.landing.accounts);
  const profile = useSelector((state) => state.landing.profile);

  if (!initalized) {
    const state = location.state ? location.state : {};
    const {
      showReviewBill = false,
      selectedAccountDetails = {
        accountNumber: "",
        accountName: "",
        accBalance: "",
        source: "",
        currency: ""
      },
      selectedBillDetails = {
        selectedPayeeDetails: {},
        amount: "0.00",
        frequency: "Once",
        date: dt,
      },
    } = state;
    setShowReviewBill(showReviewBill);
    setProceedToConfirmation(showReviewBill);
    setActiveAccountDetails(selectedAccountDetails);
    setSelectedBillDetails(selectedBillDetails);
    handleActiveAccountdetails(accounts, profile);
    setInitialized(true);
    setShowLoader(false);
  }

  function handleActiveAccountdetails(totalAccounts, profile) {
    const filteredChequingAccounts = totalAccounts.filter(
      (account) => account.type !== "Saving"
    );
    const accounts = filteredChequingAccounts.map((account) => {
      return {
        ...account,
        name: account.name.replace("BMO", ""),
      };
    });
    const { accountNumber = "" } = props.activeSlidedetails;
    let currentSlide = accounts.findIndex(
      (acc) => acc.accountNumber === accountNumber
    );
    currentSlide = currentSlide < 0 ? 0 : currentSlide;
    setCurentSlide(currentSlide);
    setActiveAccountDetails({
      accountNumber: accounts[currentSlide].accountNumber,
      maskedAccountNumber: accounts[currentSlide].maskedAccountNumber,
      accountName: accounts[currentSlide].name,
      accBalance: accounts[currentSlide].balance,
      source: accounts[currentSlide].source,
      currency: accounts[currentSlide].currency
    });
  }

  function payAnotherBill() {
    setSelectedBillDetails({});
    setSelectedPayee(null);
    setAmount("0.00");
    setShowReviewBill(false);
  }

  function onAccountChange(
    { accountNumber, balance, name, maskedAccountNumber },
    currentSlide
  ) {
    setCurentSlide(currentSlide);
    setActiveAccountDetails({
      accountNumber,
      maskedAccountNumber,
      accountName: name,
      accBalance: balance,
      source: accounts[currentSlide].source,
      currency: accounts[currentSlide].currency
    });
  }

  const { selectedPayeeDetails = {} } = selectedBillDetails;
  const { firstName = "", lastName = "" } = profile; // accountData.profile;
  const name = `${firstName} ${lastName}`;
  return (
    <div id="paybills-container" className="borderon450">
      {showloader && !showReviewBill && <Loader />}
      <div>
        <HeaderComp
          heading="Pay Bill"
          profile={profile}
          name={name}
          onBackBtnClick={() => history.push({ pathname: "/" })}
        />
        {profile && (
          <React.Fragment>
            <Carousel
              accounts={accounts}
              onAccountSlide={onAccountChange}
              show={true}
              curentSlide={curentSlide}
              carouseHeading="Pay From"
              carouselDiv="payFrom"
            />
            <SelectBill
              onBillSelect={(selectedPayeeDetails) =>
                setSelectedBillDetails({
                  ...selectedBillDetails,
                  selectedPayeeDetails
                })
              }
              selectedPayee={selectedPayee}
              setSelectedPayee={setSelectedPayee}
              setShowLoader={setShowLoader}
            />
            <AmountInput
              amount={amount}
              setAmount={setAmount}
              onAmountInpt={(amount) =>
                setSelectedBillDetails({ ...selectedBillDetails, amount })
              }
            />
            <DateInput
              onDateInput={(date) =>
                setSelectedBillDetails({ ...selectedBillDetails, date })
              }
            />
            <Frequency
              onFrequencyInput={(frequency) =>
                setSelectedBillDetails({ ...selectedBillDetails, frequency })
              }
            />
            <ActionButtons
              proceedBtnText="Continue"
              abortBtnText="Cancel"
              disableProceedBtn={
                !Boolean(selectedPayeeDetails.billerId && Number(amount) > 0)
              }
              proceedBtnAction={() => setShowReviewBill(true)}
              abortBtnAction={() => history.push({ pathname: "/" })}
            />
          </React.Fragment>
        )}
        {showReviewBill && (
          <ReviewBill
            onBackBtnClick={() => setShowReviewBill(false)}
            selectedAccountDetails={activeAccountDetails}
            payAnotherBill={() => payAnotherBill()}
            selectedBillDetails={selectedBillDetails}
            proceedConfirmation={proceedToConfirmation}
            name={name}
          />
        )}
        {showErrorComponent && <ErrorComponent />}
      </div>
    </div>
  );
};

export default PayBills;
