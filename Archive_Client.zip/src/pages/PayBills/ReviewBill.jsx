import React, { useState, useEffect } from "react";
import { HeaderComp } from "../../components/HeaderComp";
import { ActionButtons } from "../../components/ActionButtons";
import { SuccessMsg } from "./SuccessMsg";
import { useHistory } from "react-router-dom";
import review from "../../assets/PayBills/Review.svg";
import { payeeIconMap } from "./util";
import arrow from "../../assets/PayBills/Arrow.svg";
import { Loader } from "../../components/Loader";
import { makeBillPayment } from "./paybillSlice";
import { unwrapResult } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";

export const ReviewBill = ({
	onBackBtnClick,
	selectedAccountDetails,
	payAnotherBill,
	selectedBillDetails,
	proceedConfirmation,
	name
}) => {
	const [showSuccessMsg, setshowSuccessMsg] = useState(false);
	const history = useHistory();
	const [showLoader, setShowLoader] = useState(false);
	const [billpaymentInit, setBillPaymentInit] = useState({});
	const { selectedPayeeDetails, amount, date, frequency } = selectedBillDetails;
	const dispatch = useDispatch();

	async function postBill({
		amount,
		billerId,
		payerAccountNumber,
		customerAccountNumber,
		source,
		currency
	}) {
		try {
			const bill = {
				payerAccountNumber,
				source,
				billerId,
				customerAccountNumber,
				amount,
				currency,
			};

			dispatch(makeBillPayment(bill))
			.then(unwrapResult)
			.then((data) => {
				setBillPaymentInit(data);
				setShowLoader(false);
				setshowSuccessMsg(true);
			});
		} catch (error) {
			setShowLoader(false);
			console.error(error);
		}
	}

	useEffect(() => {
		if (proceedConfirmation) {
			proceedToConfirmation();
		}
	}, [proceedConfirmation]);

	function proceedToConfirmation() {
		const {
			billerId,
			accountNumber: payerAccountNumber,
		} = selectedPayeeDetails;
		const { accountNumber } = selectedAccountDetails;
		const amountNumber = parseFloat(amount);
		setShowLoader(true);
		postBill({
			selectedPayeeDetails,
			amount: amountNumber,
			billerId,
			accountNumber,
			payerAccountNumber,
			customerAccountNumber: accountNumber,
			source: selectedAccountDetails.source,
			currency: selectedAccountDetails.currency
		});
	}

  return (
    <div className="review-bill">
      {showLoader && !showSuccessMsg && <Loader />}
      <HeaderComp
        heading="Review Bill"
        onBackBtnClick={onBackBtnClick}
        name={name}
      />
      <div
        className="review-bill-details lrPad20"
        style={showSuccessMsg ? { display: "none" } : {}}
      >
        <div className="review-icon">
          <img src={review} />
        </div>
        <div style={{ paddingTop: "40px" }}>
          <span style={{ display: "block", fontWeight: "500" }}>
            {selectedAccountDetails.accountName}
          </span>
          <span>{selectedAccountDetails.maskedAccountNumber}</span>
        </div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} />
        </div>
        <div>
          <div className="selected-payee-details">
            <div className="temp-img">
              {
                <img
                  src={payeeIconMap(selectedPayeeDetails.name)}
                  style={{ width: "30px", height: "30px", marginLeft: "7px" }}
                />
              }
              {/* <img src={payeeIconMap(selectedPayee.name)} style={{width:'30px', height:'30px', marginLeft:'7px'}}/> props.payeeName.length > 10 ? `(${props.payeeName.slice(0,10)}...)` :`(${props.payeeName})*/}
            </div>
            <div className="billSelected-details">
              <div style={{ fontWeight: "500", fontSize: "14px" }}>
                {selectedPayeeDetails.nickname.slice(0, 15)}
                {selectedPayeeDetails.name.length > 10
                  ? ` (${selectedPayeeDetails.name.slice(0, 10)}...)`
                  : ` (${selectedPayeeDetails.name})`}
              </div>
              <div>{selectedPayeeDetails.accountNumber}</div>
            </div>
          </div>
        </div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} />
        </div>
        <div className=" styleamount">{`$${Number(amount).toFixed(2)}`}</div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} />
        </div>
        <div>{date}</div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} />
        </div>
        <div>{frequency}</div>
      </div>
      <ActionButtons
        proceedBtnText="Confirm Payment"
        abortBtnText="Cancel"
        proceedBtnAction={() => proceedToConfirmation()}
        abortBtnAction={() => history.push({ pathname: "/" })}
      />
      {showSuccessMsg && (
        <SuccessMsg
          payAnotherBillAction={payAnotherBill}
          selectedBillDetails={selectedBillDetails}
          selectedAccountDetails={selectedAccountDetails}
          billpaymentInit={billpaymentInit}
          name={name}
        />
      )}
    </div>
  );
};
