import React from "react";
import { HeaderComp } from "../../components/HeaderComp";
import { AddAndSelect } from "../../components/AddAndSelect";
import { Payee } from "./Payee";
// import { useGlobalState } from "../../store/store";
import { useSelector } from 'react-redux';

import { payeeIconMap } from "./util";

export const BillList = ({
  onSelectPayee,
  payees,
  headerHeading,
  onBackBtnClick,
}) => {

  const profile = useSelector(state => state.landing.profile);
  const { firstName = "", lastName = "" } =  profile ; 
  const name = `${firstName} ${lastName}`;
  function addEditFlow(flow) {
    console.log(flow);
  }
  function selectedPayee(index) {
    onSelectPayee(payees[index]);
  }
  return (
    <div className="bill-list">
      <HeaderComp
        heading={headerHeading}
        onBackBtnClick={onBackBtnClick}
        name={name}
      />
      <div className="headerPad lrPad20">
        <AddAndSelect
          text="Add a new payee"
          flow="add"
          onAction={() => addEditFlow("addPayee")}
        />
        <AddAndSelect
          text="Select payee"
          flow="select"
          onAction={() => addEditFlow("SelectPayee")}
        />
        {payees.map((payee, index) => (
          <Payee
            payeeNickName={payee.nickname}
            payeeName={payee.name}
            customerAccountNumber={payee.accountNumber}
            // lastPaidAmount={payee.lastPaidAmount}
            imgSrc={payeeIconMap(payee.name)}
            // lastpaidDate={payee.lastPaidDate}
            onSelect={() => selectedPayee(index)}
          />
        ))}
      </div>
    </div>
  );
};
