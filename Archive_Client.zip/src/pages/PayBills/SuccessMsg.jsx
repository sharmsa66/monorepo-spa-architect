import React from 'react';
import { HeaderComp } from '../../components/HeaderComp';
import {ActionButtons} from '../../components/ActionButtons';
import { useHistory } from "react-router-dom";
import close from '../../assets/Header/Close.svg';
import success from '../../assets/PayBills/Success.svg';

export const SuccessMsg = ({payAnotherBillAction, selectedBillDetails, selectedAccountDetails, billpaymentInit, name}) => {
    const history = useHistory();
    const {selectedPayeeDetails, amount, date} = selectedBillDetails;
    const {accountName, maskedAccountNumber} = selectedAccountDetails
    return (
        <div className="success-screen">
            <HeaderComp heading="Confirmation" onBackBtnClick={()=>history.push({ pathname: '/'})} backImgSrc={close} name={name}/>

            <div className="success-icon lrPad20">
                <img src={success} alt="Success" />
            </div>
        <div className="lrPad20">
            
            <div className="success-msg">Success! You’re all set</div>
            <div className="bill-details-on-sp">
            {`You’ve paid $${Number(amount).toFixed(2)} to ${selectedPayeeDetails.name} from your ${accountName} Account ${maskedAccountNumber} on ${date}`}
            </div>

            <div className="confirm">{`Confirmation #${billpaymentInit.customerReferenceNumber}`}</div>
            </div>
           
            <ActionButtons proceedBtnText="All Done" abortBtnText="Pay another Bill"
            proceedBtnAction={()=>history.push({ pathname: '/'})}   abortBtnAction={payAnotherBillAction}/>

            <div style={{padding:'40px 20px'}}>
            Didn't mean to do that? 
            <span style={{textDecoration:'underline'}}><a id="hlink" href="/"> Cancel this payment.</a></span>

 
            </div>
        </div>
    )

}