import React from 'react';
import {SelectInput} from '../../components/SelectInput.jsx';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import { makeStyles } from '@material-ui/core/styles';
import {payeeIconMap} from './util'

const useStyles = makeStyles({
    iconselectinproot: {
      fontSize: '0.8rem',
      color:'#DCDCDC'
    },
    textClass: {
      fontWeight: 'normal'
    }
  });
export const Selectpayee = (props) =>{
    const classes = useStyles();
    return (
    <div className="select-input-container" >
    {props.selectedPayee === null ? <SelectInput navigation="addNewPayee"
     text="Select Payee" onActionClick={() => props.onActionClick(true)} textClass={classes.textClass}/>
     : <div className="selected-payee-container" onClick={() => props.onActionClick(true)}>
         <div className="selected-payee-details">
         <div className="temp-img">
         <img 
            src={payeeIconMap(props.selectedPayee.name)} 
            style={{width:'32px', height:'32px', marginLeft:'7px'}}
            alt='avatar'
         />
         </div>
      <div className="billSelected-details">
    <div>
    {props.selectedPayee.nickname.slice(0,15)}
    {props.selectedPayee.name.length > 10 ? ` (${props.selectedPayee.name.slice(0,10)}...)` : ` (${props.selectedPayee.name})`}
    </div>
    <div>{props.selectedPayee.accountNumber}</div>
      </div>
         </div>
      
     <ArrowForwardIosIcon classes={{root:classes.iconselectinproot}} />
      </div>}
    </div>
    )
}

