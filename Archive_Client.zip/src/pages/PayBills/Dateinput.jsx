import 'date-fns';
import React from 'react';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
  } from '@material-ui/pickers';
  import { makeStyles } from '@material-ui/core/styles';
  import date from 'date-and-time';

  const useStyles = makeStyles({
    dateInput: {
        width:'100%',
        borderBottom:'1px solid #DCDCDC !important',
      
    '& .MuiInput-underline:before':{
        display: 'none'
    },
    '& .MuiInputBase-root':{
      fontFamily: 'sans-serif',
      fontSize: '16px'
    }
    }
  });

export const DateInput = (props) =>{
    const classes = useStyles()
    const [selectedDate, setSelectedDate] = React.useState(new Date());

  const handleDateChange = (selectedDt) => {
    const pattern = date.compile('MMMM DD, YYYY')
    const dt = date.format(new Date(), pattern);
    props.onDateInput(dt);
    setSelectedDate(new Date());
  };
    return (
        <div className="bill-input-container">
            <span className="bill-input-header-span" style={{marginBottom:'0px'}}>Date</span>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
        
        <KeyboardDatePicker
          margin="normal"
          id="date-picker-dialog"
          format="MMMM dd, yyyy"
          value={selectedDate}
          minDate={new Date()}
          disablePast={true}
          onChange={handleDateChange}
          classes={{root:classes.dateInput}}
          KeyboardButtonProps={{
            'aria-label': 'change date',
          }}
        />
        
    </MuiPickersUtilsProvider>
         </div>
    )
}

