import React from 'react';
import { useHistory } from "react-router-dom";
import bmoLogo from '../../assets/NewLandingPage/BMOlogo.svg';
import logout from '../../assets/NewLandingPage/Logout.svg';

export const LogOut = () =>{
    const history = useHistory();

    const goBackToLanding = () => {
        history.push('/');
    };

    setTimeout(goBackToLanding, 5000);
    
    return (
    <div className="contianer-box borderon450" style={{padding:'20px'}}>
            <img className="header-logo" src={bmoLogo} alt="logo" />

            <div style={{paddingTop: '64px', textAlign: 'center', color: '#0075BE', fontSize: '24px', fontWeight: '500', paddingBottom: '14px'}}>Success!</div>
            <div style={{ fontSize:'16px', width:'228px', height:'89px', margin:'0 auto', textAlign:'center'}}>You have successfully logged out of your session.</div>
            
            <img src={logout} alt="loggedOut" style={{display:'block', margin:'0 auto'}} />
         

        <div style={{position:'absolute', bottom:'20px', fontSize:'16px', fontWeight:'500', color:'#0075BE', cursor:'pointer'}}
        onClick={goBackToLanding}>LOG IN</div>
    </div>
      
    )
}
export default LogOut;
