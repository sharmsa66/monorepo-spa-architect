import React from 'react';
//import MoreVertIcon from '@material-ui/icons/MoreVert';
import { NavMenu } from '../../components/NavMenu';
import bmoLogo from '../../assets/NewLandingPage/BMOlogo.svg';
import notification from '../../assets/Header/Notification.svg';
import bellwhite from '../../assets/Header/BellWhite.svg';
import { useTranslation } from 'react-i18next';
  
export const Header = (props) =>{
  const { t } = useTranslation();
  const [activeDrawer, setActiveDrawer] = React.useState(false);
  
  function getWishMessage(){
    const hours = new Date().getHours();
    if(hours >= 5 && hours < 12){
      return t('Morning Wish')
    } 
    if(hours >= 12 && hours< 18){
      return  t('Afternoon Wish')
    }
    if(hours >= 18 && hours <21){
      return t('Evening Wish')
      }
    return t('Hello')
  }
  const {firstName='', lastName=''} = props.profile;
   const name = `${firstName} ${lastName}`;
    return (
      <div className="simpleheader">
        <div className={`logo-msg ${props.hideName? 'visbilityHide' : '' }`}>
        <div>
          <img className="header-logo" src={bmoLogo} alt="logo" />
        </div>
        <span className="wishMsg">{`${getWishMessage()},`} <span className="firstName">{`${props.name.slice(0,15)}`}</span></span>
        </div>
        <div className="flex">
          {props.hideName? <img src={bellwhite} alt="Notifications" style={{paddingRight:'20px'}}/> : <img src={notification} alt="Notifications" style={{paddingRight:'20px'}}/>}
          <NavMenu activeDrawer={activeDrawer} name={name} setActiveDrawer={(val) => setActiveDrawer(val)} />
        </div>
        
      </div>
    )
}