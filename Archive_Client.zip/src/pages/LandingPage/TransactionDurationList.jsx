import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import filter from '../../assets/NewLandingPage/Filter.svg';
import { useTranslation } from 'react-i18next';

const StyledMenu = withStyles({
	paper: {
		border: '1px solid #d3d4d5',
	},
	root: {
		padding: '0px'
	}
})((props) => (
	<Menu
		elevation={0}
		getContentAnchorEl={null}
		anchorOrigin={{
		vertical: 'bottom',
		horizontal: 'right',
		}}
		transformOrigin={{
		vertical: 'top',
		horizontal: 'right',
		}}
		classes={{ root: 'transListMenu'}}
		{...props}
	/>
));

const StyledMenuItem = withStyles((theme) => ({
	root: {
		/* '&:focus': {
		backgroundColor: theme.palette.primary.main,
		'& .MuiListItemIcon-root, & .MuiListItemText-primary': {
			color: theme.palette.common.white,
		},
		}, */
		padding: '0px 5px',
		fontSize: '12px',
		minHeight: '27px'
	},
}))(MenuItem);

export const TransactionDurationList = ({fetchTransactions}) => {
	const { t } = useTranslation()
	const [anchorEl, setAnchorEl] = React.useState(null);

	const handleClick = (event) => {
		setAnchorEl(event.currentTarget);
	};

	const handleClose = (e) => {
		fetchTransactions(e.target.value)
		setAnchorEl(null);
	};

	return (
		<div>
			{/* <IconButton key="transDurations" onClick={handleClick}>
				<KeyboardArrowDownIcon fontSize="default" />
			</IconButton> */}
			<img src={filter} onClick={handleClick} alt='filter'/>
		<StyledMenu
			id="trans-durations"
			anchorEl={anchorEl}
			keepMounted
			open={Boolean(anchorEl)}
			onClose={handleClose}
		>
			<StyledMenuItem onClick={handleClose} value="10">
			{t("FilteredTransactions", {count: 10})}
			</StyledMenuItem>
			<StyledMenuItem onClick={handleClose} value="30">
			{t("FilteredTransactions", {count: 30})}
			</StyledMenuItem>
			<StyledMenuItem onClick={handleClose} value="60">
			{t("FilteredTransactions", {count: 60})}
			</StyledMenuItem>
		</StyledMenu>
		</div>
	);
}
