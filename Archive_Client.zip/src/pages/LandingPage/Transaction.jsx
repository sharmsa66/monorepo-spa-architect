import React from 'react';
import { numberWithCommas } from '../../util/util';
import date from 'date-and-time';


function formatDate(transactionDate) {
    return date.transform(transactionDate, 'YYYY-MM-DD', 'MMM DD, YYYY');
}



export const Transaction = ({transactionAmount, transactionname, transactionDate, type}) => {
    
    
    const amount = transactionAmount.toString();
    const isAmountNegative = amount.includes('-');
    const transAmount = isAmountNegative ? numberWithCommas(Number(amount.split('-')[1]).toFixed(2)) : numberWithCommas(Number(amount).toFixed(2));
   
    return (
        <div className="transaction">
       

            <div>
                <span className="trans-name">{transactionname}</span>
                <span className="trans-date">{formatDate(transactionDate)}</span>
            </div>
            <div className={`trans-amount ${isAmountNegative ? `${type === "CreditCard" ? 'cred-negative' : 'negative' }`:`${type === "CreditCard" ? 'cred-positive' : 'positive' }`}`}>
                {transAmount}
            </div>
        </div> 
    )
}