import React from 'react';
import { IconOption } from '../../components/IconOption';
import { Link } from "react-router-dom";


export const IconAction = ({linkTo, textLabel, imgSrc}) =>{
  return (
     <Link to={linkTo} >
     <IconOption 
      src={imgSrc}
      text={textLabel}
     /></Link>
     
  )
}