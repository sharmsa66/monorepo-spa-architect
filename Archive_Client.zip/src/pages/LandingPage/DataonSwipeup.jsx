import React from 'react';
import { numberWithCommas } from '../../util/util';
import Fade from '@material-ui/core/Fade';
import { useTranslation } from 'react-i18next';


export const DataonSwipeup= ({currentBalance='', accountName='',  maskedAccountNumber='',type='', show }) => {
    const { t } = useTranslation();
    const amount = currentBalance.toString();
    const isAmountNegative = amount.includes('-');
    const acctBalance = isAmountNegative ? numberWithCommas(Number(amount.split('-')[1]).toFixed(2)) : numberWithCommas(Number(amount).toFixed(2));
    
    return (
        <Fade in={show} {...(show ? { timeout: 1000 } : {})}>
        <div className={`swipeup-data ${show? 'show' : 'hide'}`}>
            <div className= "flex-space-btw">
            {accountName.length > 30?`${accountName.slice(0,26)}...` : accountName}
            {/* <div>****<span className="masked-acc-no">{`${accountNumber.slice(-4)}`}</span></div> */}
    <div><span className="masked-acc-no">{maskedAccountNumber}</span></div>
            </div>
            <div className="flex-space-btw">{type === "CreditCard" ?  t('Credit Balance') : t('BankAcct Balance')}<span className={`${isAmountNegative?'balnegative':'balpositive'}`}>{ acctBalance } </span></div> 
        </div>
        </Fade>
    )
}