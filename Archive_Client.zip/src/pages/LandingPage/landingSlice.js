import {
  createAsyncThunk,
  createSlice,
} from "@reduxjs/toolkit";

import {
  getAccountSummary,
  getFDXAccountSummary,
  getAccountTransactions,
  getFDXTransactions
} from  "@bmo/bmo-api"  ;  //"../../services/data-adapter/api";

export const fetchFDXAccountSummary = createAsyncThunk(
  "landing/fetchFDXAccountSummary",
  async (_, thunkAPI) => {
    const currentState = thunkAPI.getState();
    if (currentState.landing.accounts && currentState.landing.profile) {
      if(currentState.landing){
          return { ...currentState.landing , existing: true };
      } 
    } else {
      const response = await getFDXAccountSummary();
      return response;
    }
  }
);

export const fetchAccountSummary = createAsyncThunk(
  "landing/fetchAccountSummary",
  async (_, thunkAPI) => {
    const currentState = thunkAPI.getState();
    if (currentState.landing.accounts && currentState.landing.profile) {
      if(currentState.landing){
          return { ...currentState.landing , existing: true };
      } 
    } else {
      const response = await getAccountSummary();
      return response;
    }
  }
);

export const fetchFDXTransactions = createAsyncThunk(
  "landing/fetchFDXTransactions",
  async (transObj, thunkAPI) => {
    const { accountNumber, numTrans } = transObj;
    const currentState = thunkAPI.getState();
    let accountTransaction = currentState.landing.transactions.find(
      (acc) => acc[accountNumber]
    );
    if (accountTransaction) {
      return { ...accountTransaction, existing: true };
    } else {
      const transactionList = await getFDXTransactions( accountNumber, numTrans );
      return { [accountNumber]: transactionList };
    }
  }
);

export const fetchAccountTransactions = createAsyncThunk(
  "landing/fetchAccountTransactions",
  async (transObj, thunkAPI) => {
    const { accountType, accountNumber, accountSource, numTrans } = transObj;
    const currentState = thunkAPI.getState();
    let accountTransaction = currentState.landing.transactions.find(
      (acc) => acc[accountNumber]
    );
    if (accountTransaction) {
      return { ...accountTransaction, existing: true };
    } else {
      const transactionList = await getAccountTransactions(
        accountType,
        accountNumber,
        accountSource,
        numTrans
      );
      return { [accountNumber]: transactionList };
    }
  }
);

export const landingSlice = createSlice({
  name: "landing",
  initialState: {
    accounts: null,
    transactions: [],
    profile: null,
    loading: false,
    error: null
  },
  reducers: {
    restoreStorage: (state, action) => {
      state.accounts = action.payload.accounts;
      state.profile = action.payload.profile;
      state.transactions.push( action.payload.transactions);
    }
  },
  extraReducers: {
    [fetchAccountSummary.pending]: (state, action) =>{
       state.loading = true;
    },
    [fetchAccountSummary.fulfilled]: (state, action) => {
      if (!action.payload.existing) {
        state.accounts = action.payload.accounts;
        state.profile = action.payload.profile;
        state.transactions.push(action.payload.transactions);
      }
      state.loading =false;
    },
    [fetchAccountSummary.rejected]: (state, action) => {
      state.error = action.error;
      state.loading = false;
    },
    [fetchFDXAccountSummary.pending]: (state, action) =>{
       state.loading = true;
    },
    [fetchFDXAccountSummary.fulfilled]: (state, action) => {
      if (!action.payload.existing) {
        state.accounts = action.payload.accounts;
        state.profile = action.payload.profile;
        state.transactions = [];
      }
      state.loading = false;
    },
    [fetchFDXAccountSummary.rejected]: (state, action) => {
      state.error = action.error;
      state.loading = false;
    },
    [fetchAccountTransactions.pending]: (state, action) => {
      state.loading = true;
    },
    [fetchAccountTransactions.fulfilled]: (state, action) => {
      if (!action.payload.existing) {
        state.transactions.push(action.payload);
      }
      state.loading = false;
    },
    [fetchAccountTransactions.rejected]: (state, action) => {
      state.error = action.error;
      state.loading = false;
    }
  },
});


export const { restoreStorage }  = landingSlice.actions;

export default landingSlice.reducer;
