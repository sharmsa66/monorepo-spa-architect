import React from 'react';
import sendMoney from '../../assets/NewLandingPage/SendMoney.svg';
import transfer from '../../assets/NewLandingPage/Transfer.svg';
import deposit from '../../assets/NewLandingPage/Deposit.svg';
import payBills from '../../assets/NewLandingPage/payBills.svg';
// import statement from '../../assets/NewLandingPage/Statements.svg';
import {IconAction} from './IconAction';
import { useTranslation } from 'react-i18next';

export const IconMenu = ({show, actions, accountNumber}) =>{
  const { t } = useTranslation();

  const accountActions = (action) => {
  
    const accountActionsMap = {
      DepositTo: {
        linkTo: '/temp',
        textLabel: t('Deposit'),
        imgSrc: deposit
      },
      SendMoneyFrom: {
        linkTo: `/sendmoney?account=${accountNumber}`,
        textLabel: t('Send Money'),
        imgSrc: sendMoney
      },
      TransferFundsFrom: {
        linkTo: '/temp',
        textLabel: t('Transfer'),
        imgSrc: transfer
      },
      PayBillFrom:{
        linkTo: '/paybills',
        textLabel: t('Pay Bill'),
        imgSrc: payBills
      },
      // Statements:{
      //   linkTo: '/temp',
      //   textLabel: 'Statements',
      //   imgSrc: statement
      // }
    }
    return accountActionsMap[action];
  }
  return (
    <React.Fragment>
     {show && <div className = "icon-menu account-menu">
        {actions && actions.map((action) => {
          const {linkTo, textLabel, imgSrc} = accountActions(action)
          return <IconAction linkTo={linkTo} textLabel={textLabel} imgSrc={imgSrc} key={action}/>
        })}
     </div>}
    </React.Fragment>
  
  )
}