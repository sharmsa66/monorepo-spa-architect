import React, { useEffect, useLayoutEffect, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { unwrapResult } from "@reduxjs/toolkit";
import { useSwipeable } from "react-swipeable";
import { Header } from "./Header";
import { Carousel } from "../../components/Carousel";
import { DataonSwipeup } from "./DataonSwipeup";
import { IconMenu } from "./IconMenu";
import { Transactions } from "./Transactions";
import ErrorComponent from "../../components/Error.component";
import { Loader } from "../../components/Loader";
import { AccountInfo } from "../../components/AccountInfo";
import { cardTypeBackgroundMap } from "../../util/landingPageutil";
import "./NewLandingPage.css";
import "../../components/genericStyles.css";
import { fetchAccountSummary, fetchAccountTransactions } from "./landingSlice";

const LandingPage = (props) => {
  const [transactions, setTransactions] = useState([]);
  const [headerBgClass, setHeaderBgClass] = useState("bgGrey");
  const [transactionsToFetch, setTransactionsToFetch] = useState(null);
  const [showErrorComponent, setShowErrorComponent] = useState(false);
  const [activeAccountDetails, setActiveAccountDetails] = useState({});
  const [transactionsDown, setTransactionsDown] = useState(true);
  const [curentSlide, setCurentSlide] = useState(0);
  const [transactionsHeight, setTransactionsHeight] = useState(0);
  const [carouselHeight, setCarouselheight] = useState(0);
  const [windowHeight, setWindowHeight] = useState(0);
  const [showCarousel, setShowCarousel] = useState(false);
  const [showAccountInfo, setShowAccountInfo] = useState(false);
  const history = useHistory();
  const location = useLocation();
  const [refreshAccountId, setRefreshAccountId] = useState(
    location.state && location.state.refresh_account
      ? location.state.refresh_account
      : null
  );

  const dispatch = useDispatch();
  const accounts = useSelector((state) => state.landing.accounts);
  const profile = useSelector((state) => state.landing.profile);
  const reduxtransactions = useSelector((state) => state.landing.transactions);
  const loading = useSelector((state) => state.landing.loading);

   async function fetchTransactions(
    currAccountDetails,
    curSlide,
    transNumber = null
  ) {
    const {
      accountNumber,
      balance,
      name,
      type,
      source,
      actions,
      maskedAccountNumber,
      numberOfTransaction,
    } = currAccountDetails;

    try {
      let transCount = transNumber || numberOfTransaction;

      dispatch(
        fetchAccountTransactions({
          accountType: type,
          accountNumber,
          accountSource: source,
          numTrans: transCount,
        })
      ).then(unwrapResult)
        .then((transactions) => {
          setActiveAccountDetails({
            ...activeAccountDetails,
            numberOfTransaction,
            accountNumber,
            name: name,
            balance: balance,
            maskedAccountNumber,
            type,
            actions,
          });
          props.onSlideLoad(currAccountDetails);
          setTransactionsToFetch(transNumber);
          setTransactions(transactions[accountNumber]);
          setShowErrorComponent(false);
          setCurentSlide(curSlide);
        });
    } catch (error) {
      setShowErrorComponent(true);
      console.error(error);
    }
  }

  function fetchTransactionsOnDuration(count) {
    setTransactionsToFetch(count || transactionsToFetch);
  }

  useEffect(() => {
    if (activeAccountDetails.accountNumber) {
      fetchTransactions(activeAccountDetails, curentSlide, transactionsToFetch);
    }
  }, [transactionsToFetch]);

  useEffect(() => {
    if (!profile) {
      fetchData();
    }
    async function fetchData() {
        try {
          dispatch(fetchAccountSummary());
        } catch (error) {
          setShowErrorComponent(true);
        }
    }
  }, [dispatch]);

  useEffect(() => {
    if (accounts && accounts.length > 0) {
      const { accountNumber = "" } = props.activeSlidedetails;
      let currentSlide = accounts.findIndex(
        (acc) => acc.accountNumber === accountNumber
      );
      currentSlide = currentSlide < 0 ? 0 : currentSlide;
      if (currentSlide !== 0) {
        fetchTransactions(accounts[currentSlide], currentSlide);
      }
      setCurentSlide(currentSlide);
      setShowCarousel(true);
      const accountsMod = accounts.map((account) => {
        return {
          ...account,
          name: account.name.replace("BMO", "").trim(),
        };
      });
      props.onSlideLoad(accountsMod[currentSlide]);
      const {
        accountNumber: accNo,
        type,
        name,
        balance,
        actions,
        maskedAccountNumber,
        numberOfTransaction,
      } = accounts[currentSlide];
      const transactions = reduxtransactions.find((tran) => tran[accNo])[accNo];
      const trans = currentSlide === 0 ? transactions : [];
      setTransactions(trans);
      setActiveAccountDetails({
        numberOfTransaction,
        accountNumber: accNo,
        type,
        name,
        balance,
        actions,
        maskedAccountNumber,
      });
      setShowErrorComponent(false);
    }
  }, [accounts, profile]);

  useLayoutEffect(() => {
    const headerCarousel = document.getElementById("header-carousel");
    if (headerCarousel) {
      const height = headerCarousel.scrollHeight === 0 ? 361 : headerCarousel.scrollHeight;
      const transactionsHeight = window.innerHeight - height - 52;
      setCarouselheight(height - 1);
      setTransactionsHeight(transactionsHeight);
    }
  });

  const resizeWindow = () => {
    setWindowHeight(window.innerHeight);
  };

  useLayoutEffect(() => {
    resizeWindow();
    window.addEventListener("resize", resizeWindow);
    return () => window.removeEventListener("resize", resizeWindow);
  }, []);

  useLayoutEffect(() => {
    const headerCarousel = document.getElementById("header-carousel");
    if (headerCarousel) {
      const height = headerCarousel.scrollHeight ===0 ?  361 : headerCarousel.scrollHeight;
      const transHeight = window.innerHeight - height - 52;
      if (transactionsHeight !== transHeight) {
        setTransactionsHeight(transHeight);
      }
    }
  }, [windowHeight, transactionsHeight]);

  const swipeUpHandler = () => {
    const { type: cardtype } = activeAccountDetails;
    const headerClass = cardTypeBackgroundMap[cardtype];
    setHeaderBgClass(headerClass);
    setTransactionsDown(false);
  };
  const swipeDownHandler = () => {
    setHeaderBgClass("bgGrey");
    setTransactionsDown(true);
  };

  const handlers = useSwipeable({
    onSwipedUp: swipeUpHandler,
    onSwipedDown: swipeDownHandler,
    delta: 10,
    trackTouch: true,
    trackMouse: true,
  });

  const toggleAccInformation = () => {
    setShowAccountInfo(false);
  };

  return (
    <React.Fragment>
      {loading && <Loader />}
      {!showAccountInfo ? (
        <React.Fragment>
          {!showErrorComponent ? (
            <div className="contianer-box borderon450">
              {profile && (
                <div id="header-carousel" className={headerBgClass}>
                  <Header
                    name={profile.firstName}
                    profile={profile}
                    hideName={!transactionsDown}
                  />
                  {showCarousel && (
                    <Carousel
                      accounts={accounts}
                      onAccountSlide={fetchTransactions}
                      curentSlide={curentSlide}
                      show={transactionsDown}
                      showAccountInfo={toggleAccInformation}
                    />
                  )}
                  <DataonSwipeup
                    show={!transactionsDown}
                    accountName={activeAccountDetails.name}
                    currentBalance={activeAccountDetails.balance}
                    maskedAccountNumber={
                      activeAccountDetails.maskedAccountNumber
                    }
                    type={activeAccountDetails.type}
                  />
                  <IconMenu
                    accountType={activeAccountDetails.type}
                    actions={activeAccountDetails.actions}
                    show={transactionsDown}
                    accountNumber={activeAccountDetails.maskedAccountNumber}
                  />
                </div>
              )}
              {accounts && (
                <div
                  className={`transactions-slider ${headerBgClass}`}
                  style={{ top: `${carouselHeight}px` }}
                >
                  <Transactions
                    swipeUpTransactions={!transactionsDown}
                    transactions={transactions}
                    transactionCount={
                      transactionsToFetch ||
                      activeAccountDetails.numberOfTransaction
                    }
                    accountType={activeAccountDetails.type}
                    accountNumber={activeAccountDetails.accountNumber}
                    transactionsHeight={transactionsHeight}
                    fetchTransactions={fetchTransactionsOnDuration}
                    swipeHandlers={handlers}
                  />
                </div>
              )}
            </div>
          ) : (
            <ErrorComponent />
          )}
        </React.Fragment>
      ) : (
        <AccountInfo
          activeAccountDetails={activeAccountDetails}
          onBackBtnClick={toggleAccInformation}
        />
      )}
    </React.Fragment>
  );
};

export default LandingPage;
