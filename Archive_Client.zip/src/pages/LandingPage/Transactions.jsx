import React from 'react';
import { Transaction } from './Transaction';
import { TransactionDurationList } from './TransactionDurationList'
import { useTranslation } from 'react-i18next';

import { useSelector } from 'react-redux';
import { getTransactions, selectTransactions} from './landingSlice';

export const Transactions = ({accountType, transactions, swipeHandlers, transactionCount, 
    swipeUpTransactions, fetchTransactions, transactionsHeight, accountNumber}) => {
  const { t } = useTranslation();

    return (
        <div className="transactions-container">
            <div className="trans-header" {...swipeHandlers}>
            <div className="trans-duration">
                <span>{t("FilteredTransactions", {count: transactionCount})}</span>
            </div>
                <TransactionDurationList fetchTransactions={fetchTransactions}/>
            </div>

            
            <div className='trans-container' style={{maxHeight:`${transactionsHeight}px`}} > 
            {/* style={{height:`${transactionsHeight}px`}} */}
            {/* <div className={`trans-container ${swipeUpTransactions ? 'swiped-up' : ''}`}> */}
            {transactions.map((transaction, index) => <Transaction 
                key={index}
                type={accountType}
                
            transactionDate={transaction.postedDate} 
            transactionAmount={transaction.amount} 
            transactionname={accountType==="CreditCard"? transaction.merchantName:transaction.description}
            /> )}
            </div>
        </div>
    )
}