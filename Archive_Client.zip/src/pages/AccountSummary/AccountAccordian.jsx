import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import { numberWithCommas } from '../../util/util';

const useStyles = makeStyles({
  root: {
    width: '100%',
  },
  accordianSummaryContent:{
      display:'flex'
  },
  accountBar:{
    width: '4px',
    height: '44px',
    marginRight: '12px'
  },
  accBalance:{
    fontSize:'18px',
    fontWeight:700
  },
  accName:{
    fontSize:'15px',
    fontWeight: 500

  },
  accountIcon:{
    color: '#0075BE',
    marginLeft: '20px'
  },
  iconcolorStyle:{
      color: '#0075BE',
      fontSize:  '34px'
  },
  accordianDetails:{
      background: '#F5F6F7',
      display: 'block'
  },
  accDetailsWrapper:{
    display: 'flex',
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop:'20px',
    paddingBottom:'20px',
  },
  accDetails:{
      display: 'flex',
      width: '95%',
      flexDirection: 'column'
  },
  subAccDetails:{
      display: 'flex',
      width:'100%',
      justifyContent: 'space-between'
  }
});
const colorMap={
    Saving: '#0079C1',
    CreditCard: '#2CBFC1',
    Chequing: '#FFC700'
}

export default function AccountAccordian({type, balance, name, accountsGroup}) {
  const classes = useStyles();
  const isAmountNegative = (amount) => amount.toString().includes('-')
    const formatBalance = (val) => {
  const amount =val.toString();
    const bal = isAmountNegative(val) ? numberWithCommas(Number(amount.split('-')[1]).toFixed(2)) : numberWithCommas(Number(amount).toFixed(2));
    return bal
  }

  return (
    <div className={classes.root}>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon  classes={{root:classes.iconcolorStyle}}/>}
          aria-label="Expand"
          aria-controls="additional-actions1-content"
          id="additional-actions1-header"
        >
          <div className={classes.accordianSummaryContent}>
              <div className={classes.accountBar} style={{background: `${colorMap[type]}`}}></div>
              <div>
                  <div className={classes.accBalance}>
                  <span className={`${isAmountNegative(balance)?'balnegative':'balpositive'}`}>{formatBalance(balance)}</span> 
                    </div>
                  <div className={classes.accName}>{name}</div>
              </div>
          </div>
        </AccordionSummary>
        <AccordionDetails classes={{root: classes.accordianDetails}}>
            {accountsGroup.map(({maskedAccountNumber, name, balance}, index) => (<div className={classes.accDetailsWrapper} style={index+1 !==accountsGroup.length?{borderBottom:'1px solid #DCDCDC'}:{}}>
                <div className={classes.accDetails}>
                    <div className={classes.subAccDetails}>
                        <div>{name}</div>
                        <div>{maskedAccountNumber}</div>
                    </div>
                    <div className={classes.subAccDetails}>
                        <div>{type === "CreditCard" ? "Outstanding Balance" : "Availble Balance"}</div>
                        <div style={{color: '#0075BE'}}>
                        <span className={`${isAmountNegative(balance)?'balnegative':'balpositive'}`}>{ formatBalance(balance) }</span> 
                        </div>
                    </div>
                </div>
             <NavigateNextIcon classes={{root:classes.accountIcon}}/>
            </div>))}
        </AccordionDetails>
      </Accordion>
      
    </div>
  );
}
