import React, { useEffect, useState, useContext } from 'react';
import ErrorComponent from '../../components/Error.component';
import { Loader } from '../../components/Loader';
import '../LandingPage/NewLandingPage.css';
import './accSumm.css';
import {Header} from '../LandingPage/Header';
import { PieChart } from 'react-minimal-pie-chart';
import AccountAccordian from './AccountAccordian';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAccountSummary} from '../LandingPage/landingSlice';

const AccSumm = (props) => {
  const [showloader, setShowLoader] = useState(true);
  const [showErrorComponent, setShowErrorComponent] = useState(false);
  const [pieData, setPieData] = useState([]);
  const [totalValue, setTotalValue]=useState(0);
  const [CategorizedAccounts, setCategorizedAccounts] = useState([]);
  
 // const client = useContext(ClientContext);

  const accounts = useSelector(state => state.landing.accounts);
  const transactions = useSelector(state => state.landing.transactions);
  const profile = useSelector(state => state.landing.profile);
  const isAuth = useSelector(state => state.oAuth.isAuth);
  const isLoading = useSelector(state => state.landing.loading);

  const dispatch  = useDispatch();

  function updatePieData(accounts){
    const CategorizedAccounts = [];
    const chequing = {displayName:  'Chequing Accounts', totalValue:0, accounts:[], type:"Chequing"};
    const saving = { displayName: 'Saving Accounts', totalValue:0, accounts:[], type:"Saving"}
    const creditCards = {displayName: 'Credit Cards', totalValue:0, accounts:[], type: "CreditCard"}
    let totalValue =0;
            const piedata = accounts.map((el) => {
              const data = {value: el.balance};
              totalValue = totalValue + el.balance
              if(el.type === "Saving"){
                data.color = "#0079C1"
                saving.totalValue = saving.totalValue + el.balance;
                saving.accounts.push(el)
              }
              if(el.type === "CreditCard"){
                data.color = "#2CBFC1"
                data.value = -1 * el.balance
                creditCards.totalValue = creditCards.totalValue + el.balance;
                creditCards.accounts.push(el)
              }
              if(el.type === "Chequing"){
                data.color = "#FFC700"
                chequing.totalValue = chequing.totalValue + el.balance;
                chequing.accounts.push(el)
              }
              return data;
            });
            if(chequing.accounts.length > 0){
              CategorizedAccounts.push(chequing)
            }
            if(saving.accounts.length > 0){
              CategorizedAccounts.push(saving)
            }
            if(creditCards.accounts.length > 0){
              CategorizedAccounts.push(creditCards)
            }
            setCategorizedAccounts(CategorizedAccounts)
            setPieData(piedata);
            setTotalValue(totalValue);

  }

  useEffect(() => {
    if(!(accounts && ! profile)){
        fetchData()
      } else {
        updatePieData(accounts)
          setShowLoader(false);
      }
    async function fetchData() {
        try {
            if(isAuth) {
              dispatch(fetchAccountSummary());

              const accountsModified = accounts.map((account) => {
                  return {
                    ...account,
                    name: account.name.replace('BMO', '').trim()
                  }
              });
              updatePieData(accountsModified);
              // setAccountData({
              //     profile: profile,
              //     accounts
              // });
           //   setShowLoader(false)
              setShowErrorComponent(false);
            }
            
           
        } catch (error) {
            setShowErrorComponent(true)
            console.error(error);  
        }
    }
  }, [dispatch, accounts]);


//   const {firstName='', lastName=''} = accountData.profile;
//    const name = `${firstName} ${lastName}`;
  return (
    <div id="paybills-container" className="borderon450">
        {showloader &&<Loader />}
      <div>
        {profile && <React.Fragment>
            <Header profile={profile} name={profile.firstName} hideName={false}/>
           <div className="pieWrapper">
             <div className="accSum-subHead">Account Summary</div>
             <div className="donutChart">
           <PieChart
                data={pieData}
                lineWidth={30}
          // labelPosition={50}
          // startAngle={320}
          labelStyle={{
            fontSize: "4px",
            fill: "ffffff"
            }}
          style={{position:'relative'}}
           >
             
           </PieChart>
           </div>
           <div className="chart-inner-text">
          <p className="chart-inner-value">{`$${totalValue}`}</p>
          <p className="inner-text">Total Balance</p>
        </div>
           </div>
            </React.Fragment>
          }
        
        {showErrorComponent && <ErrorComponent />}
      </div>
      {CategorizedAccounts.map(({displayName, totalValue, type, accounts}) => <AccountAccordian balance={totalValue} 
      name={displayName} type={type} accountsGroup={accounts}/>)}
    </div>
  );
}

export default AccSumm;