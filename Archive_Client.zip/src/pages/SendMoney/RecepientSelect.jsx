import React from 'react';
import {SelectInput} from '../../components/SelectInput.jsx';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import { makeStyles } from '@material-ui/core/styles';
import {Recepient} from './Recepient'

const useStyles = makeStyles({
    iconselectinproot: {
      fontSize: '0.8rem',
      color:'#DCDCDC'
    },
    textClass: {
      fontWeight: 'normal'
    }
  });
export const RecepientSelect = ({selectedRecepient, onActionClick}) =>{
    const classes = useStyles();
    return (
    <div className="select-input-container" >
    {!selectedRecepient.recipientName ? <SelectInput 
     text="Select Recepient" onActionClick={() => onActionClick(true)} textClass={classes.textClass}/>
     : <div className="selected-payee-container" onClick={() => onActionClick(true)}>
         <div className="selected-payee-details">
          <Recepient name={selectedRecepient.recipientName} email={selectedRecepient.email} number={selectedRecepient.recipientHandle} selected={true}  />
    
         </div>
      
     <ArrowForwardIosIcon classes={{root:classes.iconselectinproot}} />
      </div>}
    </div>
    )
}

