import React from 'react';
import { HeaderComp } from '../../components/HeaderComp';
import { AddAndSelect } from '../../components/AddAndSelect';
import {Recepient} from './Recepient';
import { useSelector } from 'react-redux';


export const RecepientList = ({onSelectRecepient, recepients, headerHeading, onBackBtnClick}) => {
    // const globalState = useGlobalState();
    // const {accountSummary = {data: { profile:{} }}}= globalState.state;

    const profile = useSelector(state => state.landing.profile);
    const {firstName='', lastName=''} = profile
    const name = `${firstName} ${lastName}`;

    function addEditFlow(flow){
        console.log(flow);
    }
    function selectedRecepient(index){
        onSelectRecepient(recepients[index])
    }
    return (
        <div className="recepient-list">
            <HeaderComp heading={headerHeading} onBackBtnClick={onBackBtnClick} name={name}/>
            <div className="headerPad lrPad20">
            <AddAndSelect text="Add a Recepient" flow="add" onAction={() => addEditFlow('add')}/>
            <AddAndSelect text="Select Recepient" flow="select" onAction={() => addEditFlow('select')}/>
            {
                recepients.map((recepient, index) => 
                    <Recepient name={recepient.recipientName} 
                        email={recepient.email}
                        number={recepient.recipientHandle} 
                        key={index}
                        onSelect={() => selectedRecepient(index)}/>
                )
            }
            </div>
            
        </div> 
    )

}