import React, { useEffect, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import { Carousel } from "../../components/Carousel";
import ErrorComponent from "../../components/Error.component";
import { Loader } from "../../components/Loader";
import "../LandingPage/NewLandingPage.css";
import "./sendmoney.css";
import { SelectRecepient } from "./SelectRecepient";
import { AmountInput } from "../../components/AmountInput";
import { ActionButtons } from "../../components/ActionButtons";
import { HeaderComp } from "../../components/HeaderComp";
import { SecurityQues } from "./SecurityQues";
import { Message } from "./Message";
import { SendingFrom } from "./SendingFrom";
import { ReviewRecipientDetails } from "./ReviewRecipientDetails";
import { useSelector, useDispatch } from "react-redux";
import { fetchAccountSummary } from "../LandingPage/landingSlice";

const SendMoney = (props) => {
  const [showloader, setShowLoader] = useState(true);
  const [showErrorComponent, setShowErrorComponent] = useState(false);
  const [selectedRecepient, setSelectedRecepient] = useState({});
  const [proceedToConfirmation, setProceedToConfirmation] = useState(false);
  const [activeAccountDetails, setActiveAccountDetails] = useState({
    accountNumber: "",
    accountName: "",
    accBalance: "",
  });
  const [showReviewRecepient, setShowReviewRecepient] = useState(false);
  const [curentSlide, setCurentSlide] = useState(0);
  const [amount, setAmount] = useState("0.00");
  const [message, setMessage] = useState("");
  const [sendingFrom, setSendingFrom] = useState("nasim@bmo.com");
  const [initalized, setInitialized] = useState(false);
  const [selectedRecepientDetails, setSelectedRecepientDetails] = useState({
    recepientDetails: {},
    amount: "0.00",
  });
  const history = useHistory();
  const location = useLocation();
  const state = location.state ? location.state : {};
  let name = "";

  const accounts = useSelector((state) => state.landing.accounts);
  const profile = useSelector((state) => state.landing.profile);
  const loading = useSelector((state) => state.sendMoney.loading);
  const dispatch = useDispatch();

  if (!initalized) {
    const state = location.state ? location.state : {};
    const {
      message = "",
      selectedAccountDetails = {
        accountNumber: "",
        accountName: "",
        accBalance: "",
        source: "",
        currency: ""
      },
      selectedRecepientDetails = {
        recepientDetails: {},
        amount: "0.00",
      },
      showReviewRecepient = false,
    } = state;
    setShowReviewRecepient(showReviewRecepient);
    setMessage(message);
    setProceedToConfirmation(showReviewRecepient);
    setActiveAccountDetails(selectedAccountDetails);
    setSelectedRecepientDetails(selectedRecepientDetails);

    setInitialized(true);
    setShowLoader(showReviewRecepient);
  }

  function handleActiveAccountDetails(accounts, profile) {
    const filteredOutCreditAccounts = accounts.filter(
      (account) => account.type !== "CreditCard"
    );
    const { accountNumber = "" } = props.activeSlidedetails;
    let currentSlide = filteredOutCreditAccounts.findIndex(
      (acc) => acc.accountNumber === accountNumber
    );
    currentSlide = currentSlide < 0 ? 0 : currentSlide;
    setCurentSlide(currentSlide);

    setActiveAccountDetails({
      accountNumber: filteredOutCreditAccounts[currentSlide].accountNumber,
      maskedAccountNumber:
        filteredOutCreditAccounts[currentSlide].maskedAccountNumber,
      accountName: filteredOutCreditAccounts[currentSlide].name,
      accBalance: filteredOutCreditAccounts[currentSlide].balance,
      source: filteredOutCreditAccounts[currentSlide].source,
      currency: filteredOutCreditAccounts[currentSlide].currency
    });
  }

  useEffect(() => {
    handleActiveAccountDetails(accounts, profile);
  }, []);

  function sendToAnotherRecepient() {
    setSelectedRecepientDetails({ recepientDetails: {}, amount: "0.00" });
    setAmount("0.00");
    setMessage("");
    setSelectedRecepient({});
    setShowReviewRecepient(false);
  }

  function onAccountChange(
    { accountNumber, balance, name, maskedAccountNumber },
    currentSlide
  ) {
    setCurentSlide(currentSlide);
    setActiveAccountDetails({
      accountNumber,
      maskedAccountNumber,
      accountName: name,
      accBalance: balance,
      source: accounts[currentSlide].source,
      currency: accounts[currentSlide].currency
    });
  }

  //   const {selectedPayeeDetails = {}} = selectedBillDetails
  if (profile) {
    name = `${profile.firstName} ${profile.lastName}`;
  }

  return (
    <div id="sendmoney-container" className="borderon450">
      {showloader && !showReviewRecepient && <Loader />}
      <div>
        <HeaderComp
          heading="Send Money"
          name={name}
          onBackBtnClick={() => history.push({ pathname: "/" })}
        />
        {profile && (
          <React.Fragment>
            <Carousel
              accounts={accounts}
              onAccountSlide={onAccountChange}
              show={true}
              curentSlide={curentSlide}
              carouseHeading="Interac e-transfer from"
              carouselDiv="payFrom"
            />

            <SelectRecepient
              onRecepientSelect={(recepientDetails) =>
                setSelectedRecepientDetails({
                  ...selectedRecepientDetails,
                  recepientDetails,
                })
              }
              selectedRecepient={selectedRecepient}
              setShowLoader={setShowLoader}
              setSelectedRecepient={setSelectedRecepient}
            />
            {/* {Number(amount) > 5  && <ErrorCompFromErrObj  errorObject={{errorType:"error", errorMsg: 'Please enter the amount less than $5.00'}}/>} */}

            <AmountInput
              amount={amount}
              setAmount={setAmount}
              onAmountInpt={(amount) =>
                setSelectedRecepientDetails({
                  ...selectedRecepientDetails,
                  amount,
                })
              }
            />
            <SecurityQues selectedName={selectedRecepient.recipientName} />
            <Message message={message} setMessage={setMessage} />
            <SendingFrom sendingFrom={sendingFrom} />
            <ActionButtons
              proceedBtnText="Continue"
              abortBtnText="Cancel"
              disableProceedBtn={
                !Boolean(selectedRecepient.recipientName && Number(amount) > 0)
              }
              proceedBtnAction={() => setShowReviewRecepient(true)}
              abortBtnAction={() => history.push({ pathname: "/" })}
            />
          </React.Fragment>
        )}
        {showReviewRecepient && (
          <ReviewRecipientDetails
            onBackBtnClick={() => setShowReviewRecepient(false)}
            selectedAccountDetails={activeAccountDetails}
            selectedRecepientDetails={selectedRecepientDetails}
            message={message}
            sendingFrom={sendingFrom}
            name={name}
            proceedConfirmation={proceedToConfirmation}
            sendToAnotherRecepient={() => sendToAnotherRecepient()}
          />
        )}
        {showErrorComponent && <ErrorComponent />}
      </div>
    </div>
  );
};

export default SendMoney;
