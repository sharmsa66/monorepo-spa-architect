import {
  createAsyncThunk,
  createSlice,
} from "@reduxjs/toolkit";

import {
  eTransfer,
  getCustomerRecipients,
} from "../../services/data-adapter/api";

export const makeEtransfer = createAsyncThunk(
  "sendMoney/Etransfer",
  async (payment) => {
    const response = await eTransfer(payment);
    return response;
  }
);

export const fetchCustomerRecepients = createAsyncThunk(
  "sendMoney/fetchRecepients",
  async () => {
    const response = await getCustomerRecipients();
    return response;
  }
);

export const sendMoneySlice = createSlice({
  name: "sendMoney",
  initialState: {
    loading: false,
    error: null,
    recepients: [],
  },
  reducers: {},
  extraReducers: {
    [makeEtransfer.pending]: (state) => {
      state.loading = true;
    },
    [makeEtransfer.rejected]: (state) => {
      state.loading = false;
    },
    [makeEtransfer.fulfilled]: (state) => {
      state.loading = false;
    },
    [fetchCustomerRecepients.pending]: (state) => {
      state.loading = true;
    },
    [fetchCustomerRecepients.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.payload.error;
    },
    [fetchCustomerRecepients.fulfilled]: (state, action) => {
      state.loading = false;
      state.recepients = action.payload;
    },
  },
});

export default sendMoneySlice.reducer;
