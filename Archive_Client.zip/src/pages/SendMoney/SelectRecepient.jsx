import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { RecepientSelect } from "./RecepientSelect";
import { RecepientList } from "./RecepientList";
import { useDispatch, useSelector } from "react-redux";
import { fetchCustomerRecepients } from "./sendMoneySlice";

export const SelectRecepient = ({
  onRecepientSelect,
  selectedRecepient,
  setSelectedRecepient,
  setShowLoader,
}) => {
  const [showSelectRecepient, setShowSelectRecepient] = useState(false);
  const loading = useSelector((state) => state.sendMoney.loading);
  const error = useSelector((state) => state.sendMoney.error);
  const recepients = useSelector((state) => state.sendMoney.recepients);
  const dispatch = useDispatch();
  // const history = useHistory();
  function handleSelectedRecepient(selectedRecepientDetails) {
    setShowSelectRecepient(false);
    setSelectedRecepient(selectedRecepientDetails);
    onRecepientSelect(selectedRecepientDetails);
  }

  useEffect(() => {
      setShowLoader(loading);
  });

  useEffect(() => {
      if (recepients) {
          fetchRecepients();
      }

      async function fetchRecepients() {
          try {
              dispatch(fetchCustomerRecepients());
              setShowLoader(true);
          } catch (error) {
              console.error(error);
          }
      }
  }, []);

  return (
    <React.Fragment>
      {showSelectRecepient && recepients ? (
        <RecepientList
          onSelectRecepient={(selectedRecepientDetails) =>
            handleSelectedRecepient(selectedRecepientDetails)
          }
          headerHeading="Choose your recepient"
          onBackBtnClick={() => setShowSelectRecepient(false)}
          recepients={recepients}
        />
      ) : (
        <div className="bill-input-container">
          <span className="bill-input-header-span">Sending To</span>
          <RecepientSelect
            selectedRecepient={selectedRecepient}
            onActionClick={() => setShowSelectRecepient(true)}
          />
        </div>
      )}
    </React.Fragment>
  );
};
