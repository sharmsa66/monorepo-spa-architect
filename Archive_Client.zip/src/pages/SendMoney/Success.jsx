import React from 'react';
import { HeaderComp } from '../../components/HeaderComp';
import {ActionButtons} from '../../components/ActionButtons';
import { useHistory } from "react-router-dom";
import close from '../../assets/Header/Close.svg';
import success from '../../assets/SendMoney/SendMoneySuccess.svg';

export const Success = ({sendToAnotherRecepient, selectedRecepientDetails, selectedAccountDetails, etransferDetails, name}) => {
    const history = useHistory();
    const {recepientDetails, amount} = selectedRecepientDetails;
    const { accountNumber, accountName, maskedAccountNumber } = selectedAccountDetails;
    return (
        <div className="success-screen">
            <HeaderComp heading="Confirmation" name={name} onBackBtnClick={()=>history.push({ pathname: '/'})} backImgSrc={close} />

            <div className="success-icon lrPad20">
                <img src={success} alt="Success" />
            </div>
        <div className="lrPad20">
            
            <div className="success-msg">Success! You’re all set</div>
            <div className="bill-details-on-sp">
            {`You’ve sent $${Number(amount).toFixed(2)} to ${recepientDetails.recipientName} (${recepientDetails.recipientHandle}) from your ${accountName} Account ${maskedAccountNumber}`}
            </div>

            <div className="confirm">{`Confirmation # ${etransferDetails.customerReferenceNumber}`}</div>
            </div>
           
            <ActionButtons proceedBtnText="All Done" abortBtnText="Send Another Money"
            proceedBtnAction={()=>history.push({ pathname: '/', state: { refresh_account: accountNumber }})}   abortBtnAction={sendToAnotherRecepient}/>
        </div>
    )

}