import React from 'react';
import { SelectInput } from '../../components/SelectInput';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
    textClass: {
      fontWeight: 'normal',
      color: '#8D9096'
    },
    extendedTextClass:{
        color:'#0075BE',
        textDecoration:'underline'
    }
  });

export const SecurityQues = (props) => {
    const classes = useStyles();
    function onLinkClick(){
        console.log('clicked what does mean??')
    }
    return (
        <div className="bill-input-container">
            <span className="bill-input-header-span">Security Question</span>
        <SelectInput navigation="addNewPayee" 
            text={`${props.selectedName}. is registered for Autodeposit. You don’t need to set a security questions.`}
            textClass={classes.textClass}
            onLinkClick={() => onLinkClick()}
            hidetext={!props.selectedName}
            hideIcon={true}
            extendedTextClass={classes.extendedTextClass}
            extendedText="What does this mean?"/>
        </div>
    )

}