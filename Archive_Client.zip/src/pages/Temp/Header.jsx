import React from 'react';
import Logo from '../../assets/Logo.svg';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import { NavMenu } from '../../components/NavMenu';
import { Link } from "react-router-dom";
import './temp.css';

export const Header = () =>{
    const [activeDrawer, setActiveDrawer] = React.useState(false);
    
    return (
              <React.Fragment>
                <div className='headerContainer'>
                <div className="headerLogos">
                    <div className="backButtonWithLogo">
                    <Link to="/">
                    <ArrowBackIosIcon />
                    </Link>
                    <div>
                        <img className="header-logo" src={Logo} alt="logo" />
                    </div>
                    </div>
                    <div>
                        <NavMenu activeDrawer={activeDrawer} setActiveDrawer={(val) => setActiveDrawer(val)} />
                    </div>
                </div>
                </div>
              </React.Fragment>
            )
           
}