import React from 'react';
import { Header } from './Header';
import '../LandingPage/landingPage.css';
import CircularProgress from '@material-ui/core/CircularProgress';



const TempPage = () => {
  
    return (
        <div className="contianer-box borderon450">
          <Header/>
          <div className="alignCenterPage" style={{width: '120px'}}>
          <CircularProgress />
          <p style={{  position: 'relative',    marginLeft: '-57px'}}>Work in Progress...</p>
          </div>
        </div>
    )
}

export default TempPage;