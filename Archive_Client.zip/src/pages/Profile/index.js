import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import profileIcon from "../../assets/Profile/ProfileSmall.svg";
import { HeaderComp } from "../../components/HeaderComp";
import { useHistory } from "react-router-dom";
import { useTranslation } from "react-i18next";
import SubHeading from "./SubHeading";
import DropDown from "../HomeSettings/Dropdown";
import { InputText } from "./InputText";
import "./profile.css";
import { ActionButtons } from "../../components/ActionButtons";
import ErrorComponent from "../../components/Error.component";
import { Loader } from "../../components/Loader";
// import {Consent} from './Consent';
import { MyAccounts } from "./MyAccounts";
import { convertObjectToArray } from "../../util/util";
import { ContactMethod } from "./ContactMethod";
import { useSelector, useDispatch } from "react-redux";
import { fetchGetParty } from "./profileSlice";

const useStyles = makeStyles((theme) => ({
  container: {
    width: "100%",
    maxWidth: "450px",
    height: "100vh",
    margin: "0 auto",
  },
  list: {
    width: "100%",
    padding: 0,
    backgroundColor: theme.palette.background.paper,
  },
  fullName: {
    fontWeight: 500,
    marginTop: "20px",
    lineHeight: "23.5px",
  },
  firstAccordian: {
    // borderRadius: '30px 30px 0 0',
    // '& .MuiAccordionSummary-root':{
    //   borderRadius: '30px 30px 0 0',
    // }
  },
  accordianExpanded: {
    margin: "0 !important",
  },
  accordianSummary: {
    // background: '#F5F5F5',
    height: "60px",
  },
  accordianDetails: {
    background: "#f8f9fa",
    padding: "20px 20px 0 20px",
    display: "block",
  },
  profileDropDown: {
    padding: "10px 0",
  },
  accordianWrapper: {
    overflowY: "auto",
    height: window.innerHeight - 300 + "px",
  },
  subHeadingSpan: {
    display: "block",
    marginTop: "25px",
    fontSize: "16px",
    fontWeight: "500",
  },
  heading: {
    fontSize: "16px",
    fontWeight: 600,
    fontStyle: "normal",
    lineHeight: "23.5px",
  },
  actionButtonsRoot: {
    position: "fixed",
    width: "100%",
    height: "60px",
    display: "flex",
    alignItems: "center",
    maxWidth: "448px",
    justifyContent: "flex-end",
    background: "white",
    bottom: 0,
    boxShadow:
      "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    "& > *": {
      margin: theme.spacing(1),
    },
  },
}));

const Profile = () => {
  const classes = useStyles();
  const { t, i18n } = useTranslation();
  const history = useHistory();
  const [showMyAccounts, setShowMyAccounts] = useState(false);
  const [profileDetails, setProfileDetails] = useState({});
  const [initProfileDetails, setInitProfileDetails] = useState({});
  const loading = useSelector((state) => state.userProfile.loading);
  const error = useSelector((state) => state.userProfile.error);
  const profile = useSelector((state) => state.landing.profile);
  const userProfile = useSelector((state) => state.userProfile.person);
  const referenceTables = useSelector(
    (state) => state.userProfile.referenceTables
  );

  const dispatch = useDispatch();
  let firstName = "";
  let lastName = "";
  if (profile) {
    firstName = profile.firstName;
    lastName = profile.lastName;
  }

  const name = `${firstName} ${lastName}`;
 

  function iterateAndDeleteTpeName(initDetails) {
    const profDetails = JSON.parse(JSON.stringify(initDetails));
    delete profDetails.__typename;
    delete profDetails.primaryOccupation.__typename;
    delete profDetails.primaryAddr.__typename;
    profDetails.contactMethods = profDetails.contactMethods.map((contact) => {
      delete contact.__typename;
      return contact;
    });
    return profDetails;
  }

  useEffect(() => {
    if (!referenceTables || Object.keys(referenceTables).length === 0) {
      fetchRdm();
    }
  
    async function fetchRdm() {
      try {
          dispatch(fetchGetParty());
      } catch (error) {
          console.error(error);
      }
    }
  }, [dispatch]);

  useEffect(() => {
    if(userProfile) {
      setProfileDetails(userProfile);
      setInitProfileDetails(profileDetails);
    }

  },[userProfile])

  function handleActionButtons() {
    if (profileDetails.primaryAddr) {
      if (
        profileDetails.primaryAddr.deliveryMode &&
        !profileDetails.primaryAddr.deliverModeText
      ) {
        return true;
      }
      if (
        profileDetails.primaryAddr.installationType &&
        !profileDetails.primaryAddr.installtionTypeText
      ) {
        return true;
      }
    }

    if (JSON.stringify(profileDetails) !== JSON.stringify(initProfileDetails)) {
      return false;
    }
    return true;
  }

  function initiliZeProfile() {
    setProfileDetails(initProfileDetails);
    setShowMyAccounts(false);
  }

  return (
    <div className={`${classes.container} borderon450`}>
      { loading  && <Loader />}
      <HeaderComp
        heading="Profile"
        profile={profile}
        name={name}
        onBackBtnClick={() => history.push({ pathname: "/" })}
      />
      <div style={{ paddingTop: "66px", textAlign: "center", height: "230px" }}>
        <img src={profileIcon} alt="Profile" />
        <div className={classes.fullName}>{profileDetails.fullName}</div>
      </div>
      <div className={classes.accordianWrapper}>
        <Accordion
          classes={{
            root: classes.firstAccordian,
            expanded: classes.accordianExpanded,
          }}
          square={true}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            classes={{ root: classes.accordianSummary }}
          >
            <span className={classes.heading}>Profile Information</span>
          </AccordionSummary>
          <AccordionDetails classes={{ root: classes.accordianDetails }}>
            <SubHeading headingText="Employment Status" />
            {profileDetails.primaryOccupation && (
              <DropDown
                defaultValue={profileDetails.primaryOccupation.employmentType}
                onChange={(val) => {
                  let updateProfileDetails = JSON.parse(
                    JSON.stringify(profileDetails)
                  );
                  updateProfileDetails.primaryOccupation.employmentType = val;
                  setProfileDetails({ ...updateProfileDetails });
                }}
                options={convertObjectToArray(referenceTables.employmentType)}
                searchable={true}
                rootDivClass={classes.profileDropDown}
              />
            )}
            <SubHeading headingText="Occupation" />
            {profileDetails.primaryOccupation && (
              <DropDown
                defaultValue={profileDetails.primaryOccupation.occupationType}
                onChange={(val) => {
                  let updateProfileDetails = JSON.parse(
                    JSON.stringify(profileDetails)
                  );
                  updateProfileDetails.primaryOccupation.occupationType = val;
                  setProfileDetails({ ...updateProfileDetails });
                }}
                options={convertObjectToArray(referenceTables.occupationType)}
                searchable={true}
                rootDivClass={classes.profileDropDown}
              />
            )}
          </AccordionDetails>
        </Accordion>

        <Accordion
          classes={{
            root: classes.firstAccordian,
            expanded: classes.accordianExpanded,
          }}
          square={true}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            classes={{ root: classes.accordianSummary }}
          >
            <span className={classes.heading}>Primary Address</span>
          </AccordionSummary>
          <AccordionDetails classes={{ root: classes.accordianDetails }}>
            {profileDetails.primaryAddr && (
              <React.Fragment>
                <SubHeading headingText="Address" />
                <InputText
                  heading="Street Number"
                  style={{ paddingTop: "16px" }}
                  value={profileDetails.primaryAddr.streetNumber}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.streetNumber = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <InputText
                  heading="Street Name"
                  value={profileDetails.primaryAddr.streetName}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.streetName = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <span className={classes.subHeadingSpan}>Apt/Suite Number</span>
                <DropDown
                  options={convertObjectToArray(referenceTables.residenceType)}
                  onChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.residenceType = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                  searchable={true}
                  rootDivClass={classes.profileDropDown}
                  defaultValue={profileDetails.primaryAddr.residenceType}
                />
                <InputText
                  value={profileDetails.primaryAddr.residenceNumber}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.residenceNumber = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <InputText
                  heading="City"
                  value={profileDetails.primaryAddr.city}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.city = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <span className={classes.subHeadingSpan}>Province</span>
                <DropDown
                  options={convertObjectToArray(referenceTables.provinceState)}
                  searchable={true}
                  onChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.provinceStateType = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                  rootDivClass={classes.profileDropDown}
                  defaultValue={profileDetails.primaryAddr.provinceStateType}
                />
                <InputText
                  heading="Postal Code"
                  value={profileDetails.primaryAddr.zipPostalCode}
                  style={{ marginTop: "10px" }}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.zipPostalCode = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />

                <SubHeading headingText="Rural Address" />
                <span className={classes.subHeadingSpan}>Delivery Mode</span>
                <DropDown
                  options={convertObjectToArray(referenceTables.deliveryMode)}
                  onChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.deliveryMode = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                  searchable={true}
                  rootDivClass={classes.profileDropDown}
                  defaultValue={profileDetails.primaryAddr.deliveryMode}
                />

                <InputText
                  placeHolder="Add note for delivery"
                  showError={Boolean(profileDetails.primaryAddr.deliveryMode)}
                  style={{ paddingTop: "30px" }}
                  value={profileDetails.primaryAddr.deliverModeText}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.deliverModeText = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <InputText
                  heading="Installation Name"
                  value={profileDetails.primaryAddr.installationName}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.installationName = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />

                <span className={classes.subHeadingSpan}>
                  Installation type
                </span>
                <DropDown
                  options={convertObjectToArray(
                    referenceTables.installationType
                  )}
                  searchable={true}
                  onChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.installationType = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                  rootDivClass={classes.profileDropDown}
                  defaultValue={profileDetails.primaryAddr.installationType}
                />
                <InputText
                  placeHolder="Add notes for Installation"
                  showError={Boolean(
                    profileDetails.primaryAddr.installationType
                  )}
                  style={{ paddingTop: "30px" }}
                  value={profileDetails.primaryAddr.installtionTypeText}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.installtionTypeText = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />

                <SubHeading headingText="Additional Address Information" />
                <InputText
                  heading="Site/Compartment, Lot/Concession"
                  style={{ paddingTop: "16px" }}
                  value={profileDetails.primaryAddr.site}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.site = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <InputText
                  heading="Building"
                  value={profileDetails.primaryAddr.building}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.building = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
                <InputText
                  heading="Floor"
                  value={profileDetails.primaryAddr.floor}
                  onInputChange={(val) => {
                    let updateProfileDetails = JSON.parse(
                      JSON.stringify(profileDetails)
                    );
                    updateProfileDetails.primaryAddr.floor = val;
                    setProfileDetails({ ...updateProfileDetails });
                  }}
                />
              </React.Fragment>
            )}
          </AccordionDetails>
        </Accordion>

        <Accordion
          classes={{
            root: classes.firstAccordian,
            expanded: classes.accordianExpanded,
          }}
          square={true}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            classes={{ root: classes.accordianSummary }}
          >
            <span className={classes.heading}>Contact Method</span>
          </AccordionSummary>
          <AccordionDetails classes={{ root: classes.accordianDetails }}>
            {profileDetails.primaryAddr && (
              <ContactMethod
                contactDetails={profileDetails.contactMethods}
                upDateContactDetails={(contactDetails) => {
                  let updateProfileDetails = JSON.parse(
                    JSON.stringify(profileDetails)
                  );
                  updateProfileDetails.contactMethods = contactDetails;
                  setProfileDetails({ ...updateProfileDetails });
                }}
                contactMethodTypes={referenceTables.contactMethodType}
              />
            )}
          </AccordionDetails>
        </Accordion>
      </div>
      <ActionButtons
        abortBtnText="Cancel"
        proceedBtnText="Continue"
        proceedBtnAction={() => setShowMyAccounts(true)}
        abortBtnAction={() => history.push({ pathname: "/" })}
        disableProceedBtn={handleActionButtons()}
        rootClass={classes.actionButtonsRoot}
      />
      {showMyAccounts && (
        <MyAccounts
          name={name}
          onBackBtnClick={() => {
            setShowMyAccounts(false);
          }}
          initiliZeValues={() => initiliZeProfile()}
          updateprofileDetails={profileDetails}
        />
      )}
      {error && <ErrorComponent />}
    </div>
  );
};

export default Profile;
