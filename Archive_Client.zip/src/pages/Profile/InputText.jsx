import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import InfoIcon from '@material-ui/icons/Info';
// .bill-input-container{
//     padding: 0 20px 40px;
// }
// .bill-input-header-span{
//     color: #393A3D;
//     font-size: 16px;
//     font-weight: 500;
//     display: block;
//     margin-bottom: 16px;
// }

const useStyles = makeStyles((theme) => ({
    rootContainer:{
        // padding:'0 20px 40px'
    },
    heading:{
        color: '#393A3D',
        fontSize: '16px',
        fontWeight: 500,
        marginBottom: '16px'
    },
  root:{
    width:'100%',
     borderBottom:'1px solid #DCDCDC',
     color: '#393A3D',
    marginBottom:'39px'
   },
   
   input:{
     fontSize:'16px',
     fontWeight: '400'
   },
   error:{
     color:'#C81414',
     marginTop: '-35px',
     display: 'block',
     marginBottom: '40px'
   }
   }));

export const InputText = ({value:initValue, heading, style, placeHolder='', required = false,
 overRideValError=false, showError=false, disabled=false, onInputChange, errorvalue="Required Field"}) => {
    const classes = useStyles();
    return (
        <div className={classes.rootContainer} style={style}>
            {heading && <span className={`${classes.heading} ${required ? 'required' : ''}`}>{heading}</span>}
          <Input
            value={initValue}
            disableUnderline={true}
            placeholder={placeHolder}
            disabled={disabled}
            classes={{root: classes.root, input: classes.input}}
            error={showError && !initValue}
            onChange={(e) => {
              onInputChange(e.target.value)
            }}
          />
          {showError && (!initValue || overRideValError ) && <span className={classes.error}> <InfoIcon/>{errorvalue}</span>}
        </div>
    )

}