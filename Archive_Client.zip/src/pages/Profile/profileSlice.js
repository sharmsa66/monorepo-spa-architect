import {
    createAsyncThunk,
    createSlice,
  } from "@reduxjs/toolkit";


  import { getParty, updateProfile, referenceTables } from '../../services/data-adapter/api';
   
  export const fetchGetParty =  createAsyncThunk('userProfile/getParty'
  , async() =>{
      const personObj = await getParty();
      const referenceTablesObj = await referenceTables();
    
      return {personObj, referenceTablesObj};
  });

 
  export const setUserProfile = createAsyncThunk(
      'updateProfile/setUserProfile',
      async({profile, accounts}) => {
          const response = await updateProfile(profile, accounts);
          return response
      }
  )

  const userProfile = createSlice({
      name: 'userProfile', 
      initialState:{
          person: null,
          referenceTables: null,
          loading: false,
          error: null
      },
      reducers:{},
      extraReducers: {
        [fetchGetParty.pending]: (state, action) => {
            state.loading = true;
        },
        [fetchGetParty.rejected]: (state, action) =>{
            state.loading = false;
            state.error = action.error;
        },
        [fetchGetParty.fulfilled]: (state, action) =>{
            state.person = action.payload.personObj;
            state.referenceTables = action.payload.referenceTablesObj;
            state.loading = false;
        },
        [setUserProfile.pending]: (state, action) =>{
            state.loading = false;
            state.erorr = null;
        },
        [setUserProfile.rejected]:(state, action)=>{
            state.error = action.error;
            state.loading = false;
        },
        [setUserProfile.fulfilled]: (state, action) => {
            state.person = action.payload;
            state.loading = false;
        }

      }
  });


  export default userProfile.reducer;