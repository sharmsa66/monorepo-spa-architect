import React from 'react';

export default function DropDown({headingText}) {
 
  return (
    <div className="subHeading">
       {headingText}
    </div>
  );
}
