import React, {useRef} from 'react';
import {ProfileHeader} from './ProfileHeader'
import {ActionButtons} from '../../components/ActionButtons';
import { useHistory } from "react-router-dom";
import close from '../../assets/Header/Close.svg';
import profilesuccess from '../../assets/Profile/ProfileSuccess.svg';

export const Success = ({name, transactionId}) => {
    const history = useHistory();
    const headerRef = useRef();
    return (
        <div className="consent">
            <ProfileHeader heading="Confirmation" name={name}
             onBackBtnClick={()=>history.push({ pathname: '/'})} 
             ref={headerRef}
             backImgSrc={close} />

            <div className="success-icon lrPad20">
                <img src={profilesuccess} alt="Success" />
            </div>
        <div className="lrPad20">
            
            <div className="success-msg" >Success! Your changes have been submitted.</div>
            <div className="bill-details-on-sp">
            It may take up to 48 hours for new information to be updated. Please keep a copy of this page for your reference.
            </div>

            <div className="confirm">{`Reference number# ${transactionId}`}</div>
            </div>
           
            <ActionButtons proceedBtnText="All Done" proceedBtnAction={()=>{
                headerRef.current.showNav()
            }} abortBtnClass="displayNone"/>
        </div>
    )

}