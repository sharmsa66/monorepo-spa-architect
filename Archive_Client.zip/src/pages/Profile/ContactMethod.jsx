import React, { useState } from 'react';
import {InputText} from './InputText';
import Radio from './RadioOptions';
import PreferedTimeCheckbox from './PreferedTimeCheckbox';
const contact = {
    type: "",
    email:null,
    phone:"",
    phoneAreaCode:"",
    phoneNumber:"",
    phoneExtension:null,
    isPreferred: false
}

export const ContactMethod = ({contactDetails, contactMethodTypes, upDateContactDetails, hasEmailError}) => {
const[emailError, setEmailError] = useState('');
    

    function extractContactDetails() {
        let emailAddress = {value:'', isPreferred: false};
        let homePhone = {value:'', isPreferred: false};
        let mobilePhone = {value:'', isPreferred: false};
        let businessPhone = {value:'', isPreferred: false};
        contactDetails.forEach(({type, email, phone, isPreferred}) =>{
            switch(type) {
                case "100008":
                case "100148":
                  emailAddress.value = email
                  emailAddress.isPreferred = isPreferred
                  break;
                case "100000":
                    homePhone.value = phone
                    homePhone.isPreferred = isPreferred
                    break;
                case "100001":
                    businessPhone.value = phone
                    businessPhone.isPreferred = isPreferred
                    break;
                case "100004":
                case "100005":
                    mobilePhone.value= phone
                    mobilePhone.isPreferred = isPreferred
                    break;
                default:
            }
        });
        return {
            emailAddress,
            homePhone,
            mobilePhone,
            businessPhone
        }
    }

    function stringSplice(a,b, position){
        return a.substring(0, position) + b + a.substring(position)
        }

    function formatPhoneNumber(phoneNumberString) {
        let cleaned = ('' + phoneNumberString).replace(/\D/g, '').slice(0,11)
        if(cleaned.length === 10 && cleaned[0] !== '1'){
            cleaned = stringSplice(cleaned, '1', 0)
        }
        if(cleaned.length === 11){
            const match = cleaned.match(/^(\d{1,1})(\d{0,3})(\d{0,3})(\d{0,4})$/);
            if (match) {
                return [match[1],  match[2], match[3], match[4]].join('-')
            }
        }
        
            return cleaned;
      }

    function updateContactDetails(value, key, updateValue){
        switch(key) {
            case "email":
                contactDetails = contactDetails.map((contact) => {
                    if(contact.type === "100008" || contact.type === "100148"){
                        if(updateValue){
                        contact.email = value
                        } else {
                            contact.isPreferred = value
                        }
                    }
                    return contact;
                })
              break;
            case "homePhone":
                const isHomePhoneExists = contactDetails.some((contact) => contact.type === "100000");
                if(isHomePhoneExists){
                    contactDetails = contactDetails.map((contact) => {
                        if(contact.type === "100000"){
                            if(updateValue){
                                contact.phone = value
                            } else {
                                contact.isPreferred = value
                            }
                        }
                        return contact;
                    })
                } else {
                    const addCOntact = JSON.parse(JSON.stringify(contact))
                addCOntact.type = "100000"
                if(updateValue){
                    addCOntact.phone = value
                } else {
                    addCOntact.isPreferred = value
                }
                contactDetails.push(addCOntact);
                }
            
                break;
            case "businessPhone":
                const isBusinessPhoneExist = contactDetails.some((contact) => contact.type === "100001");
                if(isBusinessPhoneExist){
                    contactDetails = contactDetails.map((contact) => {
                        if(contact.type === "100001"){
                            if(updateValue){
                                contact.phone = value
                            } else {
                                contact.isPreferred = value
                            } 
                        }
                        return contact;
                    })
                } else {
                    const addCOntact = JSON.parse(JSON.stringify(contact))
                    addCOntact.type = "100001"
                    if(updateValue){
                        addCOntact.phone = value
                    } else {
                        addCOntact.isPreferred = value
                    }
                    contactDetails.push(addCOntact);
                }
                break;
            case "mobilePhone":
                const isMobilePhoneExist = contactDetails.some((contact) => contact.type === "100004" || contact.type === "100005");
                if(isMobilePhoneExist){
                    contactDetails = contactDetails.map((contact) => {
                        if(contact.type === "100004" || contact.type === "100005"){
                            if(updateValue){
                                contact.phone = value
                            } else {
                                contact.isPreferred = value
                            }
                        }
                        return contact;
                    })
                } else {
                    const addCOntact = JSON.parse(JSON.stringify(contact))
                    addCOntact.type = "100005"
                    if(updateValue){
                        addCOntact.phone = value
                    } else {
                        addCOntact.isPreferred = value
                    }
                    contactDetails.push(addCOntact);
                }
                break;
            default:
          }
          upDateContactDetails(contactDetails)
    }

    const {emailAddress, homePhone, mobilePhone, businessPhone} = extractContactDetails()
    return (
        <React.Fragment>
            <InputText heading="Email Address" value={emailAddress.value} showError={Boolean(emailError)}
            errorvalue={emailError}
            overRideValError={true}
             onInputChange={(val) => {
                const re = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/i;
                if(val === ""){
                    setEmailError("Please Enter Valid Email")
                    hasEmailError(true)
                } else if(!re.test(val.toLowerCase())){
                    setEmailError("Please Enter Valid Email")
                    hasEmailError(true)
                } else{
                    setEmailError("")
                    hasEmailError(false)
                }
                updateContactDetails(val, 'email', true)
             }}/>
            <Radio style={{marginTop:'-20px', marginBottom:'40px'}} value={emailAddress.isPreferred ? "yes" : "no"}
                onValueChange={(val) =>{
                    updateContactDetails(val, 'email')
                }}/>

            <InputText heading="Mobile Phone" value={mobilePhone.value}
             onInputChange={(val) =>{
                const formatted = formatPhoneNumber(val)
                updateContactDetails(formatted, 'mobilePhone', true)
            }}/>
            <Radio style={{marginTop:'-20px', marginBottom:'40px'}} value={mobilePhone.isPreferred ? "yes" : "no"} 
                 onValueChange={(val) =>{
                    updateContactDetails(val, 'mobilePhone')
                }}/>
            <PreferedTimeCheckbox />

            <InputText heading="Home Phone" value={homePhone.value}
                disabled={true}
             onInputChange={(val) =>{
                const formatted = formatPhoneNumber(val)
                updateContactDetails(formatted, 'homePhone', true)
            }}/>
            <Radio style={{marginTop:'-20px', marginBottom:'40px'}} value={homePhone.isPreferred ? "yes" : "no"}
                disabled={true}
                 onValueChange={(val) =>{
                    updateContactDetails(val, 'homePhone')
                }}/>
            <PreferedTimeCheckbox disabled={true} />


            <InputText heading="Business Phone" value={businessPhone.value}
            disabled={true} 
             onInputChange={(val) =>{
                const formatted = formatPhoneNumber(val)
                updateContactDetails(formatted, 'businessPhone', true)
             }}/>
            <Radio style={{marginTop:'-20px', marginBottom:'40px'}} value={businessPhone.isPreferred ? "yes" : "no"} 
                disabled={true}
                 onValueChange={(val) =>{
                    updateContactDetails(val, 'businessPhone')
                }}/>
            <PreferedTimeCheckbox bottomMargin="0" disabled={true}  />
        </React.Fragment>
    )

}