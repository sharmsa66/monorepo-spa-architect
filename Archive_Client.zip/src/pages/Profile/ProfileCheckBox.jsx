import React from 'react';
import Checkbox from '@material-ui/core/Checkbox';

export default function AccountCheckBox({ 
	value, 
	subDetails, 
	noBorder=false, 
	defaultChecked = false, 
	height, 
	onChange,
	disabled=false,
	accountNumber}) {

	const handleChange = (event) => {
		onChange({checked:event.target.checked, accNo:accountNumber});
	};

	return (
		
		<div style={{display:'flex', height: `${height}px`, alignItems:'center', borderBottom: noBorder? 'none' : '1px solid #CFCFCF'}}>
		<Checkbox
			disabled={disabled}
			checked={defaultChecked}
			onChange={handleChange}
			inputProps={{ 'aria-label': 'primary checkbox' }}
		/>
		<div><span style={{display:'block', fontSize:'16px', fontWeight:500,lineHeight:'23.5px'}}>{value}</span>
		<span style={{fontSize:'14px', lineHeight:'20.5px', color: '#646C76',fontWeight:400}}>{subDetails}</span></div>
		</div>
	);
}
