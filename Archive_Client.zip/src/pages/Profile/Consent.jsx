import React, { useState } from "react";
import { HeaderComp } from "../../components/HeaderComp";
import { ActionButtons } from "../../components/ActionButtons";
import consent from "../../assets/Profile/Consent.svg";
import { useHistory } from "react-router-dom";
import { Loader } from "../../components/Loader";
import { Success } from "./Success";
import { useDispatch, useSelector } from "react-redux";

import { setUserProfile } from "./profileSlice";
import { unwrapResult } from "@reduxjs/toolkit";

export const Consent = ({
  onBackBtnClick,
  name,
  accountsChecked,
  updateprofileDetails,
  initiliZeValues,
}) => {
  const [showSuccess, setShowSuccess] = useState(false);
  const [showLoader, setShowLoader]= useState(false);
  const [transactionId, setTransactionId] = useState("");
  const history = useHistory();
  // const globalState = useGlobalState();

  const loading = useSelector((state) => state.userProfile.loading);
  const error = useSelector((state) => state.userProfile.error);

  const dispatch = useDispatch();

  async function upDataProfile() {
    delete updateprofileDetails.fullName;
    try {
        dispatch(
          setUserProfile({
            profile: updateprofileDetails,
            accounts: accountsChecked,
          })
        ).then(unwrapResult)
          .then((data) => {
            setTransactionId(data.updateProfile.transactionId);
            setShowSuccess(true);
        });
    } catch (error) {
        setShowLoader(false);
        console.error(error);
    }
  }

  return (
    <div className="success-screen">
      {loading && !showSuccess && <Loader />}
      <HeaderComp
        heading="Consent"
        name={name}
        onBackBtnClick={onBackBtnClick}
      />
      <div className="success-icon lrPad20">
        <img src={consent} alt="Success" />
      </div>
      <div className="lrPad20">
        <div className="success-msg" style={{ color: "#0075BE" }}>
          Your Consent
        </div>
        <div className="bill-details-on-sp">
          By selecting Accept, you're agreeing to share your personal
          information with BMO and are giving us permission to also update that
          information with BMO Investments Inc. and the Bank of Montreal
          Mortgage Corporation.
        </div>
      </div>
      <ActionButtons
        proceedBtnText="Accept"
        abortBtnText="Cancel"
        proceedBtnAction={() => upDataProfile()}
        abortBtnAction={() => initiliZeValues()}
      />
      {showSuccess && <Success name={name} transactionId={transactionId} />}
    </div>
  );
};
