import React, { useState } from 'react';
import CheckBox from './ProfileCheckBox'

const time = ["Morning", "Afternoon", "Evening"]
export default function PreferedTimeCheckbox({bottomMargin = "20", disabled=false}) {
  const [checkedDuration, setCheckedDuration] = useState([false, false, false]);

  return (
    <div style={{marginBottom: `${bottomMargin}px`}}>What times do you perefer to be contacted?
    
    <div style={{marginLeft:'-9px'}}>
      
      {time.map((duration, index) => <CheckBox
        disabled={disabled}
        value={duration}
        noBorder={true}
        key ={duration}
        defaultChecked={checkedDuration[index]}
        onChange={({checked}) => {
            const updateDuration = JSON.parse(JSON.stringify(checkedDuration));
            updateDuration[index] = checked;
            setTimeout(setCheckedDuration(updateDuration),0)
        }}
      />
    )}
     

    </div>
    </div>
    
  );
}
