import React, { useState } from 'react';
import { HeaderComp } from '../../components/HeaderComp';
import {ActionButtons} from '../../components/ActionButtons';
import { Consent } from './Consent';
import AccountCheckBox from './ProfileCheckBox';
// import { useGlobalState } from "../../store/store";
import { makeStyles } from '@material-ui/core/styles';
import { useSelector } from 'react-redux';

const useStyles = makeStyles((theme) => ({
    container: {
      width: '100%',
    maxWidth: '450px',
    height: '100vh',
    margin: '0 auto'
    },
    actionButtonsRoot:{
        position: 'fixed',
        width: '100%',
        height: '60px',
        display: 'flex',
        alignItems: 'center',
        maxWidth:'448px',
        justifyContent: 'flex-end',
        background: 'white',
        bottom: 0,
        boxShadow:'0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
        '& > *': {
            margin: theme.spacing(1),
        }
    }
}));

export const MyAccounts = ({ name, onBackBtnClick,  updateprofileDetails, initiliZeValues }) => {
    const classes = useStyles();
    const [showConsent, setShowConsent] = useState(false);
    // const globalState = useGlobalState();
    //  const {accountSummary = {data: {accounts:[], profile:{} }}}= globalState.state;
    //  const [accountData, setAccountData] = useState(accountSummary.data);
     const [allAccountsChecked, setAllAccountsChecked] = useState(false)
     const [accountsSelected, setAccountsSelected] = useState([]);
     const accounts = useSelector(state => state.landing.accounts);
     const defAccountsChecked =  accounts.map(el => false);
     const [accountsChecked, setAccountsChecked] = useState(defAccountsChecked);
     
     function handleActionButton(){
        const shouldDisable = accountsChecked.some((el) => el);
        return !shouldDisable
     }
    return (
        <div className={`${classes.container} borderon450`}>
        <div className="success-screen">
            <HeaderComp heading="Accts" name={name} onBackBtnClick={onBackBtnClick} />

        <div className="lrPad20">
            
            <div className="success-msg" style={{color :'#0075BE',paddingTop : '80px'}}>Your Accounts</div>
            <div className="bill-details-on-sp">
            Select the accounts that you'd like to update with these new details.
             If you want to update the details for your investments, the changes will apply to all investment accounts.
                </div>

                

           <AccountCheckBox value="All Accounts"
           height="87"
            onChange={({checked}) => {
               let updateAccountsChecked;
              if(checked){
                  const accountsList = accounts.map(({accountNumber, source=""}) => ({accountNumber, source}));
                  setAccountsSelected(accountsList);
                  updateAccountsChecked = accounts.map((_el) => true);
              } else {
                  setAccountsSelected([]);
                  updateAccountsChecked =  accounts.map((_el) => false);
              }
              setTimeout(setAllAccountsChecked(checked), 0)
              setTimeout(setAccountsChecked(updateAccountsChecked), 0)
              }}
              defaultChecked={allAccountsChecked}
              />
            {accounts && accounts.map(({name, maskedAccountNumber, accountNumber, source=""}, index) => <AccountCheckBox value={name} 
                subDetails={maskedAccountNumber}
                key={accountNumber}
               height="87"
                onChange={({checked, accNo}) => {
                    const previousaccountsSelected = JSON.parse(JSON.stringify(accountsSelected));
                    if(checked){
                        const account = {accountNumber, source}
                        previousaccountsSelected.push(account);
                    } else{
                        const getIndex = previousaccountsSelected.findIndex(el => el.accountNumber === accNo);
                        if(getIndex !== -1){
                            previousaccountsSelected.splice(getIndex,1);
                        }
                    }
                    setAccountsSelected(previousaccountsSelected);
                    const updateAccountsChecked = accountsChecked;
                    updateAccountsChecked[index] = checked;
                    setTimeout(setAllAccountsChecked(false), 0)
                    setTimeout(setAccountsChecked(updateAccountsChecked), 0)
                    
                }}
             defaultChecked={accountsChecked[index]} accountNumber={accountNumber}
             />)}

            </div>
            <div style= {{paddingTop : '10px', fontWeight: 400, fontSize: '14px', padding: '10px 20px'}}>
                To make changes to BMO InvestorLine accounts, contact BMO InvestorLine at 1-800-387-7800. 
                For BMO Nesbitt Burns investments, contact your advisor.
            </div>
            <div style={{padding: '10px 20px', fontSize: '14px'}}>
            Are accounts missing from this list? Go to<span style={{textDecoration:'underline', color: '#0075BE'}}> <a href="http://localhost:3000/e2eapp/profile">Link My Accounts </a></span>to add them to Online Banking.
            </div>
            {<ActionButtons abortBtnText="Cancel" proceedBtnText="Continue" proceedBtnAction={() => setShowConsent(true)}
             abortBtnAction={onBackBtnClick}
             disableProceedBtn={handleActionButton()}
            rootClass={classes.actionButtonsRoot}
            />}
            
    </div>
    {showConsent && <Consent name={name} onBackBtnClick={() => {setShowConsent(false)}}
             updateprofileDetails={updateprofileDetails}
             initiliZeValues={() => {initiliZeValues();
                 setShowConsent(false)}}
             accountsChecked={accountsSelected}
             />}
           </div>
            
    )

}