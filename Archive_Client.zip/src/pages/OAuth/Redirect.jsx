import { useHistory } from "react-router-dom";
import { useTranslation } from 'react-i18next';
import { clearPageContext, getPageContext, checkInNewAuthCode } from  "@bmo/auth";  //"../../services/oauth";

const Redirect = () => {
    const history = useHistory();
    const { i18n } = useTranslation();
    const pageContext = getPageContext();

    const urlParams = new URLSearchParams(window.location.search);
    const oAuthError = urlParams.get('error');
    const authCode = urlParams.get('code');
    const newStateCode = urlParams.get('state');
    const language = urlParams.get('language');

    clearPageContext();

    if (oAuthError) {
        if (oAuthError === 'access_denied') {            
            // Check what the current oAuth request is for: login or transaction
            // If the oAuth context exists it's an oAuth under a transaction
            if (pageContext && pageContext.path && pageContext.state) {
                history.push('/paymentdeny');
            }
            else {
                history.push('/logindeny');
            }
        }
        else {
            // TODO: Handle unexpected oAuth error code
            throw new Error('oAuth error: unknown error code - ' + oAuthError);
        }
    }
    else if (authCode) {
        if (language) {
            i18n.changeLanguage(language.toLowerCase());
        }

        checkInNewAuthCode(authCode, newStateCode)
        .then(() => {
            // Jump back to where it was before oauth
            history.push(pageContext.path, pageContext.state);
        })
        .catch(error => {
            // TODO: Display error message
        });
    }
    else {
        // TODO: Handle the case that authCode is missing in redirect
        throw new Error("Missing auth code in response");
    }

    return (null);
}

export default Redirect;
