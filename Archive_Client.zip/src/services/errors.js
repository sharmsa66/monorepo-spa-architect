const ERRORS  = {
    INSUFFICIENT_SCOPE      :   'INSUFFICIENT_SCOPE',
    INSUFFICIENT_PERMISSION :   'INSUFFICIENT_PERMISSION',
    UNAUTHORIZED            :   'UNAUTHORIZED',
    NETWORK_ERROR           :   'NETWORK_ERROR',
    SERVER_ERROR            :   'SERVER_ERROR',
    OAUTH_ERROR             :   'OAUTH_ERROR',
    UNKNOWN                 :   'UNKNOWN'
}

export default ERRORS;