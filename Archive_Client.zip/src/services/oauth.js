import { Mutex } from "async-mutex";
import ERRORS from "./errors";

const REDIRECT_URI_PATH = "/redirect";
const REACT_APP_TOKEN_URL = "http://localhost:4010/token";
const REACT_APP_CLIENT_ID = "user";
const mutex = new Mutex();

// Generate a secure random string using the browser crypto functions
function generateRandomString() {
  var array = new Uint32Array(28);
  window.crypto.getRandomValues(array);
  return Array.from(array, (dec) => ("0" + dec.toString(16)).substr(-2)).join(
    ""
  );
}

// Calculate the SHA256 hash of the input text.
// Returns a promise that resolves to an ArrayBuffer
function sha256(plain) {
  const encoder = new TextEncoder();
  const data = encoder.encode(plain);
  return window.crypto.subtle.digest("SHA-256", data);
}

// Base64-urlencodes the input string
function base64urlencode(str) {
  // Convert the ArrayBuffer to string using Uint8 array to convert to what btoa accepts.
  // btoa accepts chars only within ascii 0-255 and base64 encodes them.
  // Then convert the base64 encoded to base64url encoded
  //   (replace + with -, replace / with _, trim trailing =)
  return btoa(String.fromCharCode.apply(null, new Uint8Array(str)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function base64Encode(str) {
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function getJWTTokenWithoutSignature(header, payload) {
  return (
    base64Encode(JSON.stringify(header)) +
    "." +
    base64Encode(JSON.stringify(payload)) +
    "."
  );
}

// Return the base64-urlencoded sha256 hash for the PKCE challenge
async function pkceChallengeFromVerifier(v) {
  const hashed = await sha256(v);
  return base64urlencode(hashed);
}

async function authorize(transaction_id) {
  const verifier = generateRandomString();
  const challenge = await pkceChallengeFromVerifier(verifier);
  const redirect_uri = window.location.origin + REDIRECT_URI_PATH;
  const stateCode = generateRandomString();
  const requestClause = transaction_id
    ? "&request=" +
      getJWTTokenWithoutSignature(
        {
          typ: "JWT",
          alg: "none",
        },
        {
          transaction_id: transaction_id,
          redirect_uri: redirect_uri,
          client_id: "user",
        }
      )
    : "";

  const authUrl =
    "http://localhost:4010/auth" +
    "?response_type=code" +
    "&redirect_uri=" +
    encodeURIComponent(redirect_uri) +
    "&client_id=" +
    encodeURIComponent("user") +
    "&scope=" +
    encodeURIComponent("openid") +
    "&state=" +
    encodeURIComponent(stateCode) +
    "&response_mode=form_post" +
    "&code_challenge_method=S256" +
    "&code_challenge=" +
    encodeURIComponent(challenge) +
    requestClause;

  setStateCode(stateCode);
  setCodeVerifier(verifier);
  window.location.replace(authUrl);
}

async function getTokenByAuthCode(authCode) {
  const redirect_uri = window.location.origin + REDIRECT_URI_PATH;
  const data =
    "code=" +
    encodeURIComponent(authCode) +
    "&code_verifier=" +
    encodeURIComponent(getCodeVerifier()) +
    "&client_id=" +
    encodeURIComponent(REACT_APP_CLIENT_ID) +
    "&grant_type=authorization_code" +
    "&redirect_uri=" +
    encodeURIComponent(redirect_uri);

  const response = await fetch(REACT_APP_TOKEN_URL, {
    method: "POST",
    url: REACT_APP_TOKEN_URL,
    credentials: "include",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: data,
  });
  const payload = await response.json();
  return payload;
}

async function refreshToken() {
  const redirect_uri = window.location.origin + REDIRECT_URI_PATH;
  const data =
    "grant_type=refresh_token" +
    "&refresh_token=" +
    encodeURIComponent(getToken().refresh_token) +
    "&code_verifier=" +
    encodeURIComponent(getCodeVerifier()) +
    "&client_id=" +
    encodeURIComponent(process.env.REACT_APP_CLIENT_ID) +
    "&redirect_uri=" +
    encodeURIComponent(redirect_uri);

  const response = await fetch(process.env.REACT_APP_TOKEN_URL, {
    method: "POST",
    url: process.env.REACT_APP_TOKEN_URL,
    credentials: "include",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: data,
  });
  const payload = await response.json();
  return payload;
}

async function logout() {
  const res = await fetch(process.env.REACT_APP_LOGOUT_URL, {
    credentials: "include",
  });
  if (res.status === 200) {
    clearAll();
    return true;
  } else {
    console.error("Failed to logout, status code = " + res.status);
    return false;
  }
}

/****************************************************************************************
 *                       oAuth states management and operations
 * All oauth related states need to be stored in session storage only since every API call
 * potentially involve user re-login or token escalation(such as in a payment) call, in
 * which case the browser will be redirected to login SPA, all the in-memory states will
 * be lost when it is redirected back from login/OTP
 ****************************************************************************************/

function setParam(key, value) {
  sessionStorage.setItem(key, JSON.stringify(value));
}

function getParam(key) {
  return JSON.parse(sessionStorage.getItem(key));
}

function setCodeVerifier(verifier) {
  sessionStorage.setItem("verifier", verifier);
}

function getCodeVerifier() {
  return sessionStorage.getItem("verifier");
}

function setToken(token) {
  setParam("token", token);
}

function getToken() {
  return getParam("token");
}

function isAuth() {
  const token = getToken();
  return token !== null && token !== undefined;
}

async function acquireToken() {
  return await mutex.runExclusive(async () => {
    const token = getToken();
    if (token.expires_at - Date.now() < 10000) {
      try {
        const newToken = await refreshToken();
        newToken.expires_at = Date.now() + newToken.expires_in * 1000;
        setToken(newToken);
        return newToken;
      } catch (error) {
        console.error(error);
        throw new Error(ERRORS.OAUTH_ERROR);
      }
    }
    return token;
  });
}

async function checkInNewAuthCode(authCode, state) {
  return await mutex.runExclusive(async () => {
    if (state === getStateCode()) {
      clearStateCode();
      newSession();

      try {
        const newToken = await getTokenByAuthCode(authCode);
        newToken.expires_at = Date.now() + newToken.expires_in * 1000;
        setToken(newToken);
      } catch (error) {
        console.error(error);
        throw new Error(ERRORS.OAUTH_ERROR);
      }
    } else {
      console.error("state code doesn't match");
      throw new Error(ERRORS.OAUTH_ERROR);
    }
  });
}

function setStateCode(code) {
  sessionStorage.setItem("state", code);
}

function getStateCode() {
  return sessionStorage.getItem("state");
}

function clearStateCode() {
  setStateCode(null);
}

function newSession() {
  sessionStorage.setItem(
    "sessionId",
    Math.floor(Math.random() * 10000000000).toString()
  );
}

function getSessionId() {
  return sessionStorage.getItem("sessionId");
}

function savePageContext(context) {
  setParam("context", context);
}

function clearPageContext() {
  savePageContext(null);
}

function getPageContext() {
  const context = getParam("context");
  return context ? context : { path: "/", state: {} };
}

function clearAll() {
  setToken(null);
  clearStateCode();
  setCodeVerifier(null);
  clearPageContext();
  setParam("sessionId", null);
}

export {
  authorize,
  logout,
  isAuth,
  acquireToken,
  checkInNewAuthCode,
  getSessionId,
  savePageContext,
  clearPageContext,
  getPageContext,
};
