

export const PAR_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_PAR_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const GCAE_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_GCAE_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const CCAE_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  apikey: process.env.REACT_APP_API_KEY,
  endpoint: process.env.REACT_APP_CCAE_PATH,
  method: "POST",
};

export const PAYEE_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_PAYEE_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "GET",
};

export const PAYBILL_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_BILL_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const RECIPIENT_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_RECIPIENT_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "GET",
};

export const ETRANSFER_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_ETRANSFER_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const DECISIONAPI_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_DECISION_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const USERPREF_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_USERPREF_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const RDM_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_RDM_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const RETRIEVE_PARTY_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_RETRIEVE_PARTY_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "POST",
};

export const UPDATE_PARTY_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_UPDATE_PARTY_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "PATCH",
};

export const UPDATE_CONTACTPOINTS_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_UPDATE_CONTACTPOINTS_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "PATCH",
};

export const FDX_ACCOUNTS_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_FDX_ACCOUNTS_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "GET",
};

export const FDX_ACCOUNT_DETAILS_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_FDX_ACCOUNT_DETAILS_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "GET",
};

export const FDX_TRANSACTIONS_CONFIG = {
  apihost: process.env.REACT_APP_API_ENDPOINT,
  endpoint: process.env.REACT_APP_FDX_TRANSACTIONS_PATH,
  apikey: process.env.REACT_APP_API_KEY,
  method: "GET",
};

export const X_FAPI_FINANCIAL_ID = process.env.REACT_APP_FAPI_FINANCIAL_ID;

export const X_APP_CAT_ID = process.env.REACT_APP_CAT_ID;
