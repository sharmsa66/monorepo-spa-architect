// Mapping between GraphQL AccountType and Account subCategory in backend representation
export const ACCOUNT_TYPE = {
    Chequing:   'Chequing Accounts',
    Saving:     'Saving Accounts',
    CreditCard: 'MasterCard',
    Loan:       'Loan Accounts',
    Mortgate:   'Mortgage Accounts',
    RESP:       'Registered Education Savings Plans (RESPs)',
    RRSP:       'Registered Retirement Savings Plans (RRSPs)',
    Wills:      'Wills'
};

// Mapping between GraphQL AccountStatus and Account status in backend representation
export const ACCOUNT_STATUS = {
    Pending:    '100000',
    Open:       '100001',
    Closed:     '100002',
    Canceled:   '100003',
    Expired:    '100004',
    Unknown:    '999999'
};

// The currency code mapping between numeric and letter representation in ISO 4217
export const CURRENCY = {
    '124': 'CAD',
    '840': 'USD',
    '978': 'EUR'
};

// Mapping from backend representation of category to type of Account
export const ACCOUNT_CATEGORY = {
    'Bank Accounts':    'BankAccount',
    'Credit Cards':     'CreditCard'
};

export const DECISIONAPI_ACCOUNT_TYPE = {
    'Chequing Accounts':    'CHQ',
    'Saving Accounts':      'SAV',
    'MasterCard':           'Credit'
};

export const ACCOUNT_ACTIONS = {
    SendMoneyFrom:      'Send Money',
    TransferFundsFrom : 'Transfer',
    DepositTo:          'Deposit',
    PayBillFrom:        'Pay Bills'
};


// Additional mapping tables packed with the RDM code tables
// delivered to UI for display purpose
export const INSTALLATION_TYPE = {
    'BDP':	    'BDP - Bureau de poste',
	'CPC':	    'CPC - Centre postal communautaire',
	'CDO':	    'CDO - Commercial Dealership Outlet',
	'CMC':	    'CMC - Community Mail Centre',
	'CSP':	    'CSP - Comptoir postal',
	'CC':	    'CC - Concession commerciale',
	'LCD':	    'LCD - Letter Carrier Depot',
	'RPO':	    'RPO - Retail Postal Outlet',
	'PDF':      'PDF - Post de factueurs',
	'PO': 	    'PO - Post Office',
	'STN':	    'STN - Station',
	'SUCC':	    'SUCC - Succursale'
}

export const DELIVERY_MODE = {
    'CP':	    'CP - Case postale',
	'GD':	    'GD - General Delivery',
	'IM':	    'IM - Itinéraire motorisé',
	'MR':	    'MR - Mobile Route',
	'PR':	    'PR - Poste restante',
	'PO BOX':   'PO BOX - Post Office Box',
	'RR':	    'RR - Rural Route / Route rurale',
	'SS':	    'SS - Suburban Service / Service suburbain'
}

// This ecif code -> UI Label mapping is served from graphql layer instead of from RDM table
// because the CDCONTMETHTP sub-category table lacks of user friendly UI labels
// And we also need to map multiple ECIF code to same UI labels
// Based on OLB's Data mapping document
export const CONTACT_MATHOD_TYPE = {
    '100000':   'Home Phone',         
    '100001':   'Business Phone',     
    '100004':   'Mobile Phone',       
    '100005':   'Mobile Phone',       
    '100112':   'Home Fax',           
    '100116':   'Business Fax',       
    '100113':   'Pager',              
    '100117':   'Business Pager',     
    '100114':   'TTY/TDD',            
    '100118':   'Business TTY/TDD',
    '100008':   'Email Address',
    '100009':   'Business Email',
    '100148':   'Email Address',
    '100149':   'Business Email'
}

export const RDM_CODETABLES = {
    'ES.CDXEMPLTP':      'employmentType',      
    'ES.CDOCCUPATIONTP': 'occupationType',    
    'ES.CDPROVSTATETP':  'provinceState',    
    'ES.CDRESIDENCETP':  'residenceType'
};