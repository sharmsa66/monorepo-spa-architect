import {
	accountSummary,
	fdxAccountSummary,
	CustomerProfile,
	accountCommonResolvers,
	fdxAccountResolver,
	transactionMapper,
	fdxTransactionMapper,
	resolveCustomerRecipeintList,
	parseRDMXml,
	setUpdatableProfile
} from "./transformer";

import { getDeviceFingerprint } from "../../util/util";
import { authorize, acquireToken, getSessionId } from "../oauth";

import {
	DECISIONAPI_ACCOUNT_TYPE,
	ACCOUNT_ACTIONS,
	ACCOUNT_TYPE,
	RDM_CODETABLES,
	DELIVERY_MODE,
	INSTALLATION_TYPE,
	CONTACT_MATHOD_TYPE
} from "./mappings";

import * as constants from "./constants";
import ERRORS from "../errors";
import axios from "axios";
import { v4 } from "uuid";

axios.defaults.withCredentials = true;

async function callAPI(request) {
	let response;
	try {
		response = await axios(request);
	}
	catch(error) {
		switch(error.response.status) {
			case 401:
				const authHeader = error.response.headers['www-authenticate'];
				if (authHeader.includes("error='insufficient_scope'")) {
					const match = authHeader.match(/scope='transaction_id=(\S+?)['|\s]/);
					const transaction_id = match[1];
					if (transaction_id) {
						authorize(transaction_id);
						throw new Error(ERRORS.INSUFFICIENT_SCOPE);
					}
					else {
						throw new Error(ERRORS.UNKNOWN);
					}
				}
				else {
					await authorize();
					throw new Error(ERRORS.UNAUTHORIZED);
				}
			case 403:
				throw new Error(ERRORS.INSUFFICIENT_PERMISSION);
			case 404:
			case 500:
			case 502:
				throw new Error(ERRORS.SERVER_ERROR);
			default: 
				throw new Error(ERRORS.UNKNOWN);
		}
	}
  	return response.data;
}

async function composeRequest(apiInfo, templateParams) {
    const token = await acquireToken();

	const context = {
        "authorization": 'Bearer ' + token.access_token,
        "x-fapi-interaction-id": getSessionId(),
		"x-bmo-id-token": token.id_token,
		"x-bmo-device-fingerprint" : getDeviceFingerprint()
    }

	let path = apiInfo.endpoint;
	if (templateParams) {
		Object.keys(templateParams).forEach(key => {
			path = path.replace('{' + key + '}', templateParams[key])
		});
	}

	return {
		method: apiInfo.method,
		url: apiInfo.apihost + path,
		headers: {
			"content-type": "application/json",
			"x-fapi-financial-id": constants.X_FAPI_FINANCIAL_ID,
			"x-app-cat-id": constants.X_APP_CAT_ID,
			"x-request-id": v4(),
			"x-api-key": apiInfo.apikey,
			...context,
			...apiInfo.headers,
		},
		data: {
			originatorData: {
				applicationCatalogueId: constants.X_APP_CAT_ID,
				country: "CAN",
				locationId: process.env.IP,
				locationType: "IP",
				channel: "NET",
			}
		}
	};
}

export async function payBill(bill) {
	const request = await composeRequest(constants.PAYBILL_CONFIG);
	request.data = {
		paymentInitiation: {
			payerAccountNumber: bill.payerAccountNumber,
			payerAccountSource: bill.source,
			payeeAccountNumber: bill.customerAccountNumber,
			payeeBillerId: bill.billerId,
			instructedAmount: {
				amount: bill.amount,
				currency: bill.currency,
			}
		}
	};
	return await callAPI(request);
}

export async function getCustomerPayees() {
	const request = await composeRequest(constants.PAYEE_CONFIG);
	return await callAPI(request);
}

export async function getFDXAccountSummary() {
  	return await axios
    .all([getFDXAccounts(), getUserPreference()])
    .then(
		axios.spread((...responses) => {
			return [responses[0], responses[1]];
		})
    )
    .then((data) => {
		return {
			accounts: fdxAccountSummary(data)
		};
    })
    .then(async (data) => {
		const partyPromise = getParty();
		const accountActionsPromise = getActionDecision(data.accounts);
		const [partyProfile, accountActions] = await Promise.all([
			partyPromise,
			accountActionsPromise
		]);
		data.profile = partyProfile;
      	if (data.accounts && data.accounts.length > 0) {
			accountActions.forEach((actions) => {
				data.accounts.forEach((account) => {
					if (account.accountId === actions.id) {
						account.actions = actions.result;
					}
				});
			});
		}
		return data;
    })
    .then((data) => {
		return {
			profile: data.profile,
			accounts: data.accounts.map((acct) => fdxAccountResolver(acct)),
			transactions: []
		};
    })
    .catch((err) => console.log(err));
}

export async function getFDXTransactions(accountNumber, numTrans = 10) {
	const payload = await getFDXAccountTransactions(accountNumber, numTrans);
	return payload.transactions.map((t) => fdxTransactionMapper(t));
}

export async function getAccountSummary() {
  	return await axios
    .all([getPartyArrangementReport(), getUserPreference()])
    .then(
		axios.spread((...responses) => {
			return [responses[0], responses[1]];
		})
    )
    .then((data) => {
		return {
			profile: CustomerProfile(data[0].party.person[0]),
			accounts: accountSummary(data),
			transactions: {}
		};
    })
    .then(async (data) => {
      	if (data.accounts && data.accounts.length > 0) {
			const transPromise = getAccountTransactions(
				data.accounts[0].subCategory,
				data.accounts[0].arrangementId,
				data.accounts[0].adminSystemValue,
				data.accounts[0].numberOfTransactions
        	);

			const accountActionsPromise = getActionDecision(data.accounts);

			const [transactions, accountActions] = await Promise.all([
				transPromise,
				accountActionsPromise,
			]);

			if (data.accounts.length > 0) {
				data.transactions = {
					[data.accounts[0].arrangementId]: transactions,
				};
			}

			accountActions.forEach((actions) => {
				data.accounts.forEach((account) => {
					if (account.arrangementId === actions.id) {
						account.actions = actions.result;
					}
				});
			});
		}
		return data;
    })
    .then((data) => {
		return {
			profile: data.profile,
			accounts: data.accounts.map((acct) => accountCommonResolvers(acct)),
			transactions: data.transactions,
		};
    })
    .catch((err) => console.log(err));
}

export async function getAccountTransactions(
	accountType,
	accountNumber,
	accountSource,
	numTrans
) {
	numTrans = numTrans ? numTrans : 10;
	let trans = [];

	if (accountType === "CreditCard" || accountType === ACCOUNT_TYPE.CreditCard) {
		const payload = await getCreditCardTransactions(accountNumber, numTrans);
		trans = payload.retail.getEntriesResponse.entries;
		return trans.map((t) => transactionMapper(t));
	} else if (
		accountType === "Saving" ||
		accountType === ACCOUNT_TYPE.Saving ||
		accountType === "Chequing" ||
		accountType === ACCOUNT_TYPE.Chequing
	) {
		const payload = await getDepositTransactions(
			accountSource,
			accountNumber,
			numTrans
		);
		trans = payload.depositResponse.transactions;
		return trans.map((t) => transactionMapper(t));
	}
}

export async function getCustomerRecipients() {
	const request = await composeRequest(constants.RECIPIENT_CONFIG);
	const data = await callAPI(request);
	return resolveCustomerRecipeintList(data);
}

export async function eTransfer(payment) {
	const request = await composeRequest(constants.ETRANSFER_CONFIG);
	request.data = {
		paymentInitiation: {
			sender: {
				accountNumber: payment.senderAccountNumber,
				accountSource: payment.source
			},
			recipient: {
				recipientId: payment.recipientId,
				recipientName: payment.recipientName,
				handle: payment.handle,
				handleType: payment.handleType,
				autoDepositRegistrationId: payment.recipientAutoDepositId
			},
			paymentInstruction: {
				paymentType: "DirectDeposit", // Only support DirectDeposit for now
				currency: payment.currency,
				amount: payment.amount
			}
		}
	};
	
  	return await callAPI(request);
}

export async function getParty() {
	const request = await composeRequest(constants.RETRIEVE_PARTY_CONFIG);
	request.data.inquiryLevel = "4003";
	const data =  await callAPI(request);
	const transformParty = setUpdatableProfile(data.person);
	return  transformParty;
}

export const referenceTables = async () => {
	const payload = await getRDMCode();
	const result = await parseRDMXml(payload);

	// For non RDM mapping tables to be delivered to
	// UI, such as some OCIF mapping, we add them here
	result.deliveryMode = DELIVERY_MODE;
	result.installationType = INSTALLATION_TYPE;
	result.contactMethodType = CONTACT_MATHOD_TYPE;
	return result;
};

export const updateProfile = async ( profile, accounts ) => {
	let payload = await updateContactPoints(profile, accounts);
	let transactionId = payload.txId;
	if (profile.primaryOccupation) {
		let payload = await getParty();
		const partyUpdateRef = payload.person.sourceObjectRef;
		payload = await updatePartyOccupation(
			partyUpdateRef,
			profile.primaryOccupation
		);
		transactionId = payload.txId;
	}

	return { transactionId: transactionId };
};

async function getActionDecision(accounts) {
	const request = await composeRequest(constants.DECISIONAPI_CONFIG);
	const decisionName = Object.keys(ACCOUNT_ACTIONS).join(",");
	const data = [];
	accounts.forEach((account) => {
		data.push({
			decisionName: decisionName,
			id: account.arrangementId ?  account.arrangementId : account.accountId,
			context: {
				acctType: DECISIONAPI_ACCOUNT_TYPE[account.subCategory ? account.subCategory : account.accountType],
			}
		});
	});
	request.data = data;
	return await callAPI(request);
}

async function getDepositTransactions(source, accountNumber, lastNumTrans) {
	const request = await composeRequest(constants.GCAE_CONFIG);
	request.data = {
		originatorApplicationCatalogueId: constants.X_APP_CAT_ID,
		accountNumber: accountNumber,
		source: source,
		listControl: {
			startPage: "1",
			limit: "" + lastNumTrans
		}
	};

	return await callAPI(request);
}

async function getCreditCardTransactions(accountNumber, lastNumTrans) {
	const request = await composeRequest(constants.CCAE_CONFIG);
	request.data = {
		requestListControl: {
			limitCount: lastNumTrans
		},
		cardNumber: accountNumber,
		mostRecentTransaction: true
	};

	return await callAPI(request);
}

async function getPartyArrangementReport() {
	const request = await composeRequest(constants.PAR_CONFIG);
	return await callAPI(request);
}

async function getFDXAccounts() {
	const request = await composeRequest(constants.FDX_ACCOUNTS_CONFIG);
	return await callAPI(request);
}

async function getFDXAccountDetails(accountId) {
	const request = await composeRequest(constants.FDX_ACCOUNT_DETAILS_CONFIG, { accountId });
	return await callAPI(request);
}

async function getFDXAccountTransactions(accountId, numTrans) {
	const request = await composeRequest(constants.FDX_TRANSACTIONS_CONFIG, { accountId });
	request.url += '?limit=' + numTrans;
	return await callAPI(request);
}

async function getUserPreference() {
	const request = await composeRequest(constants.USERPREF_CONFIG);
	request.data.interactionPoint = "USERPREF";
	return await callAPI(request);
}

async function updateContactPoints(profile, accounts) {
	const request = await composeRequest(constants.UPDATE_CONTACTPOINTS_CONFIG);
	const partyRef = JSON.parse(profile.updateRef).sourceObjectRef;
	request.data.partyRef = {
		identifier: partyRef[0].objectRef[0].refKeyValue,
		identifierType: "ECIF",
		partyType: "P",
		partyObjectRef: partyRef,
	};

	if (profile.primaryAddr) {
		const updateRef = JSON.parse(profile.primaryAddr.updateRef);
		request.data.partyAddress = [{
			sourceObjectRef: updateRef.sourceObjectRef,
			addressUsageType: "100000",
			additionalAddressInfo: profile.primaryAddr.floor,
			address: {
				streetNumber: profile.primaryAddr.streetNumber,
				streetName: profile.primaryAddr.streetName,
				residenceType: profile.primaryAddr.residenceType,
				city: profile.primaryAddr.city,
				provinceStateType: profile.primaryAddr.provinceStateType,
				zipPostalCode: profile.primaryAddr.zipPostalCode,

				deliveryDesignator: profile.primaryAddr.deliveryMode,
				deliveryId: profile.primaryAddr.deliverModeText,
				installationName: profile.primaryAddr.installationName,
				stationInfo: profile.primaryAddr.installationType,
				stationId: profile.primaryAddr.installtionTypeText,
				buildingName: profile.primaryAddr.building,
				deliveryInfo: profile.primaryAddr.site,
				sourceObjectRef: updateRef.address.sourceObjectRef
			}
		}];
	}

	if (profile.contactMethods) {
		request.data.partyContactMethod = [];
		profile.contactMethods.forEach((contactMethod) => {
			const updateRef = JSON.parse(contactMethod.updateRef);
			const contact = {
				sourceObjectRef: updateRef.sourceObjectRef,
			};
			contact.contactMethod = {
				sourceObjectRef: updateRef.contactMethod.sourceObjectRef,
				contactMethodUsageType: contactMethod.type
			};
			if (contactMethod.type === "1") {
				contact.contactMethod.referenceNumber = contactMethod.phone;
				contact.contactMethod.phoneNumber = {
					phoneAreaCode: contactMethod.phoneAreaCode,
					phoneNumber: contactMethod.phoneNumber,
					phoneExtension: contactMethod.phoneExtension
				};
			} else if (contactMethod.type === "2") {
				contact.contactMethod.referenceNumber = contactMethod.email;
			}
			contact.contactMethod.preferredIndicator = contactMethod.isPreferred ? "Y" : "N";
			request.data.partyContactMethod.push(contact);
		});
	}

	if (accounts) {
		request.data.arrangementList = [];
		accounts.forEach((account) => {
			request.data.arrangementList.push({
				adminContractId: account.accountNumber,
				adminSystemType: account.source,
			});
		});
	}

	request.data.requestControl = {
		updateArrangementOnly: false,
		deleteNonMatchingStatementAddress: true,
	};

	return await callAPI(request);
}

async function updatePartyOccupation(partyUpdateRef, occupation) {
	const request = await composeRequest(constants.UPDATE_PARTY_CONFIG);
	request.data.person = {
		sourceObjectRef: partyUpdateRef,
		occupation: [{
			sourceObjectRef: JSON.parse(occupation.updateRef).sourceObjectRef,
			employmentType: occupation.employmentType,
			occupationType: occupation.occupationType,
		}]
	};
  	return await callAPI(request);
}

async function getRDMCode() {
	const request = await composeRequest(constants.RDM_CONFIG);
	const query = [];

	// The header specially required by this API to work
	request.headers.apiheaderrequest = `{"correlation":{"callPath":"LOB-SPA","myId":"isam","myTimeStamp":"2021-02-04T00:00:00.000","requestId":"isam001"},"headerVersion":"1.0","what":{"API":"/esbapi/ReferenceData/V2_1/GetDataListForParameter","APIFunction":"GetSupportedLanguages"},"where":{"originatorApplicationCatalogueId":"112","originatorChannel":"NET","originatorLocationId":"127.0.0.1","originatorLocationType":"IP","originatorSessionId":"sessionId"}}`;
	Object.keys(RDM_CODETABLES).forEach((table) => {
		query.push({
			source: "RDM",
			code: table,
			type: "Data Set~~xml",
		});
	});
	request.data.paramsInquiry = query;
	const response = await axios(request);
	return response.data;
}
