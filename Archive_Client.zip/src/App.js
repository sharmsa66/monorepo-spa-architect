import React, { useState, Suspense } from "react";
import { Route, Switch, BrowserRouter as Router } from "react-router-dom";

import { ThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import LandingPage from "./pages/LandingPage/index";
import ErrorComponent from "./components/Error.component";
import TempPage from "./pages/Temp";
import PayBills from "./pages/PayBills";
import LogOut from "./pages/LogOut";
import Profile from "./pages/Profile";
import LoginDeny from "./pages/DenyPage/LoginDeny";
import PaymentDeny from "./pages/DenyPage/PaymentDeny";
import PaymentError from "./pages/DenyPage/PaymentError";
import SendMoney from "./pages/SendMoney";
import Redirect from "./pages/OAuth/Redirect";
import "./App.css";
import { teal, blue } from "@material-ui/core/colors";
import HomeSettings from "./pages/HomeSettings";
import GenericErrorMsg from "./pages/DenyPage/GenericErrorMsg";
import AccountSummary from "./pages/AccountSummary";
import { isAuth, authorize } from "@bmo/auth" ;  // "./services/oauth";

import store from "./redux/store";
import { Provider } from "react-redux";

import "./index.css";

const theme = createMuiTheme({
  palette: {
    primary: teal,
    secondary: blue,
  },
  typography: {
    fontFamily: ["Futura", "Trebuchet MS", "Arial", "sans-serif"],
  },
  overrides: {
    MuiAppBar: {
      colorPrimary: {
        color: "#000",
        backgroundColor: "#eee",
      },
      positionStatic: {
        position: "static",
      },
    },
    MuiTabs: {
      root: {
        width: "100%",
      },
    },
    MuiTableCell: {
      sizeSmall: {
        paddingTop: 8,
        paddingBottom: 8,
        paddingLeft: 4,
        paddingRight: 4,
        "&:first-child": {
          paddingLeft: 8,
        },
        "&:last-child": {
          paddingRight: 8,
        },
      },
    },
    MuiCardContent: {
      root: {
        "&:last-child": {
          paddingBottom: 16,
        },
      },
    },
  },
});

function AppImpl() {
  const [activeSlidedetails, setActiveSlideDetails] = useState({});

  // if (!isAuth() && window.location.pathname !== "/redirect") {
  //   authorize();
  //   return null;
  // }

  return (
    <Router>
      <Provider store={store}>
        <ThemeProvider theme={theme}>
          {/* <StateProvider> */}
          <Switch>
            <Route path="/" exact>
              <LandingPage
                onSlideLoad={(accDetails) => setActiveSlideDetails(accDetails)}
                activeSlidedetails={activeSlidedetails}
              />
            </Route>
            <Route path="/paybills" exact>
              <PayBills activeSlidedetails={activeSlidedetails} />
            </Route>
            {/* <Route path="/sendmoney" exact>
              <SendMoney activeSlidedetails={activeSlidedetails} />
            </Route> */}
            <Route path="/error" exact>
              <ErrorComponent />
            </Route>
            <Route path="/temp" exact>
              <TempPage />
            </Route>
            <Route path="/redirect" exact>
              <Redirect />
            </Route>
            <Route path="/logout" exact>
              <LogOut />
            </Route>
            <Route path="/logindeny" exact>
              <LoginDeny />
            </Route>
            <Route path="/paymentdeny" exact>
              <PaymentDeny />
            </Route>
            <Route path="/paymenterror" exact>
              <PaymentError />
            </Route>
            <Route path="/genericmsg" exact>
              <GenericErrorMsg />
            </Route>
            <Route path="/landing" exact>
              <AccountSummary />
            </Route>
            <Route path="/setting" exact>
              <HomeSettings />
            </Route>
            <Route path="/profile" exact>
              <Profile />
            </Route>
          </Switch>
          {/* </StateProvider> */}
        </ThemeProvider>
      </Provider>
    </Router>
  );
}

export default function App() {
  return (
    <Suspense fallback="loading">
      <AppImpl />
    </Suspense>
  );
}
