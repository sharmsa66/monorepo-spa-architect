export const cardTypeBackgroundMap = {
    CreditCard:'bgCreditCard',
    Chequing:'bgChequing',
    Saving:'bgSaving'
}