import { configureStore, getDefaultMiddleware , combineReducers}  from '@reduxjs/toolkit';

import landingReducer   from '../pages/LandingPage/landingSlice';
import paymentReducer   from  '../pages/PayBills/paybillSlice';
import sendMoneyReducer from '../pages/SendMoney/sendMoneySlice';
import userProfileReducer from '../pages/Profile/profileSlice';

const { logger } = require(`redux-logger`);
const combinedReducers = combineReducers({
    landing: landingReducer,
    payment: paymentReducer,
    sendMoney: sendMoneyReducer,
    userProfile: userProfileReducer
});

const rootReducer = (state, action) => {
    if(action.type === 'oAuth/setUserLogout') {
      state = undefined;
    }
    return combinedReducers(state, action);
}

const sessionStorageMiddleware = ({getState}) => {
    return (next) => (action) => {
        const result = next(action);
        sessionStorage.setItem('appdata', JSON.stringify(
            getState()
        ));
        return result;
    };
};

const getReduxStore = () => { 
    if (sessionStorage.getItem('appdata') !== null) {
        return JSON.parse(sessionStorage.getItem('appdata'));
    }
}

export default configureStore ({
    reducer: rootReducer,
    preloadedState: getReduxStore(),
    devTools: process.env.NODE_ENV !== 'production',
    middleware: process.env.NODE_ENV !== 'production' ? (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(sessionStorageMiddleware).concat(logger) : 
        getDefaultMiddleware().concat(sessionStorageMiddleware)
});
