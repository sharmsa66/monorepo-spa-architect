const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-react");
const { webpack } = require("webpack");
const { EnvironmentPlugin } = require("webpack");

module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "bmo",
    projectName: "e2e-mobile-web-app",
    webpackConfigEnv,
    argv,
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    module: {
      rules: [
        {
          test: /\.(png|jpe?g|gif|eot|woff|woff2|ttf|svg)$/i,
          use: [
            {
              loader: "file-loader",
            },
          ],
        },
      ],
    },
    plugins: [
      new EnvironmentPlugin({
        REACT_APP_API_ENDPOINT: "http://localhost:4010",
        REACT_APP_AUTHORIZE_URL: "http://localhost:4010/auth",
        REACT_APP_LOGOUT_URL: "http://localhost:4010/logout",
        REACT_APP_TOKEN_URL: "http://localhost:4010/token",
        REACT_APP_CLIENT_ID: "user",
        REACT_APP_API_KEY: "12345",
        REACT_APP_FAPI_FINANCIAL_ID: "001",
        REACT_APP_CAT_ID: "112",
        REACT_APP_PAR_PATH:
          "/party-data-management/party/party-arrangement-report/get",
        REACT_APP_GCAE_PATH: "/current-account/account-entries/get",
        REACT_APP_CCAE_PATH:
          "/credit-charge-card/credit-card-account/account-entries/get",
        REACT_APP_BILL_PATH: "/payment-initiation/bill-payment-instruction",
        REACT_APP_PAYEE_PATH: "/party-data-management/party/payees",
        REACT_APP_ETRANSFER_PATH: "/payment-initiation/sendETransfer",
        REACT_APP_RECIPIENT_PATH: "/party-data-management/party/recipients",
        REACT_APP_DECISION_PATH: "/utility/decision/aggregate-rules-evaluation",
        REACT_APP_RDM_PATH:
          "/esbapi/ReferenceData/V2_1/GetDataListForParameter",
        REACT_APP_USERPREF_PATH:
          "/contact-dialogue/interaction-point-procedures/get",
        REACT_APP_RETRIEVE_PARTY_PATH: "/demo/party-data-management/party/get",
        REACT_APP_UPDATE_PARTY_PATH: "/demo/party-data-management/party",
        REACT_APP_UPDATE_CONTACTPOINTS_PATH:
          "/demo/party-data-management/party/contact-points",
        REACT_APP_FDX_ACCOUNTS_PATH: "/accounts",
        REACT_APP_FDX_ACCOUNT_DETAILS_PATH: "/accounts/{accountId}",
        REACT_APP_FDX_TRANSACTIONS_PATH: "/accounts/{accountId}/transactions",
      }),
    ],
  });
};
