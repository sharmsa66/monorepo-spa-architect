const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa");
const { IgnorePlugin } = require("webpack");
module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "bmo",
    projectName: "styleguide",
    webpackConfigEnv,
    argv,
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    module: {
      rules: [
        {
          test: /\.(png|jpe?g|gif|eot|woff|woff2|ttf|svg)$/i,
          use: [
            {
              loader: "file-loader",
            },
          ],
        },
        {
          test: /\.s[ac]ss$/i,
          use: [
            // Creates `style` nodes from JS strings
            "style-loader",
            // Translates CSS into CommonJS
            "css-loader",
            // Compiles Sass to CSS
            "sass-loader",
          ],
        },
      ],
    
  
    },
    externals: {
      'react': 'react',
      'react-dom': 'react-dom',
      'react-router-dom': 'react-router-dom'

    },
    plugins: [
      new  IgnorePlugin(/react/)
     ]
  });
};
