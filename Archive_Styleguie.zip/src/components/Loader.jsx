import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import CircularProgress from "@material-ui/core/CircularProgress";
import "./loader.css";

const useStyles = makeStyles((theme) => ({
  loaderPrimary: {
    color: "#0075BE",
  },
}));

export const Loader = () => {
  const classes = useStyles();
  return (
    <div className="loaderContainer">
      <div className="loader">
        <CircularProgress
          className="spinner"
          classes={{ colorPrimary: classes.loaderPrimary }}
        />
        <span style={{ marginTop: "10px" }}>Loading...</span>
      </div>
    </div>
  );
};
