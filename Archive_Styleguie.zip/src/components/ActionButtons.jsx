import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  root: {
    textAlign: "right",
    paddingTop: "48px",
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  continueButtonRoot: {
    borderRadius: "18px",
    height: "36px",
  },
  cancelButtonRoot: {
    borderRadius: "18px",
    height: "36px",
    border: "2px solid #0075be",
    color: "#0075be",
    "&:hover": {
      border: "2px solid #005587",
      color: "#005587",
      background: "inherit",
    },
    "&:focus": {
      border: "2px solid #005587",
      color: "#005587",
      background: "inherit",
      boxShadow: "0 0 0 2px #BEDCEB, 0 0 0 3px #005587",
      outline: 0,
    },
  },

  continueLabel: { color: "#FFFFFF" },
  contained: {
    background: "#0075BE",
    "&:hover": {
      background: "#005587",
    },
    "&:focus": {
      background: "#005587",
      boxShadow: "0 0 0 2px #BEDCEB, 0 0 0 3px #005587",
      outline: 0,
    },
  },
}));

export const ActionButtons = (props) => {
  const classes = useStyles();

  return (
    <div className={props.rootClass ? props.rootClass : classes.root}>
      <Button
        variant="outlined"
        classes={{ root: classes.cancelButtonRoot }}
        className={props.abortBtnClass || ""}
        onClick={props.abortBtnAction}
      >
        {props.abortBtnText}
      </Button>
      <Button
        variant="contained"
        classes={{
          root: classes.continueButtonRoot,
          label: classes.continueLabel,
          contained: classes.contained,
        }}
        disabled={props.disableProceedBtn}
        onClick={props.proceedBtnAction}
      >
        {props.proceedBtnText}
      </Button>
    </div>
  );
};
