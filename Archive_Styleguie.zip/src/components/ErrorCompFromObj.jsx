import React from "react";
import { makeStyles } from "@material-ui/core/styles";
// import notValid from '../../assets/OTP/NotValid.svg';
import error from "../assets/SendMoney/Error.svg";

/* const imgMap = {
    warn: warning,
    error: notValid
} */

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    padding: "10px",
    alignItems: "flex-start",
  },
  error: {
    background: "rgba(200, 20, 20, 0.08)",
  },
  warn: {
    background: "rgba(208, 119, 4, 0.08)",
  },
}));

const ErrorCompFromErrObj = ({ errorObject }) => {
  const classes = useStyles();
  return (
    <React.Fragment>
      {errorObject.errorType && (
        <div style={{ padding: "0 20px" }}>
          <div className={`${classes[errorObject.errorType]} ${classes.root}`}>
            {/* <img src={imgMap[errorObject.errorType]}/> */}
            <img src={error} alt="error" />
            <span style={{ margin: "-5px 0 0 12px" }}>
              {errorObject.errorMsg}
            </span>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default ErrorCompFromErrObj;
