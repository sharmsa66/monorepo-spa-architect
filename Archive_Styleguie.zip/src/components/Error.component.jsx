import React from "react";
import "./Error.css";

const ErrorComponent = () => {
  return (
    <div className="error-msg">
      <p>Something went wrong.... Please try again</p>
    </div>
  );
};

export default ErrorComponent;
