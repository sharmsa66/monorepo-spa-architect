import React from "react";

export const ReviewHelper = (props) => {
  return (
    <div className="review-helper-root">
      <span className="review-helper-section">{props.section}</span>
      <span>{props.value}</span>
    </div>
  );
};
