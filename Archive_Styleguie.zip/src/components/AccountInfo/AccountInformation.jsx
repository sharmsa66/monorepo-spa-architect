import React from "react";
import { cardTypeBackgroundMap } from  "../../util/util";
import { Header } from "./Header.jsx";
import { numberWithCommas } from "../../util/util";

export const AccountInformation = ({
  activeAccountDetails,
  onBackBtnClick,
}) => {
  const amount = activeAccountDetails.balance.toString();
  const isAmountNegative = amount.includes('-');
  const acctBalance = isAmountNegative ? numberWithCommas(Number(amount.split('-')[1]).toFixed(2)) : numberWithCommas(Number(amount).toFixed(2));
  return (
      <div className={cardTypeBackgroundMap[activeAccountDetails.type]} style={{padding:'27px 20px 0'}}>
          <Header onBackBtnClick={onBackBtnClick}/>
      <div style={{paddingTop:'60px', fontSize:'20px', lineHeight:'29px'}}>
        {activeAccountDetails.name}
      </div>
      <div style={{paddingTop:'12px', fontSize:'18px',  lineHeight:'14px'}}>
          {activeAccountDetails.maskedAccountNumber}
      </div>
          {/* <div style={{paddingTop:'16px', fontSize:'32px', lineHeight:'37px'}}>{activeAccountDetails.balance}</div> */}
      <div style={{paddingTop:'16px', fontSize:'32px', lineHeight:'37px'}}>
          <span className={`${isAmountNegative?'balnegative':'balpositive'}`}>
              { acctBalance }
          </span>
      </div>
    </div>
  );
};
