import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ArrowForwardIosIcon from "@material-ui/icons/ArrowForwardIos";

const useStyles = makeStyles((theme) => ({
  listitem: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #DCDCDC",
    color: "black",
    height: "76px",
  },
  listItemText: {
    marginLeft: "10px",
  },
  listFwdIcon: {
    fontSize: "0.75rem",
  },
}));

export const AccountOption = (props) => {
  const classes = useStyles();
  return (
    <ListItem
      button
      classes={{ root: classes.listitem }}
      onClick={props.onClick}
    >
      <ListItemText
        primary={props.text}
        classes={{ root: classes.listItemText }}
      />
      <ArrowForwardIosIcon classes={{ root: classes.listFwdIcon }} />
    </ListItem>
  );
};
