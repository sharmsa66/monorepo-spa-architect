import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import ArrowForwardIosIcon from "@material-ui/icons/ArrowForwardIos";

const useStyles = makeStyles({
  iconselectinproot: {
    fontSize: "0.8rem",
    color: "#DCDCDC",
  },
});

export const SelectInput = (props) => {
  const classes = useStyles();
  return (
    <div className="select-input-container">
      <div className="select-input" onClick={props.onActionClick}>
        {!props.hidetext && (
          <span className={props.textClass}>
            {props.text}
            {props.extendedText && (
              <span
                className={props.extendedTextClass}
                onClick={props.onLinkClick}
              >
                {props.extendedText}
              </span>
            )}
          </span>
        )}

        {!props.hidetext && !props.hideIcon && (
          <ArrowForwardIosIcon classes={{ root: classes.iconselectinproot }} />
        )}
      </div>
    </div>
  );
};
