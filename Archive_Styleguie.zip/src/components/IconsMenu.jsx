import React from "react";

export const IconsMenu = (props) => {
  return (
    // <div className="IconsMenu-icon">
    <img src={props.src} alt={props.text} />

    //  </div>
  );
};
