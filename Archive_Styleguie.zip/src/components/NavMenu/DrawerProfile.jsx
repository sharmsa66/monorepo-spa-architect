import React from "react";
import goback from "../../assets/Menu/LeftFigma.svg";
import { DrawerProfOption } from "./DrawerProfOption";
import { useLocation, useHistory } from "react-router-dom";
// import { logout } from "@bmo/auth";
export const DrawerProfile = (props) => {
  const history = useHistory();
  const location = useLocation();

  function tryLogout() {
    // logout().then((result) => {
    //   if (result) {
    //     history.push("/logout");
    //   } else {
    //     alert("Logout failed on server");
    //   }
    // });
  }

  return (
    <div className="drawerprofile">
      <div className="drawer-profile-options">
        <DrawerProfOption
          imgsrc={goback}
          alt="Back"
          onClick={props.closeDrawer}
        />
        <DrawerProfOption
          imgsrc={logout}
          alt="Log Out"
          label="Logout"
          onClick={tryLogout}
          imgStyle={{ width: "20px" }}
        />
      </div>
      <div className="drawer-profile-nameIcon">
        <span>{props.name}</span>
      </div>
      <div
        className="view-profile"
        onClick={() => {
          const currentPath = location.pathname;
          if (currentPath === "/profile") {
            props.closeDrawer();
          }
          history.push("/profile");
        }}
      >
        View Profile
      </div>
    </div>
  );
};
