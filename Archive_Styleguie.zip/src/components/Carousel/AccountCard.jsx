import React from "react";
import { numberWithCommas } from "../../util/util";
import { useTranslation } from "react-i18next";

export const AccountCard = (props) => {
  const { t } = useTranslation();
  const amount = props.currentBalance.toString();
  const isAmountNegative = amount.includes("-");
  const acctBalance = isAmountNegative
    ? numberWithCommas(Number(amount.split("-")[1]).toFixed(2))
    : numberWithCommas(Number(amount).toFixed(2));
  return (
    <div
      className="account-card"
      style={{
        background: `url(${props.cardImg})`,
        height: "151px",
        backgroundRepeat: "no-repeat",
        backgroundSize: "contain",
        backgroundPosition: "center",
      }}
      onClick={() => props.showAccountInfo(props.accountNumber)}
    >
      {<div className="acc-number">{props.maskedAccountNumber}</div>}
      {
        <div className="acc-balance">
          <div className="amount-info">
            {props.type === "CreditCard"
              ? t("Credit Balance")
              : t("BankAcct Balance")}
          </div>
          <span
            className={`${isAmountNegative ? "balnegative" : "balpositive"}`}
          >
            {acctBalance}
          </span>{" "}
        </div>
      }
      {/* {<div className="acc-balance">{props.currentBalance}</div> } */}
      {
        <div className="acc-accountName">
          {props.accountName.length > 26
            ? `${props.accountName.slice(0, 26)}...`
            : props.accountName}
        </div>
      }
    </div>
  );
};
