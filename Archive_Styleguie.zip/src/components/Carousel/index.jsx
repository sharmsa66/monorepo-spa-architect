import React from "react";
import { CarouselMenu } from "./CarouselMenu";
import Fade from "@material-ui/core/Fade";

export const Carousel = ({
  accounts,
  onAccountSlide,
  curentSlide,
  show,
  carouseHeading,
  carouselDiv,
  showAccountInfo,
}) => {
  return (
    <Fade in={show} {...(show ? { timeout: 1000 } : {})}>
      <div className={`${carouselDiv} myAccounts ${show ? "show" : "hide"}`}>
        {carouseHeading && (
          <span className="myaccount-span">{carouseHeading}</span>
        )}
        <div className="valueCard">
          <CarouselMenu
            accounts={accounts}
            onAccountSlide={onAccountSlide}
            curentSlide={curentSlide}
            showAccountInfo={showAccountInfo}
          />
        </div>
      </div>
    </Fade>
  );
};
