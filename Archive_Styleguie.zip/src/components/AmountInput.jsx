import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Input from "@material-ui/core/Input";
import InputAdornment from "@material-ui/core/InputAdornment";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    borderBottom: "1px solid #DCDCDC",
    color: "#095DA2",
  },
  adormentRoot: {
    "& p": {
      color: "#095DA2 !important",
      fontSize: "20px",
      fontWeight: "600",
    },
  },
  adormentPositionStart: {
    marginRight: "1px",
  },
  input: {
    fontSize: "20px",
    fontWeight: "500",
  },
}));

export const AmountInput = ({ onAmountInpt, amount, setAmount }) => {
  const classes = useStyles();
  return (
    <div className="bill-input-container">
      <span className="bill-input-header-span">
        How much would you like to send?
      </span>
      <Input
        id="standard-adornment-amount"
        value={amount}
        disableUnderline={true}
        classes={{ root: classes.root, input: classes.input }}
        onChange={(e) => {
          setAmount(e.target.value);
          onAmountInpt(e.target.value);
        }}
        startAdornment={
          <InputAdornment
            position="start"
            classes={{
              root: classes.adormentRoot,
              positionStart: classes.adormentPositionStart,
            }}
          >
            $
          </InputAdornment>
        }
      />
    </div>
  );
};
