import {createMuiTheme , teal,blue} from "@material-ui/core/styles";

export const cardTypeBackgroundMap = {
    CreditCard: "bgCreditCard",
    Chequing: "bgChequing",
    Saving: "bgSaving",
  };
  
  export function numberWithCommas(x) {
    const parts = x.toString().split(".");
    const thousandSeperated = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return `${thousandSeperated}.${parts[1]}`;
  }
  
  export function convertObjectToArray(obj) {
    const arr = obj
      ? Object.keys(obj).map((key) => ({
          value: key,
          label: String(obj[key]).slice(0, 30),
        }))
      : [];
    return arr;
  }


export const theme = createMuiTheme({
  palette: {
    primary: teal,
    secondary: blue,
  },
  typography: {
    fontFamily: ["Futura", "Trebuchet MS", "Arial", "sans-serif"],
  },
  overrides: {
    MuiAppBar: {
      colorPrimary: {
        color: "#000",
        backgroundColor: "#eee",
      },
      positionStatic: {
        position: "static",
      },
    },
    MuiTabs: {
      root: {
        width: "100%",
      },
    },
    MuiTableCell: {
      sizeSmall: {
        paddingTop: 8,
        paddingBottom: 8,
        paddingLeft: 4,
        paddingRight: 4,
        "&:first-child": {
          paddingLeft: 8,
        },
        "&:last-child": {
          paddingRight: 8,
        },
      },
    },
    MuiCardContent: {
      root: {
        "&:last-child": {
          paddingBottom: 16,
        },
      },
    },
  },
});

  