
export const goHome = () => {
   // window.location.href = 'http://localhost:9000';
    window.history.back();

};

export const goBack = () => {
    window.location.href = () => {
        window.history.back();
    }
}

export const goToSendPayment = () => {
    window.location.href = 'http://localhost:9000/sendmoney'
}