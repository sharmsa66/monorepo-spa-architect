import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';

const useStyles = makeStyles((theme) => ({
  root:{
    width:'100%',
     borderBottom:'1px solid #DCDCDC',
     color: '#393A3D',
   },
   
   input:{
     fontSize:'16px',
     fontWeight: '400'
   }
   }));

export const Message = ({message, setMessage}) => {
    const classes = useStyles();
    return (
        <div className="bill-input-container">
            <span className="bill-input-header-span">Message (Optional)</span>
          <Input
            id="send-money-message"
            value={message}
            disableUnderline={true}
            classes={{root: classes.root, input: classes.input}}
            onChange={(e) => {
                setMessage(e.target.value)
            }}
          />
        </div>
    )

}