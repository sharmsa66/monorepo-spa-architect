import React, { useState, useEffect, useContext } from "react";
import { HeaderComp } from "@bmo/styleguide";   // "../../components/HeaderComp";
import { ActionButtons } from "@bmo/styleguide";  // "../../components/ActionButtons";
import { ReviewHelper } from "@bmo/styleguide";  //"../../components/ReviewHelper";
import { Success } from "./Success";
// import { useHistory } from "react-router-dom";
import review from "../../assets/PayBills/Review.svg";
import arrow from "../../assets/PayBills/Arrow.svg";
import { Recepient } from "./Recepient";
import { Loader } from "@bmo/styleguide";   //"../../components/Loader";
// import { useDispatch } from "react-redux";
// import { makeEtransfer } from "./sendMoneySlice"; 
// import { unwrapResult } from "@reduxjs/toolkit";
// import { savePageContext } from "../../services/oauth";
import { eTransfer } from '@bmo/bmo-api';
import { savePageContext } from '@bmo/auth'
import {ERRORS} from  "@bmo/bmo-api";
export const ReviewRecipientDetails = ({
	onBackBtnClick,
	selectedAccountDetails,
	sendToAnotherRecepient,
	selectedRecepientDetails,
	message,
	sendingFrom,
	name,
	proceedConfirmation,
}) => {

  const [showSuccess, setshowSuccess] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [etransferDetails, setEtransferDetails] = useState({});
  // const history = useHistory();
  const { recepientDetails, amount } = selectedRecepientDetails;
  // const dispatch = useDispatch();

  async function postSendMoney() {
      const { accountNumber, source, currency } = selectedAccountDetails;
      const amountNumber = parseFloat(amount);
      setShowLoader(true);
      const paymentDetails = {
          senderAccountNumber: accountNumber,
          ...recepientDetails,
          amount: amountNumber,
          source,
          currency
      };

      // Use helper funciton from oauth to save page context in case the current
      // API call needs user re-autorization or token escalation, such that after
      // the authorization is done the redirect page will restore the page context
      // and continue the operation 

      if (!proceedConfirmation) {
          savePageContext({
              path: "/sendmoney",
              state: {
                  selectedAccountDetails,
                  selectedRecepientDetails,
                  message,
                  showReviewRecepient: true
              }
          });
      }

      try {
        const response = await eTransfer(paymentDetails);
        setEtransferDetails(response);
        setShowLoader(false);
        setshowSuccess(true);
      } catch(error )  {
          if (error.message === ERRORS.INSUFFICIENT_SCOPE) {
              return;
          }
          else if (error.message === ERRORS.INSUFFICIENT_PERMISSION) {
              alert("You don't have permission to do payment right now");
          }
          setShowLoader(false);
          console.error(error.message);
      };
  }

  useEffect(() => {
      if (proceedConfirmation) {
          postSendMoney();
      }
  }, [proceedConfirmation]);

  return (
    <div className="review-bill">
      {showLoader && !showSuccess && <Loader />}
      <HeaderComp
        heading="Review Send Money"
        onBackBtnClick={onBackBtnClick}
        name={name}
      />
      <div
        className="review-bill-details lrPad20"
        style={showSuccess ? { display: "none" } : {}}
      >
        <div className="review-icon">
          <img src={review} alt="review" />
        </div>
        <div style={{ paddingTop: "40px" }}>
          <span style={{ display: "block", fontWeight: "500" }}>
            {selectedAccountDetails.accountName}
          </span>
          <span>{selectedAccountDetails.maskedAccountNumber}</span>
        </div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} alt="arrow" />
        </div>
        <div>
          <div className="selected-payee-details">
            <Recepient
              name={recepientDetails.recipientName}
              email={recepientDetails.email}
              number={recepientDetails.recipientHandle}
              selected={true}
            />
          </div>
        </div>
        <div className="bill-review-vertical-divider">
          <img src={arrow} alt="arrow" />
        </div>
        <div className=" styleamount">{`$${Number(amount).toFixed(2)}`}</div>
        {message && (
          <React.Fragment>
            <div className="bill-review-vertical-divider">
              <img src={arrow} alt="arrow" />
            </div>
            <ReviewHelper section="Message (optional)" value={message} />
          </React.Fragment>
        )}
        <div className="bill-review-vertical-divider">
          <img src={arrow} alt="arrow" />
        </div>
        <ReviewHelper section="Sending From" value={sendingFrom} />
      </div>
      <ActionButtons
        proceedBtnText="Send Money"
        abortBtnText="Cancel"
        proceedBtnAction={() => postSendMoney()}
        abortBtnAction={() => window.history.go('/')}
      />
      {showSuccess && (
        <Success
          sendToAnotherRecepient={sendToAnotherRecepient}
          selectedRecepientDetails={selectedRecepientDetails}
          etransferDetails={etransferDetails}
          selectedAccountDetails={selectedAccountDetails}
          name={name}
        />
      )}
    </div>
  );
};
