import React from 'react';
import { SelectInput } from  "@bmo/styleguide";  // '../../components/SelectInput';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
    textClass: {
      fontWeight: 'normal'
    }
  });

export const SendingFrom = (props) => {
    const classes = useStyles();
    return (
        <div className="bill-input-container">
            <span className="bill-input-header-span">Sending from</span>
        <SelectInput text={props.sendingFrom} textClass={classes.textClass} />
        </div>
    )

}