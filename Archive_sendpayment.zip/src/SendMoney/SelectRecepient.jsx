import React, { useState, useEffect } from "react";
//import { useHistory } from "react-router-dom";
import { RecepientSelect } from "./RecepientSelect";
import { RecepientList } from "./RecepientList";
//import { useDispatch, useSelector } from "react-redux";
//import { fetchCustomerRecepients } from "./sendMoneySlice";
import {  getCustomerPayees, getCustomerRecipients } from '@bmo/bmo-api';

export const SelectRecepient = ({
  onRecepientSelect,
  selectedRecepient,
  setSelectedRecepient,
  setShowLoader,
  profile
}) => {
  const [showSelectRecepient, setShowSelectRecepient] = useState(false);
  const loading = false;
  const error =  null; 
  const [recepients,setRecepients] = useState([]);
  function handleSelectedRecepient(selectedRecepientDetails) {
    setShowSelectRecepient(false);
    setSelectedRecepient(selectedRecepientDetails);
    onRecepientSelect(selectedRecepientDetails);
  }


  useEffect(() => {
      if (recepients && recepients.length <=0) {
          fetchRecepients();
      }
      async function fetchRecepients() {
          try {
            setShowLoader(true);
            const response = await getCustomerRecipients();
            setRecepients(response);

          } catch (error) {
              console.error(error);
          } finally {
            setShowLoader(false)
          }
      }
  }, [recepients]);

  return (
    <React.Fragment>
      {showSelectRecepient && recepients ? (
        <RecepientList
          onSelectRecepient={(selectedRecepientDetails) =>
            handleSelectedRecepient(selectedRecepientDetails)
          }
          headerHeading="Choose your recepient"
          onBackBtnClick={() => setShowSelectRecepient(false)}
          recepients={recepients}
          profile={profile}
        />
      ) : (
        <div className="bill-input-container">
          <span className="bill-input-header-span">Sending To</span>
          <RecepientSelect
            selectedRecepient={selectedRecepient}
            onActionClick={() => setShowSelectRecepient(true)}
          />
        </div>
      )}
    </React.Fragment>
  );
};
