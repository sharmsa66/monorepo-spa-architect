import React from 'react';



export const Recepient = ({name, email, number, onSelect, selected}) => {
    const nameLetters = name.match(/\b(\w)/g);
    const nameLettersJoin = nameLetters.join('');
    return (
        <div className={`recepient-container ${selected ? 'selected-recep' :''}`} onClick={onSelect}>
            <div className="recepient-circle-icon">
                {nameLettersJoin}
            </div>
            <div className="recepient-details">
                <div className="recepient-name">{name}</div>
                <div>{email}</div>
                <div>{number}</div>
            </div>
        </div> 
    )

}