import React from "react";
import  SendMoney from './SendMoney/index';
 import { ThemeProvider} from "@material-ui/core/styles";
import { theme } from '@bmo/styleguide';

export default function Root(props) {
  return (
          <ThemeProvider theme={theme}>
            <SendMoney></SendMoney>
          </ThemeProvider>
          );
           
   
}
